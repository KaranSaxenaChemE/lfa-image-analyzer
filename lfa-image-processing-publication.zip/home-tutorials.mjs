// Create the Google player only after a visitor opens a tutorial.
for (const item of document.querySelectorAll('.tutorial-item')) {
  item.addEventListener('toggle', () => {
    const slot = item.querySelector('.tutorial-player');
    if (!item.open) {
      // Unload a closed player so playback stops and hidden videos use no resources.
      slot.replaceChildren();
      return;
    }
    if (slot.childElementCount) return;
    const frame = document.createElement('iframe');
    frame.src = 'https://drive.google.com/file/d/' + slot.dataset.videoId + '/preview';
    frame.title = slot.dataset.videoTitle;
    frame.allow = 'autoplay; fullscreen';
    frame.allowFullscreen = true;
    frame.referrerPolicy = 'no-referrer';
    slot.append(frame);
  });
}

// Closing the whole tutorial section also stops any open player.
document.querySelector('.tutorials-panel').addEventListener('toggle', event => {
  if (!event.currentTarget.open) {
    for (const item of event.currentTarget.querySelectorAll('.tutorial-item')) item.open = false;
  }
});
