// A viewing copy of the current notebook. No scripts, workers or remote assets
// are needed to open the downloaded file; scientific calculations are untouched.
const savedStyles=`
.saved-copy{border:1px solid #cedce3;border-left:3px solid #426b7c;padding:12px 15px;margin:15px 0 24px;font:14px/1.6 Arial,sans-serif;background:#f6f9fb}
.saved-copy p{margin:4px 0}.saved-setting{display:block;font:14px/1.55 Consolas,monospace;white-space:pre-wrap;overflow-wrap:anywhere;color:#262626}
#experiment-details.saved-notes{height:auto;min-height:0;white-space:pre-wrap;overflow:visible;font:15px/1.55 Arial,sans-serif}
.saved-index{margin:18px 0 26px;border:1px solid #ddd;padding:10px 14px}.saved-index summary,.saved-data summary{cursor:pointer;font-weight:700}.saved-index ul{padding-left:22px}.saved-index li{margin:5px 0}
.saved-data{margin:28px 0}.saved-data pre{max-height:500px;overflow:auto;white-space:pre-wrap;word-break:break-word}
@media print{#experiment-details.saved-notes{display:block!important}.saved-setting{display:block!important}.saved-index,.saved-data{display:none}}
`;

function styles(){
 const result=[];
 for(const sheet of document.styleSheets){
  if(sheet.disabled)continue;
  // All app styles are loaded from the same origin. Do not silently create a
  // partially styled document if an inaccessible stylesheet is introduced.
  const rules=[...sheet.cssRules].map(rule=>rule.cssText).join('\n');
  result.push(sheet.media.mediaText?'@media '+sheet.media.mediaText+'{'+rules+'}':rules);
 }
 return result.join('\n');
}

function captureCanvas(source,target){
 const image=document.createElement('img');
 image.src=source.toDataURL('image/png');
 image.alt=source.closest('figure')?.querySelector('figcaption')?.textContent||'LFA image';
 image.width=source.width;image.height=source.height;
 image.className=(source.className||'')+' saved-canvas';
 if(source.id)image.id=source.id;
 const css=getComputedStyle(source);
 for(const property of ['display','width','height','max-width','max-height','object-fit','margin-top','margin-right','margin-bottom','margin-left'])image.style.setProperty(property,css.getPropertyValue(property));
 target.replaceWith(image);
}

function captureSetting(source,target){
 if(source.type==='file'&&!source.files.length){target.closest('label')?.remove();return;}
 const value=source.tagName==='SELECT'?[...source.selectedOptions].map(o=>o.textContent).join(', '):source.type==='checkbox'?(source.checked?'true':'false'):source.type==='file'?[...source.files].map(f=>f.name).join('\n'):source.value;
 const output=document.createElement(source.tagName==='TEXTAREA'?'pre':'span');
 output.textContent=value;output.className=source.tagName==='TEXTAREA'?'saved-notes':'saved-setting';
 output.style.fontWeight=getComputedStyle(source).fontWeight;
 if(source.id)output.id=source.id;
 target.replaceWith(output);
}

async function buildSnapshot(data){
 const sourceMain=document.querySelector('main.document');
 const html=document.documentElement.cloneNode(true),main=html.querySelector('main.document');
 const css=styles();
 const controls=[...html.querySelectorAll('input,select,textarea')];
 [...document.querySelectorAll('input,select,textarea')].forEach((source,i)=>captureSetting(source,controls[i]));
 const canvases=[...html.querySelectorAll('canvas')];
 [...document.querySelectorAll('canvas')].forEach((source,i)=>captureCanvas(source,canvases[i]));

 const images=[...html.querySelectorAll('img')].filter(img=>!img.classList.contains('saved-canvas'));
 const liveImages=[...document.querySelectorAll('img')];
 const imageJobs=liveImages.map(async(source,i)=>{
  if(!source.getAttribute('src'))throw Error('An illustration has not finished loading. Please try again.');
  if(!source.complete||!source.naturalWidth)await source.decode();
  const canvas=document.createElement('canvas');canvas.width=source.naturalWidth;canvas.height=source.naturalHeight;
  canvas.getContext('2d').drawImage(source,0,0);
  images[i].src=canvas.toDataURL('image/png');
  images[i].removeAttribute('srcset');images[i].removeAttribute('sizes');images[i].removeAttribute('loading');
 });

 // Existing SVG plots already embed the strip as a data URL; retain the SVGs
 // and their text/legends rather than rasterising scientific figures.
 for(const image of html.querySelectorAll('svg image')){
  const href=image.getAttribute('href')||image.getAttribute('xlink:href');
  if(href&&!href.startsWith('data:'))throw Error('A figure contains an image that cannot be saved offline.');
 }

 const headings=[...sourceMain.querySelectorAll('h2,h3')],copies=[...main.querySelectorAll('h2,h3')];
 const index=document.createElement('details');index.className='saved-index';
 const summary=document.createElement('summary');summary.textContent='Notebook sections';index.append(summary);
 const list=document.createElement('ul');
 headings.forEach((heading,i)=>{
  if(!heading.getClientRects().length||heading.closest('.image-result'))return;
  copies[i].id||='saved-section-'+i;
  const item=document.createElement('li'),link=document.createElement('a');link.href='#'+copies[i].id;link.textContent=heading.textContent.trim();item.append(link);list.append(item);
 });index.append(list);

 for(const node of html.querySelectorAll('script,link,base,iframe,object,embed,form,button,.pdf-actions,.print-value,#experiment-details-print,#html-export-status,.notebook-index-tools,#notebook-index,nav[aria-label="Analysis navigation"],.site-footer-nav,#crop-editor'))node.remove();
 for(const element of html.querySelectorAll('*'))for(const attribute of [...element.attributes])if(/^on/i.test(attribute.name))element.removeAttribute(attribute.name);
 for(const element of html.querySelectorAll('.print-only'))element.classList.remove('print-only');
 html.querySelector('body').classList.remove('notebook-index-open');
 const head=html.querySelector('head');head.querySelectorAll('style,meta[http-equiv]').forEach(node=>node.remove());
 const charset=head.querySelector('meta[charset]')||document.createElement('meta');charset.setAttribute('charset','utf-8');head.prepend(charset);
 const security=document.createElement('meta');security.httpEquiv='Content-Security-Policy';security.content="default-src 'none'; img-src data:; style-src 'unsafe-inline'; font-src data:; base-uri 'none'; form-action 'none'";charset.after(security);
 const style=document.createElement('style');style.textContent=css+'\n'+savedStyles;head.append(style);
 const note=document.createElement('aside');note.className='saved-copy';
 const title=document.createElement('strong');title.textContent='Saved analysis · offline viewing copy';
 const date=document.createElement('p');date.textContent='Saved '+new Date().toLocaleString(undefined,{dateStyle:'long',timeStyle:'long'});
 const help=document.createElement('p');help.textContent='This file preserves the settings and results at the time of saving. Images and figures are embedded. To change settings or run another analysis, open the app.';
 note.append(title,date,help);main.prepend(note,index);
 const raw=document.createElement('details');raw.className='saved-data';const rawSummary=document.createElement('summary');rawSummary.textContent='Full analysis data (JSON)';
 const pre=document.createElement('pre');pre.id='saved-analysis-data';pre.textContent=JSON.stringify(data,null,2);raw.append(rawSummary,pre);main.append(raw);
 // App-relative navigation cannot work from a downloaded file. Preserve
 // internal section links and explicit author/institution/article links.
 for(const link of html.querySelectorAll('a[href]'))if(!/^(#|https?:\/\/)/i.test(link.getAttribute('href')))link.removeAttribute('href');
 await Promise.all(imageJobs);
 return '<!doctype html>\n'+html.outerHTML;
}

export function installNotebookHTMLExport({getData,getFilename}){
 const buttons=['top','bottom'].map(side=>document.getElementById('save-html-'+side));
 const pdf=document.getElementById('save-pdf-top'),message=document.getElementById('html-export-status');
 let saving=false;
 const sync=()=>{for(const button of buttons)button.disabled=saving||pdf.disabled;};
 new MutationObserver(sync).observe(pdf,{attributes:true,attributeFilter:['disabled']});sync();
 for(const button of buttons)button.addEventListener('click',async()=>{
  if(saving||pdf.disabled)return;
  saving=true;sync();message.textContent='Preparing the complete HTML file locally…';
  try{
   const data=getData(),name=getFilename();const html=await buildSnapshot(data);
   const url=URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'}));
   const link=document.createElement('a');link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),10000);
   message.textContent='HTML downloaded. Open the saved file in a browser to view this analysis offline.';
  }catch(error){message.textContent='Could not save HTML: '+error.message;}
  finally{saving=false;sync();}
 });
}
