// An offline interactive record. Only the small, embedded viewing script runs;
// the numerical engine and analysis settings remain unchanged and locked.
const savedStyles=`
.saved-copy{border:1px solid #cedce3;border-left:3px solid #426b7c;padding:10px 14px;margin:15px 0 20px;font:14px/1.6 Arial,sans-serif;background:#f6f9fb}
.saved-copy p{margin:4px 0}.saved-setting{display:block;font:14px/1.55 Consolas,monospace;white-space:pre-wrap;overflow-wrap:anywhere;color:#262626}
.saved-setting-print{display:none}input:disabled,select:disabled{opacity:1;color:#404040;-webkit-text-fill-color:#404040;background:#f5f5f5;cursor:not-allowed}
.saved-data summary{cursor:pointer;font-weight:700}
.saved-data{margin:28px 0}.saved-data pre{max-height:500px;overflow:auto;white-space:pre-wrap;word-break:break-word}
.saved-status{font:14px/1.5 Arial,sans-serif;color:#365566}
@media print{.saved-setting-print,.saved-setting{display:block!important}.saved-copy,.saved-data,.saved-status{display:none!important}#experiment-details-print:not([hidden]){display:block!important}}
`;

// This function is serialized into the saved file. Keep it self-contained: no
// imports, network calls, worker, storage, numerical code or outside variables.
function savedNotebook(){
 const $=id=>document.getElementById(id),notes=$('experiment-details'),raw=$('saved-analysis-data');
 const status=$('html-export-status'),panel=$('notebook-index'),toggle=$('notebook-index-toggle');
 function syncNotes(){
  const print=$('experiment-details-print');print.textContent=notes.value;print.hidden=!notes.value.trim();
  const data=JSON.parse(raw.textContent);data.experiment_details=notes.value;raw.textContent=JSON.stringify(data,null,2);
 }
 function download(value,name,type){
  const url=URL.createObjectURL(new Blob([value],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);
 }
 function open(value){
  panel.hidden=!value;toggle.setAttribute('aria-expanded',String(value));toggle.setAttribute('aria-label',(value?'Close':'Open')+' notebook section index');document.body.classList.toggle('notebook-index-open',value);
 }
 toggle.addEventListener('click',()=>open(panel.hidden));
 addEventListener('keydown',event=>{if(event.key==='Escape'){open(false);toggle.focus();}});
 panel.addEventListener('click',event=>{
  const a=event.target.closest('a[href^="#"]');if(!a)return;
  const target=$(decodeURIComponent(a.hash.slice(1)));if(!target)return;
  event.preventDefault();if(matchMedia('(max-width:1099px)').matches)open(false);
  location.hash=a.hash;target.scrollIntoView({block:'start'});target.focus({preventScroll:true});
  panel.querySelectorAll('a').forEach(link=>link.removeAttribute('aria-current'));a.setAttribute('aria-current','location');
 });
 notes.addEventListener('input',()=>{syncNotes();status.textContent='Notes edited. Choose Save updated HTML to keep these changes in a new file.';});
 addEventListener('beforeprint',syncNotes);
 document.addEventListener('click',event=>{
  const button=event.target.closest('button[data-saved-action]');if(!button)return;
  syncNotes();const action=button.dataset.savedAction,name=button.dataset.savedFilename;
  if(action==='pdf'){window.print();return;}
  if(action==='html'){
   notes.textContent=notes.value;$('saved-updated-at').textContent='Last saved '+new Date().toLocaleString(undefined,{dateStyle:'long',timeStyle:'long'});
   status.textContent='Saved notebook. Notes can be edited; analysis settings and results are locked.';
   download('<!doctype html>\n'+document.documentElement.outerHTML,document.body.dataset.savedFilename,'text/html;charset=utf-8');return;
  }
  if(action==='svg'){
   const svg=$(button.dataset.savedTarget);download(new XMLSerializer().serializeToString(svg),name,'image/svg+xml');return;
  }
  if(action==='json'){download(raw.textContent,name,'application/json');return;}
  if(action==='csv'){
   const table=$(button.dataset.savedTarget),quote=value=>'"'+String(value).replaceAll('"','""')+'"';
   let rows;
   if(table){rows=[...table.rows].map(row=>[...row.cells].map(cell=>cell.hasAttribute('title')?cell.title:cell.textContent));rows=rows.map(row=>row.map(value=>value==='Infinity'?'Inf':value==='-Infinity'?'-Inf':value));}
   else{
    const data=JSON.parse(raw.textContent),fields=['C_area','T_area','area_ratio','C_prom','T_prom','prom_ratio'];
    const modes={1:'Colorimetric (dark lines on bright background)',2:'Fluorescent/Chemiluminescent (bright lines on dark background)'};
    rows=[['filename','method','readout','control_threshold','test_threshold',...fields],[data.filename,$('method').selectedOptions[0].textContent,modes[data.readout],data.settings.control_threshold,data.settings.test_threshold,...fields.map(key=>data[key])]];
   }
   download(rows.map(row=>row.map(quote).join(',')).join('\r\n'),name,'text/csv');
  }
 });
 syncNotes();
}

function styles(){
 const result=[];
 for(const sheet of document.styleSheets){
  if(sheet.disabled)continue;
  // All app styles are loaded from the same origin. Do not silently create a
  // partially styled document if an inaccessible stylesheet is introduced.
  const rules=[...sheet.cssRules].map(rule=>rule.cssText).join('\n');
  result.push(sheet.media.mediaText?'@media '+sheet.media.mediaText+'{'+rules+'}':rules);
 }
 return result.join('\n');
}

function captureCanvas(source,target){
 const image=document.createElement('img');
 image.src=source.toDataURL('image/png');
 image.alt=source.closest('figure')?.querySelector('figcaption')?.textContent||'LFA image';
 image.width=source.width;image.height=source.height;
 image.className=(source.className||'')+' saved-canvas';
 if(source.id)image.id=source.id;
 const css=getComputedStyle(source);
 for(const property of ['display','width','height','max-width','max-height','object-fit','margin-top','margin-right','margin-bottom','margin-left'])image.style.setProperty(property,css.getPropertyValue(property));
 target.replaceWith(image);
}

function captureSetting(source,target){
 if(source.tagName==='TEXTAREA'){target.value=source.value;target.textContent=source.value;return;}
 const value=source.tagName==='SELECT'?[...source.selectedOptions].map(o=>o.textContent).join(', '):source.type==='checkbox'?(source.checked?'true':'false'):source.type==='file'?[...source.files].map(f=>f.name).join('\n'):source.value;
 if(source.type==='file'){
  const output=document.createElement('span');output.textContent=value||'No files selected';output.className='saved-setting';output.id=source.id;target.replaceWith(output);return;
 }
 target.disabled=true;target.title='Saved analysis setting — locked. Use the app to run a new analysis.';
 if(source.tagName==='SELECT')[...target.options].forEach((option,i)=>option.toggleAttribute('selected',source.options[i].selected));
 else if(source.type==='checkbox')target.toggleAttribute('checked',source.checked);
 else target.setAttribute('value',source.value);
 const print=document.createElement('span');print.className='saved-setting-print';print.textContent=value;target.after(print);
}

async function buildSnapshot(data,filename){
 const sourceMain=document.querySelector('main.document');
 const html=document.documentElement.cloneNode(true),main=html.querySelector('main.document');
 const css=styles();
 const controls=[...html.querySelectorAll('input,select,textarea')];
 [...document.querySelectorAll('input,select,textarea')].forEach((source,i)=>captureSetting(source,controls[i]));
 const canvases=[...html.querySelectorAll('canvas')];
 [...document.querySelectorAll('canvas')].forEach((source,i)=>captureCanvas(source,canvases[i]));

 const images=[...html.querySelectorAll('img')].filter(img=>!img.classList.contains('saved-canvas'));
 const liveImages=[...document.querySelectorAll('img')];
 const imageJobs=liveImages.map(async(source,i)=>{
  if(!source.getAttribute('src'))throw Error('An illustration has not finished loading. Please try again.');
  if(!source.complete||!source.naturalWidth)await source.decode();
  const canvas=document.createElement('canvas');canvas.width=source.naturalWidth;canvas.height=source.naturalHeight;
  canvas.getContext('2d').drawImage(source,0,0);
  images[i].src=canvas.toDataURL('image/png');
  images[i].removeAttribute('srcset');images[i].removeAttribute('sizes');images[i].removeAttribute('loading');
 });

 // Existing SVG plots already embed the strip as a data URL; retain the SVGs
 // and their text/legends rather than rasterising scientific figures.
 for(const image of html.querySelectorAll('svg image')){
  const href=image.getAttribute('href')||image.getAttribute('xlink:href');
  if(href&&!href.startsWith('data:'))throw Error('A figure contains an image that cannot be saved offline.');
 }

 // Preserve the Batch menu and its image-file shortcuts. Single notebooks get
 // the same menu built from the visible section headings.
 if(!html.querySelector('#notebook-index')){
  const tools=document.createElement('div');tools.className='notebook-index-tools';
  tools.innerHTML='<button id="notebook-index-toggle" type="button" aria-label="Open notebook section index" aria-controls="notebook-index" aria-expanded="false" title="Notebook sections"><span class="notebook-menu-bars" aria-hidden="true"><i></i><i></i><i></i></span></button><span class="notebook-index-label">Notebook sections</span>';
  const panel=document.createElement('nav');panel.id='notebook-index';panel.className='notebook-index';panel.setAttribute('aria-label','Notebook section index');panel.hidden=true;
  panel.innerHTML='<h2 class="notebook-index-title">Notebook sections</h2><div id="notebook-index-links"><ul></ul></div>';
  const list=panel.querySelector('ul'),headings=[...sourceMain.querySelectorAll('h2,h3')],copies=[...main.querySelectorAll('h2,h3')];
  headings.forEach((heading,i)=>{
   if(!heading.getClientRects().length)return;
   copies[i].id||='saved-section-'+i;copies[i].tabIndex=-1;copies[i].classList.add('notebook-section-target');
   const li=document.createElement('li'),a=document.createElement('a');a.href='#'+copies[i].id;a.textContent=heading.textContent.trim();li.append(a);list.append(li);
  });html.querySelector('body').prepend(tools,panel);
 }
 const stem=filename.replace(/\.html$/i,'');let figureNumber=0,tableNumber=0;
 for(const button of html.querySelectorAll('button')){
  const id=button.id;let action,name,target;
  if(id==='notebook-index-toggle')continue;
  if(id.startsWith('save-pdf-'))action='pdf';
  else if(id.startsWith('save-html-')){action='html';button.textContent='Save updated HTML';}
  else if(id==='download-json'){action='json';name=stem+'-results.json';}
  else if(id==='download-csv'){action='csv';name=stem+'-measurements.csv';}
  else if(button.closest('figure')?.querySelector('svg')){
   action='svg';target=button.closest('figure').querySelector('svg');target.id||='saved-figure-'+(++figureNumber);name=stem+'-'+target.id+'.svg';
  }else if(button.closest('.table-block')?.querySelector('table')){
   action='csv';target=button.closest('.table-block').querySelector('table');target.id||='saved-table-'+(++tableNumber);name=stem+'-'+target.id+'.csv';
  }
  if(!action){button.remove();continue;}
  button.disabled=false;button.dataset.savedAction=action;
  if(name)button.dataset.savedFilename=name;if(target)button.dataset.savedTarget=target.id;
 }
 for(const node of html.querySelectorAll('script,link,base,iframe,object,embed,form,.print-value,nav[aria-label="Analysis navigation"],.site-footer-nav,#crop-editor'))node.remove();
 for(const element of html.querySelectorAll('*'))for(const attribute of [...element.attributes])if(/^on/i.test(attribute.name))element.removeAttribute(attribute.name);
 for(const element of html.querySelectorAll('.print-only:not(#experiment-details-print)'))element.classList.remove('print-only');
 html.querySelector('body').dataset.savedFilename=filename;
 const head=html.querySelector('head');head.querySelectorAll('style,meta[http-equiv]').forEach(node=>node.remove());
 const charset=head.querySelector('meta[charset]')||document.createElement('meta');charset.setAttribute('charset','utf-8');head.prepend(charset);
 const runtime='('+savedNotebook.toString()+')();';
 const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(runtime));
 const hash=btoa(String.fromCharCode(...new Uint8Array(digest)));
 const security=document.createElement('meta');security.httpEquiv='Content-Security-Policy';security.content="default-src 'none'; script-src 'sha256-"+hash+"'; img-src data:; style-src 'unsafe-inline'; font-src data:; base-uri 'none'; form-action 'none'";charset.after(security);
 const style=document.createElement('style');style.textContent=css+'\n'+savedStyles;head.append(style);
 const note=document.createElement('aside');note.className='saved-copy';
 const title=document.createElement('strong');title.textContent='Saved analysis · interactive offline notebook';
 const date=document.createElement('p');date.id='saved-updated-at';date.textContent='Saved '+new Date().toLocaleString(undefined,{dateStyle:'long',timeStyle:'long'});
 const help=document.createElement('p');help.textContent='Use the section menu, download figures and tables, save as PDF, or edit experimental notes and choose Save updated HTML. Analysis settings and results are locked; use the app for new calculations.';
 note.append(title,date,help);main.querySelector('.pdf-actions').after(note);
 const message=html.querySelector('#html-export-status');message.classList.add('saved-status');message.textContent='Notes can be edited; analysis settings and results are locked.';
 const pdfHelp=main.querySelector('.pdf-actions span');if(pdfHelp)pdfHelp.textContent='Save as PDF opens the print dialog. Save updated HTML keeps your edited notes in a new offline file.';
 const print=html.querySelector('#experiment-details-print');print.textContent=data.experiment_details||'';print.hidden=!print.textContent.trim();
 const raw=document.createElement('details');raw.className='saved-data';const rawSummary=document.createElement('summary');rawSummary.textContent='Full analysis data (JSON)';
 const pre=document.createElement('pre');pre.id='saved-analysis-data';pre.textContent=JSON.stringify(data,null,2);raw.append(rawSummary,pre);main.append(raw);
 // App-relative navigation cannot work from a downloaded file. Preserve
 // internal section links and explicit author/institution/article links.
 for(const link of html.querySelectorAll('a[href]'))if(!/^(#|https?:\/\/)/i.test(link.getAttribute('href')))link.removeAttribute('href');
 // Author-supplied notes and JSON are text nodes, never executable markup.
 // Only this exact script is permitted by the saved document's CSP hash.
 const script=document.createElement('script');script.textContent=runtime;html.querySelector('body').append(script);
 await Promise.all(imageJobs);
 return '<!doctype html>\n'+html.outerHTML;
}

export function installNotebookHTMLExport({getData,getFilename}){
 const buttons=['top','bottom'].map(side=>document.getElementById('save-html-'+side));
 const pdf=document.getElementById('save-pdf-top'),message=document.getElementById('html-export-status');
 let saving=false;
 const sync=()=>{for(const button of buttons)button.disabled=saving||pdf.disabled;};
 new MutationObserver(sync).observe(pdf,{attributes:true,attributeFilter:['disabled']});sync();
 for(const button of buttons)button.addEventListener('click',async()=>{
  if(saving||pdf.disabled)return;
  saving=true;sync();message.textContent='Preparing the complete HTML file locally…';
  try{
   const data=getData(),name=getFilename();const html=await buildSnapshot(data,name);
   const url=URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'}));
   const link=document.createElement('a');link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),10000);
   message.textContent='HTML downloaded. Open the saved file in a browser to view this analysis offline.';
  }catch(error){message.textContent='Could not save HTML: '+error.message;}
  finally{saving=false;sync();}
 });
}
