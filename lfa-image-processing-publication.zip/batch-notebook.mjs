import {calibrationFigure} from './batch-calibration.mjs';
import {modelEquation,lodEquation} from './model-equations.mjs';
import {imageCanvas,profileFigure,alignedFigure,diagnosticChannels} from './batch-plots.mjs';
const $=id=>document.getElementById(id),worker=new Worker('./batch-worker.mjs',{type:'module'});
const channelNames=['Red Channel','Green Channel','Blue Channel','Grayscale','Contrast-adjusted Grayscale'];
const methodValues=['Automatic RGB','Contrast-Adjusted Grayscale','Red_channel','Green_channel','Blue_channel','Grayscale'];
const modes={1:'Colorimetric (dark lines on bright background)',2:'Fluorescent/Chemiluminescent (bright lines on dark background)'};
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const special=v=>v==='Infinity'||v===Infinity?'Inf':v==='-Infinity'||v===-Infinity?'-Inf':v;
const num=v=>typeof v==='number'&&Number.isFinite(v)?String(Number(v.toPrecision(9))):String(special(v));
function formatText(element,text){
 element.replaceChildren();
 for(const part of text.split(/\b(Sandwich|Competitive|SANDWICH|COMPETITIVE)\b/g)){
  if(/^(Sandwich|Competitive|SANDWICH|COMPETITIVE)$/.test(part)){const strong=document.createElement('strong');strong.textContent=part;element.append(strong);}
  else element.append(document.createTextNode(part));
 }
}
let selected=[],ready=false,busy=false,sequence=0,latest=null,imageRows=[],imageSettings=null;
function settings(){return {method:+$('method').value,readout:+$('readout').value,control_threshold:+$('control-threshold').value,test_threshold:+$('test-threshold').value,diagnostics:$('diagnostics').value,stage:$('stage').value,signal:$('signal').value,format:$('format').value,model:$('model').value,lod_method:+$('lod-method').value,units:$('units').value.trim()};}
function setBusy(value){
 busy=value;for(const id of ['folder','files','method','readout','control-threshold','test-threshold','diagnostics','stage','signal','format','model','lod-method','analyte','units'])$(id).disabled=value;
 $('run').disabled=value||!ready||!selected.length;$('recalculate').disabled=value||!imageRows.length||$('stage').value==='Image Analysis Only';
 for(const id of ['save-pdf-top','save-pdf-bottom','download-json'])$(id).disabled=value||!latest;
}
function clearCalibration(){
 for(const id of ['averages-table','parameters-table','gof-table','equation','lod-equations','format-output','lod-output','calibration','warnings'])$(id).replaceChildren();
 $('calibration-figure').hidden=true;
 $('publication-output').hidden=true;$('publication-curve').replaceChildren();
}
function reset(){
 latest=null;imageRows=[];imageSettings=null;clearCalibration();$('image-results').replaceChildren();$('results-table').replaceChildren();$('readout-output').replaceChildren();$('image-completion').replaceChildren();$('error').hidden=true;setBusy(false);
}
function select(files){
 reset();
 const topLevel=files.filter(f=>!f.webkitRelativePath||f.webkitRelativePath.split('/').length===2);
 selected=topLevel.filter(f=>/\.(jpe?g|png|tiff?)$/i.test(f.name));
 const ignored=topLevel.filter(f=>!selected.includes(f));
 $('selection').textContent=selected.length+' supported image(s) selected.'+(ignored.length?' Excluded unsupported files: '+ignored.map(f=>f.name).join(', '):'')+(files.length!==topLevel.length?' Subfolders are excluded, as in the MATLAB folder workflow.':'');
 setBusy(false);
}
$('folder').addEventListener('change',()=>select([...$('folder').files]));
$('files').addEventListener('change',()=>select([...$('files').files]));
$('run').addEventListener('click',()=>{
 if(busy||!selected.length)return;
 for(const id of ['control-threshold','test-threshold'])if(!$(id).value.trim()||!$(id).checkValidity()){$(id).reportValidity();return;}
 reset();imageSettings=settings();setBusy(true);$('engine-status').textContent='Analysing selected images locally…';sequence++;
 $('method-run-output').textContent='Image analysis method for this batch: '+methodValues[imageSettings.method];
 $('run-information').textContent='CODE RUN DATE AND TIME: '+new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Kolkata',dateStyle:'short',timeStyle:'medium',hour12:false}).format(new Date())+' IST';
 worker.postMessage({type:'analyze',id:sequence,files:selected,options:imageSettings});
});
for(const id of ['method','readout','control-threshold','test-threshold','diagnostics','stage'])$(id).addEventListener('change',()=>{
 $('method-selection').textContent="image_analysis_method =\n   '"+methodValues[+$('method').value]+"'";
 reset();$('calibration-controls').hidden=$('stage').value==='Image Analysis Only';$('engine-status').textContent='Settings changed. Run image analysis to update the results.';
});
function recalculate(){
 if(busy||!imageRows.length)return;latest=null;clearCalibration();$('error').hidden=true;setBusy(true);$('engine-status').textContent='Calculating statistics, fitted curve and LoD locally…';
 sequence++;worker.postMessage({type:'calibrate',id:sequence,options:settings()});
}
$('recalculate').addEventListener('click',recalculate);
for(const id of ['signal','format','model','lod-method','units','analyte'])$(id).addEventListener('change',recalculate);
function fail(message){$('error').textContent=message;$('error').hidden=false;$('engine-status').textContent='Analysis stopped. Review the message and settings.';setBusy(false);}
worker.onmessage=({data})=>{
 if(data.type==='ready'){ready=true;setBusy(false);$('engine-status').textContent='Ready. Select an image folder or image files.';return;}
 if(data.type==='fatal'){fail(data.error);return;}
 if(data.id!==sequence)return;
 if(data.type==='error'){fail(data.error);return;}
 if(data.type==='readout'){
  const strong=document.createElement('strong');strong.textContent=modes[data.readout];
  $('readout-output').replaceChildren(document.createTextNode(data.filename?'Auto-detected LFA readout mode from '+data.filename+': ':'LFA readout mode: '),strong);
  if(data.detection){const d=data.detection;$('readout-output').append(document.createTextNode(' (background '+d.backgroundLevel.toFixed(1)+'; dark-line score '+d.darkLineScore.toFixed(1)+'; bright-line score '+d.brightLineScore.toFixed(1)+').'));}
 }else if(data.type==='image'){
  imageRows.push(data.row);renderImage(data);$('engine-status').textContent='Analysed '+data.index+' of '+data.total+': '+data.row.filename;
 }else if(data.type==='summary'){
  if(data.result.error){fail(data.result.error);return;}
  latest=data.result;$('image-completion').textContent='Image Analysis Complete';renderSummary(latest);setBusy(false);$('engine-status').textContent=latest.calibration_error||latest.fit?.lod_error?'Image measurements are available. Review the calibration message below.':'Analysis complete.';
 }
};
worker.onerror=e=>fail('The analysis engine stopped: '+e.message+'. Reload this view to restart it.');
function download(data,name,type){const url=URL.createObjectURL(new Blob([data],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}
function figure(svg,name){
 const f=document.createElement('figure');f.className='plot';f.innerHTML=svg;const button=document.createElement('button');button.textContent='Download SVG';button.addEventListener('click',()=>download(svg,name+'.svg','image/svg+xml'));f.append(button);return f;
}
function renderImage(data){
 const section=document.createElement('article');section.className='image-result';
 const heading=document.createElement('h3');heading.textContent='============================================================\nANALYSING LFA IMAGE: '+data.row.filename+'\n============================================================';section.append(heading);
 const decision=document.createElement('p'),strong=document.createElement('strong');strong.textContent=channelNames[data.channel];decision.append(strong,document.createTextNode(' is the best channel for further analysis'));
 const r=data.result,stem=data.row.filename.replace(/\.[^.]+$/,'');
 if(r&&imageSettings.diagnostics==='All'){
  const channels=document.createElement('div');channels.className='batch-channels';
  const images=diagnosticChannels(r).map(id=>[channelNames[id],id<3?id:id===3?r.grayscale:r.adjusted]);
  for(const [name,plane]of [['Original Image',null],...images]){
   const f=document.createElement('figure'),caption=document.createElement('figcaption');caption.textContent=name;f.append(caption,imageCanvas(r.rgb,r.width,r.height,plane));channels.append(f);
  }
  section.append(channels);
 }
 if(data.index===1&&imageSettings.method===0){const ranges=document.createElement('pre');ranges.textContent='red_range = '+num(data.ranges[0])+'\ngreen_range = '+num(data.ranges[1])+'\nblue_range = '+num(data.ranges[2]);section.append(ranges);}
 if(imageSettings.method===0)section.append(decision);
 const values=document.createElement('pre');
 values.textContent=['pks','locs','widths','proms'].map((name,i)=>name+' =\n   '+data.peaks.map(p=>num(p[['height','location','width','prominence'][i]])).join('\n   ')).join('\n\n');section.append(values);
 if(r&&imageSettings.diagnostics==='All')section.append(figure(profileFigure(r),stem+'-profiles'));
 const areas=document.createElement('pre');areas.textContent='The area under control peak = '+num(data.row.C_area)+(data.row.C_prom===0?'\nControl peak not detected':'')+(data.row.T_prom===0?'\nTest Line not detected':'')+'\nThe area under test peak = '+num(data.row.T_area);section.append(areas);
 if(r){
  section.append(figure(alignedFigure(r).replaceAll('aligned-image','aligned-image-'+data.index),stem+'-aligned'));
 }
 const outputs=document.createElement('pre');outputs.textContent='The area ratio (T/C)_area = '+num(data.row.T_area/data.row.C_area)+'\nTest Peak Prominence = '+num(data.row.T_prom)+'\nControl Peak Prominence = '+num(data.row.C_prom)+'\nThe prominence ratio T/C = '+num(data.row.T_prom/data.row.C_prom)+'\n---------------- Moving on to the next image-------------';section.append(outputs);
 $('image-results').append(section);
}
function table(target,title,spec,name){
 const mount=$(target);mount.replaceChildren();if(!spec)return;
 const block=document.createElement('div');block.className='table-block'+(spec.columns.length>6?' wide':'');const h=document.createElement('h3');h.textContent=title+' ('+spec.rows.length+' rows)';block.append(h);
 const help=document.createElement('p');help.className='table-help';help.textContent='All rows and columns are included. Scroll sideways if needed; the CSV contains the complete table.';block.append(help);
 const scroll=document.createElement('div');scroll.className='table-scroll';scroll.tabIndex=0;scroll.setAttribute('role','region');scroll.setAttribute('aria-label',title+' — scroll horizontally to view all columns');
 const t=document.createElement('table'),caption=document.createElement('caption');caption.textContent=title;caption.hidden=true;t.append(caption);
 const head=document.createElement('thead'),hr=document.createElement('tr');for(const name of spec.columns){const th=document.createElement('th');th.scope='col';th.textContent=name;hr.append(th);}head.append(hr);t.append(head);
 const body=document.createElement('tbody');for(const row of spec.rows){const tr=document.createElement('tr');for(const value of row){const td=document.createElement('td');td.textContent=num(value);td.title=String(value);tr.append(td);}body.append(tr);}t.append(body);scroll.append(t);block.append(scroll);
 const button=document.createElement('button');button.textContent='Download '+title+' CSV';button.addEventListener('click',()=>{const quote=v=>'"'+String(special(v)).replaceAll('"','""')+'"';download([spec.columns,...spec.rows].map(row=>row.map(quote).join(',')).join('\r\n'),name+'.csv','text/csv');});block.append(button);mount.append(block);
}
function renderSummary(r){
 clearCalibration();table('results-table','Per-image results',r.results,'batch-image-results');
 $('calibration-controls').hidden=r.stage==='Image Analysis Only';
 if(r.stage==='Image Analysis Only')return;
 table('averages-table','Replicate statistics',r.averages,'batch-replicate-statistics');
 $('format-output').replaceChildren();
 if(r.format){
  const bold=document.createElement('strong');bold.textContent=r.format.toUpperCase();
  const units=$('units').value.trim(),averages=r.averages.rows,g=v=>String(Number(v.toPrecision(6)));
  const auto=$('format').value==='Auto';
  $('format-output').append(document.createTextNode('============================================================\nLFA FORMAT USED FOR ANALYSIS: '),bold,document.createTextNode('\nDetermination mode: '+(auto?'AUTO':'USER DEFINED')+(auto?'\nMean Test Line Area at lowest concentration ('+g(averages[0][0])+' '+units+'): '+g(r.endpoint_test_areas[0])+'\nMean Test Line Area at highest concentration ('+g(averages.at(-1)[0])+' '+units+'): '+g(r.endpoint_test_areas[1]):'')+'\nLoD signal-direction factor, k = '+(r.k>0?'+1':'-1')+'\n============================================================'));
 }
 for(const warning of r.warnings??[]){const p=document.createElement('p');p.className='warning';formatText(p,warning);$('warnings').append(p);}
 if(r.fallback_details){const pre=document.createElement('pre');pre.className='signal-fallback-details';pre.textContent=r.fallback_details;$('warnings').append(pre);}
 if(r.signal!==$('signal').value){const p=document.createElement('p');p.className='warning';p.textContent='Signal metric used after fallback: '+r.signal;$('warnings').append(p);}
 if(r.calibration_error){const p=document.createElement('p');p.className='calibration-error';formatText(p,r.calibration_error);$('warnings').append(p);return;}
 const f=r.fit;if(!f)return;
 $('equation').innerHTML=modelEquation(f.model,r.format);table('parameters-table','Fitted model parameters',f.parameters,'batch-model-parameters');table('gof-table','Goodness of fit',f.gof,'batch-goodness-of-fit');
 $('lod-equations').innerHTML=lodEquation(+$('lod-method').value,r.k);
 $('lod-output').textContent=f.lod_error??('Raw fsolve LoD concentration = '+String(f.lod)+'\nThe Limit of Detection of the assay = '+f.lod_display+' '+$('units').value.trim());
 $('calibration').innerHTML=calibrationSVG(r);$('calibration-figure').hidden=false;
 $('publication-curve').innerHTML=calibrationSVG(r,true);$('publication-output').hidden=false;
}
function calibrationSVG(r,publication=false){return calibrationFigure(r,{analyte:$('analyte').value,units:$('units').value.trim(),publication});}
$('download-calibration').addEventListener('click',()=>download(new XMLSerializer().serializeToString($('calibration').querySelector('svg')),'batch-calibration.svg','image/svg+xml'));
$('download-publication').addEventListener('click',()=>download(new XMLSerializer().serializeToString($('publication-curve').querySelector('svg')),'batch-publication-curve.svg','image/svg+xml'));
$('download-json').addEventListener('click',()=>download(JSON.stringify({experiment_details:$('experiment-details').value,analyte:$('analyte').value,settings:settings(),image_settings:imageSettings,measurements:imageRows,...latest},null,2),'batch-lfa-results.json','application/json'));
function syncNotes(){const value=$('experiment-details').value;$('experiment-details-print').textContent=value;$('experiment-details-print').hidden=!value.trim();}
$('experiment-details').addEventListener('input',syncNotes);
function preparePrint(){
 syncNotes();document.querySelectorAll('.print-value').forEach(e=>e.remove());
 for(const input of document.querySelectorAll('select,input[type=number],input[type=text]')){
  const span=document.createElement('span');span.className='print-value';span.textContent=input.tagName==='SELECT'?input.selectedOptions[0].textContent:input.value;input.after(span);
 }
}
for(const id of ['save-pdf-top','save-pdf-bottom'])$(id).addEventListener('click',()=>{preparePrint();window.print();});
addEventListener('beforeprint',preparePrint);
async function artwork(){
 const a=await(await fetch('./assets/artwork.json')).json();
 for(const key of ['4451','3c31']){
  const image=document.createElement('img');image.src='./assets/'+a[key];image.alt=key==='4451'?'Indian Institute of Science':'Toley Lab';
  const link=document.createElement('a');link.href=key==='4451'?'https://iisc.ac.in/':'https://toleylab.weebly.com/';link.target='_blank';link.rel='noopener noreferrer';link.append(image);$('logos').append(link);
 }
 $('orientation').src='./assets/'+a['0d05'];
}
artwork().catch(error=>fail('Could not load the app artwork: '+error.message));
$('method-selection').textContent="image_analysis_method =\n   '"+methodValues[+$('method').value]+"'";
$('format').addEventListener('change',()=>{$('format').style.fontWeight=$('format').value==='Auto'?'400':'700';});
