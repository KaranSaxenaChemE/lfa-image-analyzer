import {calibrationFigure} from '../batch-calibration.mjs';
import {modelEquation,lodEquation} from '../model-equations.mjs';
import {alignedPlot,profilePlot,orientationFigure} from './plots.mjs';
import {spreadsheetCSV,lineLabel} from './concentrations.mjs';

export function el(tag,text,cls) {
  const node=document.createElement(tag);
  if(text!==undefined)node.textContent=text;
  if(cls)node.className=cls;
  return node;
}
export function download(value,name,type) {
  const url=URL.createObjectURL(value instanceof Blob?value:new Blob([value],{type}));
  const link=el('a');link.href=url;link.download=name;link.click();
  setTimeout(()=>URL.revokeObjectURL(url),30000);
}
function dataLink(value,name,type,text) {
  const link=el('a',text,'result-download');link.download=name;
  link.href='data:'+type+';charset=utf-8,'+encodeURIComponent(value);
  return link;
}
export function tableView(columns,rows,filename,{compact=false,groupFilenames=false}={}) {
  const wrap=el('div',undefined,'table-block'+(columns.length>6?' wide':'')), table=el('table'), head=table.createTHead().insertRow();
  for(const name of columns){const cell=el('th',name);cell.scope='col';head.append(cell);}
  const groups=groupFilenames?[]:[rows];
  if(groupFilenames){
    for(const row of rows){
      const group=groups.at(-1);
      if(group&&group[0][0]===row[0])group.push(row);
      else groups.push([row]);
    }
  }
  for(const group of groups){
    const body=table.createTBody();
    for(const [index,row] of group.entries()){
      const tr=body.insertRow();
      if(groupFilenames&&index===0){
        const name=el('th',row[0]);name.scope='rowgroup';name.rowSpan=group.length;
        tr.append(name);
      }
      for(const value of groupFilenames?row.slice(1):row){
        const cell=tr.insertCell();
        cell.textContent=typeof value==='number'?Number(value.toPrecision(6)):value??'—';
        if(typeof value==='number')cell.title=String(value);
      }
    }
  }
  const scroll=el('div',undefined,'table-scroll');scroll.tabIndex=0;scroll.append(table);
  if(!compact)wrap.append(el('p','All rows and columns are included. Scroll sideways if needed; the CSV contains the complete table.','table-help'));
  wrap.append(scroll,dataLink(spreadsheetCSV([columns,...rows]),filename+'.csv','text/csv','Download CSV'));
  return wrap;
}
export function figureView(svg,name) {
  const figure=el('figure',undefined,svg.classList.contains('multiplex-aligned-svg')?'plot multiplex-aligned':'plot');
  figure.append(svg,dataLink(new XMLSerializer().serializeToString(svg),name+'.svg','image/svg+xml','Download SVG'));
  return figure;
}
const channelNames=['Red','Green','Blue','Grayscale','Contrast-adjusted grayscale'];
function usablePlot(result) {
  const {fit,averages}=result;
  const curve=fit?.curve?.filter(row=>Array.isArray(row)&&typeof row[1]==='number'&&Number.isFinite(row[1]));
  return Array.isArray(curve)&&curve.length>1&&curve[0][0]>0&&curve.at(-1)[0]>curve[0][0]&&
    curve.every(row=>typeof row[0]==='number'&&Number.isFinite(row[0]))&&
    Array.isArray(averages?.rows)&&averages.rows.some(row=>row[0]>0)&&
    averages.rows.every(row=>[row[0],row[1],row[2]].every(Number.isFinite));
}
export function resultSummary(record,line,index,{calibration=true,measurements=true}={}) {
  const root=el('div'),prefix='T'+(index+1),result=record.summary;
  const readout=el('pre','LFA readout mode: ');
  readout.append(el('strong',record.readout===1?'Colorimetric':'Fluorescent/Chemiluminescent'));
  if(measurements)root.append(readout);
  const columns=['File Name','T_area','C_area','(T/C)_area','T Prominence','C Prominence','T/C Prominence','Status'];
  if(measurements)root.append(el('h3','Per-image results ('+record.measurements.length+' rows)'),tableView(columns,record.measurements.map(m=>[
    m.name,m.row.T_area,m.row.C_area,m.row.C_area?m.row.T_area/m.row.C_area:null,
    m.row.T_prom,m.row.C_prom,m.row.C_prom?m.row.T_prom/m.row.C_prom:null,m.status
  ]),prefix+'-measurements'));
  if(!calibration||!result)return root;
  if(result.error||result.calibration_error)root.append(el('p',result.error??result.calibration_error,'notice'));
  for(const warning of result.warnings??[])root.append(el('p',warning,'notice'));
  if(result.format)root.append(el('p','Assay format: '+result.format+'. Signal: '+result.signal+'.'));
  if(result.results?.rows?.length)root.append(el('h3','Calibration inputs and signals'),tableView(result.results.columns,result.results.rows,prefix+'-calibration-inputs'));
  if(result.averages)root.append(el('h2','STATISTICAL ANALYSIS:'),el('h3','Replicate statistics'),tableView(result.averages.columns,result.averages.rows,prefix+'-replicates'));
  const fit=result.fit;
  if(fit){
    root.append(el('h2','Plotting Results'),el('h3','Curve Fitting'));
    const model=el('div',undefined,'math-equation'),lod=el('div',undefined,'math-equation');
    model.innerHTML=modelEquation(fit.model,result.format);
    lod.innerHTML=lodEquation(record.settings.lod_method,result.k);
    root.append(model);
    for(const [label,item] of [['Fitted model parameters',fit.parameters],['Goodness of fit',fit.gof]])
      if(item?.rows)root.append(el('h3',label),tableView(item.columns,item.rows,prefix+'-'+label.toLowerCase().replaceAll(' ','-')));
    root.append(el('h2','LoD Calculation'),lod,el('pre',typeof fit.lod==='number'?'Calculated LoD: '+fit.lod_display+' '+line.units:(fit.lod_error??'A finite LoD was unavailable.'),'lod-result'));
    for(const publication of [false,true]){
      if(!usablePlot(result)){root.append(el('p','A calibration plot is unavailable for this fit.','notice'));break;}
      try{
        const template=el('template');
        template.innerHTML=calibrationFigure(result,{analyte:line.name,units:line.units,publication}).replaceAll('plot-area','plot-area-'+prefix);
        if(publication)root.append(el('h2','Final Signal-Response (Standard) Curve for publications'));
        root.append(figureView(template.content.firstElementChild,prefix+(publication?'-publication':'-calibration')));
      }catch{root.append(el('p','The calibration plot could not be drawn for this fit.','notice'));}
    }
    if(fit.lod_error&&typeof fit.lod==='number')root.append(el('p',fit.lod_error,'notice'));
  }
  return root;
}

export function diagnosticImages(measurement){
  const container=el('div',undefined,'batch-channels');
  const entries=[[-1,'Original Image'],...(measurement.channelProfiles??[]).map(([channel])=>[channel,channelNames[channel]+(channel<3?' Channel':'')])];
  for(const [channel,label] of entries){
    const source=measurement.channelImages?.[channel+1];
    if(!source)continue;
    const figure=el('figure'),image=el('img');
    image.alt=label;image.src=source;
    figure.append(el('figcaption',label),image);container.append(figure);
  }
  return container;
}

export function diagnosticOutput(measurement,testLines){
  const [control,...tests]=measurement.lines;
  const number=value=>String(Number(value.toPrecision(6)));
  const peaks=measurement.lines.filter(Boolean);
  const rows=tests.map((test,i)=>{
    const config=testLines[i];
    const analyte=config.name.trim()||'—', units=config.units.trim();
    return ['Test Line '+(i+1),units?analyte+' ('+units+')':analyte,
      control?.area?(test?.area??0)/control.area:null,test?.prominence??0,
      control?.prominence?(test?.prominence??0)/control.prominence:null];
  });
  const table=el('div',undefined,'strip-signal-table');
  table.append(el('h4','Test line measurements'),tableView(
    ['Test line','Analyte','(T/C) area','Test peak prominence','T/C prominence'],rows,
    measurement.name.replace(/\.[^.]+$/,'')+'-test-lines',{compact:true}));
  return [
    el('pre',[['pks','height'],['locs','location'],['widths','width'],['proms','prominence']]
      .map(([label,key])=>label+' =\n   '+peaks.map(peak=>number(peak[key])).join('\n   ')).join('\n\n')),
    el('pre',['The area under control peak = '+number(control?.area??0),...tests.map((test,i)=>
      'The area under Test Line '+(i+1)+' peak = '+number(test?.area??0)+(test?'':' (not detected)'))].join('\n')),
    table
  ];
}

export function sharedResultsTable(batch,testLines) {
  const root=el('div');
  const readout=el('pre','LFA readout mode: ');
  readout.append(el('strong',batch.readout===1?'Colorimetric':'Fluorescent/Chemiluminescent'));
  root.append(readout,el('h3','Per-image results'));
  const rows=batch.measurements.flatMap(m=>{
    const [control,...tests]=m.lines;
    return tests.map((test,i)=>[m.name,lineLabel(testLines[i],i),test?.area??0,control?.area??0,
      control?.area?(test?.area??0)/control.area:null,test?.prominence??0,control?.prominence??0,
      control?.prominence?(test?.prominence??0)/control.prominence:null,
      m.controlMissing?m.status:test?'Measured':'Test line not detected']);
  });
  root.append(tableView(['File Name','Test Line','T_area','C_area','(T/C)_area','T Prominence','C Prominence','T/C Prominence','Status'],rows,'multiplex-image-results',{groupFilenames:true}));
  return root;
}

function svgFor(record,line,index,publication,suffix){
  if(!usablePlot(record.summary))return null;
  const template=el('template');
  template.innerHTML=calibrationFigure(record.summary,{analyte:line.name,units:line.units,publication})
    .replaceAll('plot-area','plot-area-T'+(index+1)+(publication?'-publication':'')+suffix);
  return template.content.firstElementChild;
}

export function renderBatchResults(record,line,index,suffix=''){
  const mount=id=>document.getElementById(id+suffix);
  for(const id of ['averages-table','format-output','parameters-table','gof-table','warnings','equation','lod-equations','lod-output','calibration','publication-curve'])mount(id).replaceChildren();
  mount('calibration-figure').hidden=mount('publication-output').hidden=true;
  mount('lod-output').classList.remove('lod-result');
  const result=record?.summary;
  if(!result)return;
  if(result.averages)mount('averages-table').append(el('h3','Replicate statistics ('+result.averages.rows.length+' rows)'),tableView(result.averages.columns,result.averages.rows,'T'+(index+1)+'-replicates'));
  if(result.format)mount('format-output').append('LFA FORMAT USED FOR ANALYSIS: ',el('strong',result.format.toUpperCase()),'\nLoD signal-direction factor, k = '+(result.k>0?'+1':'-1'));
  for(const warning of result.warnings??[])mount('warnings').append(el('p',warning,'warning'));
  if(result.fallback_details)mount('warnings').append(el('pre',result.fallback_details));
  if(result.error||result.calibration_error)mount('warnings').append(el('p',result.error??result.calibration_error,'calibration-error'));
  if(!result.fit)return;
  const fit=result.fit;
  mount('equation').innerHTML=modelEquation(fit.model,result.format);
  mount('lod-equations').innerHTML=lodEquation(record.settings.lod_method,result.k);
  for(const [id,title,item] of [['parameters-table','Fitted model parameters',fit.parameters],['gof-table','Goodness of fit',fit.gof]])
    if(item?.rows)mount(id).append(el('h3',title),tableView(item.columns,item.rows,'T'+(index+1)+'-'+id));
  mount('lod-output').classList.add('lod-result');
  mount('lod-output').textContent=fit.lod_error??('Raw fsolve LoD concentration = '+String(fit.lod)+'\nThe Limit of Detection of the assay = '+fit.lod_display+' '+line.units);
  for(const [id,outer,publication] of [['calibration','calibration-figure',false],['publication-curve','publication-output',true]]){
    const svg=svgFor(record,line,index,publication,suffix);
    if(svg){mount(id).append(svg);mount(outer).hidden=false;}
  }
  for(const id of ['calibration','publication']){
    const svg=mount(id==='calibration'?'calibration':'publication-curve').querySelector('svg');
    mount('download-'+id).onclick=()=>{if(svg)download(new XMLSerializer().serializeToString(svg),'T'+(index+1)+'-'+id+'.svg','image/svg+xml');};
  }
}

export async function combinedReport(state,{forPrint=false}={}) {
  const doc=document.implementation.createHTMLDocument('Multiplex LFA analysis');
  doc.documentElement.lang='en';
  const meta=doc.createElement('meta');meta.setAttribute('charset','utf-8');doc.head.prepend(meta);
  const viewport=doc.createElement('meta');viewport.name='viewport';viewport.content='width=device-width,initial-scale=1';doc.head.append(viewport);
  const sheets=[...document.querySelectorAll('link[rel="stylesheet"]')];
  if(forPrint){
    for(const sheet of sheets){
      const link=sheet.cloneNode();link.href=sheet.href;doc.head.append(link);
    }
  }else{
    const policy=doc.createElement('meta');policy.httpEquiv='Content-Security-Policy';
    policy.content="default-src 'none'; img-src data:; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'";
    doc.head.append(policy);
    const css=await Promise.all(sheets.map(async link=>{
      const response=await fetch(link.href);
      if(!response.ok)throw Error('Could not load notebook styles.');
      const rules=await response.text();
      return link.media==='print'?'@media print{'+rules+'}':rules;
    }));
    const style=doc.createElement('style');style.textContent=css.join('\n');doc.head.append(style);
  }
  const body=el('main',undefined,'document multiplex');
  doc.body.append(body);
  const header=document.querySelector('.document-header').cloneNode(true);
  for(const image of header.querySelectorAll('img')){
    const response=await fetch(image.src);
    if(!response.ok)throw Error('Could not embed notebook branding.');
    const blob=await response.blob();
    image.src=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(blob);});
  }
  header.querySelector('a[aria-label="LFA2LoD home"]')?.removeAttribute('href');
  body.append(header,el('p','Use your browser’s Print command to save this complete notebook as PDF.','print-help'),
    el('h2','Experimental Information'),el('pre',state.notes||'No experiment details entered.'),
    el('p','Representative image: '+state.reference+'. Default dividers after pixels: '+state.dividers.join(', ')+'.'));
  const orientation=el('figure',undefined,'orientation');
  orientation.id='orientation';
  orientation.append(orientationFigure(state.lines),el('figcaption','Figure 1: Correct LFA Strip orientation for analysis.'));
  body.append(orientation);
  const pending=state.lines.map((line,i)=>state.saved[i]?null:lineLabel(line,i)).filter(Boolean);
  if(pending.length)body.append(el('p','Unfinished or awaiting resave: '+pending.join(', ')+'.','notice'));
  const nav=el('nav',undefined,'report-index');nav.setAttribute('aria-label','Test line sections');body.append(nav);
  const first=state.saved.find(Boolean);
  if(first){
    body.append(el('h2','Individual image processing results'));
    for(const measurement of first.measurements){
      if(first.settings.diagnostics==='None'&&!measurement.controlMissing)continue;
      const image=el('article',undefined,'image-result'),[peaks,areas,outputs]=diagnosticOutput(measurement,state.lines);
      image.append(el('h3','ANALYSING LFA IMAGE: '+measurement.name),el('p',(measurement.controlMissing?measurement.status:'Measured')+
        ' Dividers after pixels: '+measurement.dividers.join(', ')+'.'));
      if(first.settings.diagnostics==='All')image.append(diagnosticImages(measurement));
      image.append(peaks);
      if(first.settings.diagnostics==='All')image.append(figureView(profilePlot(measurement),measurement.name+'-profiles'));
      image.append(areas,figureView(alignedPlot(measurement),measurement.name+'-aligned'),outputs);body.append(image);
    }
    body.append(sharedResultsTable(first,state.lines));
  }
  state.lines.forEach((line,i)=>{
    const record=state.saved[i];
    if(!record)return;
    const link=el('a',lineLabel(line,i));link.href='#test-'+(i+1);nav.append(link,el('br'));
    const section=el('section');section.id='test-'+(i+1);section.className='saved-analyte';
    section.append(el('h2',lineLabel(line,i)),el('h3','Analysis settings'),el('pre',Object.entries(record.settings).map(([k,v])=>k.replaceAll('_',' ')+': '+v).join('\n')));
    section.append(resultSummary(record,line,i,{measurements:false}));
    body.append(section);
  });
  return '<!doctype html>\n'+doc.documentElement.outerHTML;
}
