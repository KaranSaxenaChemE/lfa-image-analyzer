const encoder = new TextEncoder(), decoder = new TextDecoder();
export async function createMultiplexEngine(bytes) {
  const {instance} = await WebAssembly.instantiate(bytes,{});
  const wasm = instance.exports;
  function put(data) {
    const ptr=wasm.allocate(data.length);
    new Uint8Array(wasm.memory.buffer,ptr,data.length).set(data);
    return ptr;
  }
  function invoke(name, payload, options) {
    const data=payload instanceof Uint8Array?payload:encoder.encode(JSON.stringify(payload));
    const settings=options && encoder.encode(JSON.stringify(options));
    const ptr=put(data), extra=settings && put(settings);
    try {
      if(settings) wasm[name](ptr,data.length,extra,settings.length);
      else wasm[name](ptr,data.length);
      return JSON.parse(decoder.decode(new Uint8Array(wasm.memory.buffer,wasm.result_pointer(),wasm.result_length())));
    } finally {
      wasm.release(ptr,data.length);
      if(settings) wasm.release(extra,settings.length);
    }
  }
  return {
    profiles:(bytes,readout)=>invoke('analyze_file',bytes,{readout,profiles_only:true}),
    peaks:profile=>invoke('inspect_peaks',{profile,threshold:0}),
    regions:(profile,dividers,control_threshold,test_thresholds)=>invoke('measure_regions',{profile,dividers,control_threshold,test_thresholds}),
    summarize:(rows,options,metadata)=>invoke('batch_summary',{rows,options,metadata})
  };
}

export function validDividers(dividers, height, count) {
  return dividers.length===count && dividers.every(Number.isInteger) &&
    [0,...dividers,height].every((edge,i,edges)=>!i||edge-edges[i-1]>=3);
}

export function suggestDividers(peaks, count) {
  const ordered = peaks.slice().sort((a,b)=>b.prominence-a.prominence||a.location-b.location)
    .slice(0,count+1).sort((a,b)=>a.location-b.location);
  if (ordered.length!==count+1) return [];
  return ordered.slice(1).map((p,i)=>Math.floor((ordered[i].location+p.location)/2));
}

export function bestChannel(profiles) {
  let best=0, bestRange=-1;
  for (let channel=0; channel<3; channel++) {
    let min=Infinity,max=-Infinity;
    for (const value of profiles[channel]) {
      min=Math.min(min,value); max=Math.max(max,value);
    }
    if(max-min>bestRange){best=channel;bestRange=max-min;}
  }
  return best;
}
