export const lineLabel=(line,i)=>`T${i+1} — ${line.name.trim()||'Test line '+(i+1)}${line.units.trim()?' ('+line.units.trim()+')':''}`;
export const headers=lines=>['Filename','Replicate ID',...lines.map(lineLabel)];
export const csvText=rows=>rows.map(row=>row.map(value=>'"'+String(value??'').replaceAll('"','""')+'"').join(',')).join('\r\n');
// The UTF-8 signature lets spreadsheet apps recognize non-ASCII units and labels.
export const spreadsheetCSV=rows=>'\uFEFF'+csvText(rows);

export function parseCSV(text) {
  text=text.replace(/^\uFEFF/,'');
  const rows=[];
  let row=[],field='',quoted=false,closed=false;
  const finish=()=>{row.push(field);field='';closed=false;};
  for(let i=0;i<text.length;i++){
    const ch=text[i];
    if(quoted){
      if(ch!=='"') field+=ch;
      else if(text[i+1]==='"'){field+='"';i++;}
      else {quoted=false;closed=true;}
    }else if(ch===',') finish();
    else if(ch==='\r'||ch==='\n'){
      if(ch==='\r'&&text[i+1]==='\n')i++;
      finish();rows.push(row);row=[];
    }else if(ch==='"'&&!field&&!closed) quoted=true;
    else if(closed||ch==='"') throw Error('Invalid CSV quoting near row '+(rows.length+1)+'.');
    else field+=ch;
  }
  if(quoted)throw Error('The CSV ends inside a quoted cell.');
  if(field||closed||row.length){finish();rows.push(row);}
  while(rows.length&&rows.at(-1).length===1&&!rows.at(-1)[0])rows.pop();
  return rows;
}

export function validateCSV(text,files,lines) {
  const rows=parseCSV(text),expected=headers(lines);
  const head=rows.shift();
  if(JSON.stringify(head)!==JSON.stringify(expected))
    throw Error('CSV headers differ from the current template. Download a fresh template and keep its header row.');
  const names=new Set(files.map(file=>file.name)), data=new Map();
  for(const row of rows){
    const [name,replicate,...values]=row;
    if(row.length!==expected.length) throw Error('Wrong number of columns for '+(name||'a blank filename')+'.');
    if(!names.has(name))throw Error('Unexpected filename: '+name+'. Use the prefilled filenames.');
    if(data.has(name))throw Error('Duplicate CSV row for '+name+'.');
    if(!replicate.trim())throw Error('Enter a replicate ID for '+name+'.');
    const concentrations=values.map((value,i)=>{
      const cell=value.trim();
      if(!cell&&lines[i].settings.stage==='Image Analysis Only')return null;
      if(!/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(cell)||!Number.isFinite(Number(cell)))
        throw Error('Enter a non-negative decimal concentration for '+name+' in '+expected[i+2]+'.');
      const [whole,decimal='']=cell.split('.');
      const normalized=(whole.replace(/^0+(?=\d)/,'')||'0')+'.'+decimal.replace(/0+$/,'');
      return normalized.replace(/\.$/,'');
    });
    data.set(name,{replicate:replicate.trim(),concentrations});
  }
  for(const name of names)if(!data.has(name))throw Error('Missing CSV row for '+name+'.');
  return data;
}
