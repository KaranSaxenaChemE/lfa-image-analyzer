const names=['Red Channel','Green Channel','Blue Channel','Grayscale','Contrast-adjusted Grayscale'];
const colors=['#ff0000','#00ff00','#0000ff','#808080','#000000'];
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const start=(w,h,title)=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" font-family="Arial,Helvetica,sans-serif" font-size="12" role="img"><title>${esc(title)}</title><rect width="100%" height="100%" fill="white"/>`;
function line(v,x,y,offset=0){return v.map((n,i)=>`${i?'L':'M'}${x(i+1+offset).toFixed(3)} ${y(n).toFixed(3)}`).join('');}
function axes(left,top,right,bottom,xmin,xmax,ymax,labels=true,tickStep=null){
 const x=v=>left+(v-xmin)/(xmax-xmin)*(right-left),y=v=>bottom-v/ymax*(bottom-top);
 let s=`<path d="M${left} ${top}V${bottom}H${right}V${top}H${left}" fill="none" stroke="black" stroke-width=".6"/>`;
 const step=xmax>100?100:Math.max(1,Math.ceil(xmax/5));
 for(let v=Math.ceil(xmin/step)*step;v<=xmax;v+=step)s+=`<path d="M${x(v)} ${bottom}v-5" stroke="black" stroke-width=".6"/><text x="${x(v)}" y="${bottom+17}" text-anchor="middle">${v}</text>`;
 let ystep=tickStep??(ymax>180?50:ymax>100?20:ymax>40?10:ymax>10?5:1);
 for(let v=0;v<=ymax;v+=ystep)s+=`<path d="M${left} ${y(v)}h5" stroke="black" stroke-width=".6"/><text x="${left-7}" y="${y(v)+4}" text-anchor="end">${v}</text>`;
 if(labels)s+=`<text x="${(left+right)/2}" y="${bottom+37}" text-anchor="middle">pixel</text>`;
 s+=`<text transform="translate(${left-42} ${(top+bottom)/2}) rotate(-90)" text-anchor="middle">Intensity</text>`;
 return {x,y,s};
}
function legend(entries,left,top,width){
 let s=`<g class="figure-legend"><rect x="${left}" y="${top}" width="${width}" height="${entries.length*17+8}" fill="white" stroke="black" stroke-width=".6"/>`;
 entries.forEach((e,i)=>{const yy=top+14+i*17;s+=e.area?`<rect x="${left+5}" y="${yy-8}" width="33" height="9" fill="${e.color}" fill-opacity="${e.opacity}" stroke="black" stroke-width=".5"/>`:`<path d="M${left+5} ${yy-4}h33" stroke="${e.color}" stroke-width="${e.selected?2:1}"/>`;s+=`<text x="${left+44}" y="${yy}" font-size="11">${esc(e.label)}</text>`;});return s+'</g>';
}

export {names, colors, start, line, axes, legend, esc};
