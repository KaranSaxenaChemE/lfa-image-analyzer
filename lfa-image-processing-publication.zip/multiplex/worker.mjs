import {createMultiplexEngine} from './measure.mjs';

const engine = fetch('./multiplex.wasm').then(response=>{
  if(!response.ok)throw Error('The multiplex analysis engine could not be loaded.');
  return response.arrayBuffer();
}).then(createMultiplexEngine);
async function thumbnail(data) {
  const image = new OffscreenCanvas(data.width,data.height);
  image.getContext('2d').putImageData(new ImageData(
    Uint8ClampedArray.from({length:data.width*data.height*4},(_,i)=>i%4===3?255:data.rgb[i-Math.floor(i/4)]),
    data.width,data.height),0,0);
  const scale=Math.min(1,1400/data.height,180/data.width);
  const strip=new OffscreenCanvas(Math.max(1,Math.round(scale*data.height)),Math.max(1,Math.round(scale*data.width)));
  const context=strip.getContext('2d');
  context.setTransform(0,-strip.height/data.width,strip.width/data.height,0,0,strip.height);
  context.drawImage(image,0,0);
  const figures=[strip.convertToBlob({type:'image/png'})];
  const vertical=new OffscreenCanvas(Math.max(1,Math.round(180*data.width/data.height)),180);
  const verticalContext=vertical.getContext('2d');
  verticalContext.drawImage(image,0,0,vertical.width,vertical.height);
  figures.push(vertical.convertToBlob({type:'image/png'}));
  const recorded=image.getContext('2d').getImageData(0,0,data.width,data.height);
  const pixels=recorded.data;
  for(let channel=0;channel<5;channel++){
    for(let i=0; i<data.width*data.height; i++){
      const value=channel<3?data.rgb[i*3+channel]:channel===3?data.grayscale[i]:data.adjusted[i];
      pixels[i*4]=pixels[i*4+1]=pixels[i*4+2]=value;
    }
    image.getContext('2d').putImageData(recorded,0,0);
    verticalContext.drawImage(image,0,0,vertical.width,vertical.height);
    figures.push(vertical.convertToBlob({type:'image/png'}));
  }
  const [thumbnail,...channelImages]=await Promise.all(figures);
  return {thumbnail,channelImages};
}
onmessage=async({data:{id,method,args}})=>{
  try {
    const wasm=await engine;
    let result;
    if(method==='prepare'){
      const [bytes]=args;
      const data=wasm.profiles(bytes,2);
      if(data.error)throw Error(data.error);
      const detection=wasm.profiles(bytes,0);
      result={width:data.width,height:data.height,profiles:data.profiles,readout:detection.readout??0,
        ...await thumbnail(data)};
    }else if(method==='ready')result=true;
    else result=wasm[method](...args);
    if(result?.error)throw Error(result.error);
    postMessage({id,result});
  }catch(error){postMessage({id,error:error.message});}
};
