import {names,colors,start,line,axes,legend} from './batch-figure-base.mjs';

function parse(markup){
  const template=document.createElement('template');
  template.innerHTML=markup;
  return template.content.firstElementChild;
}

export function orientationFigure(lines) {
  const ns='http://www.w3.org/2000/svg';
  function node(name,attributes,text){
    const element=document.createElementNS(ns,name);
    for(const [key,value] of Object.entries(attributes))element.setAttribute(key,value);
    if(text!==undefined)element.textContent=text;
    return element;
  }
  const bands=[{y:103,labels:['Control Line']}];
  let y=393;
  for(const [i,line] of lines.entries()){
    const details=[line.name.trim(),line.units.trim()].filter(Boolean);
    const label='Test Line '+(i+1)+(details.length?' ('+details.join(', ')+')':'');
    const labels=label.match(/.{1,36}(?:\s|$)|.{1,36}/gu).map(part=>part.trim());
    bands.push({y,labels});
    y+=Math.max(72,labels.length*42+26);
  }
  const height=Math.max(525,y-16),width=Math.max(464,240+Math.max(...bands.flatMap(b=>b.labels.map(value=>value.length)))*21);
  const svg=node('svg',{xmlns:ns,viewBox:`0 0 ${width} ${height}`,width:width*145/525,height:height*145/525,
    role:'img','aria-label':'Correct LFA strip orientation for analysis','font-family':'Arial,Helvetica,sans-serif','font-size':37,'font-weight':400});
  svg.append(node('rect',{x:2.5,y:2.5,width:91,height:height-5,stroke:'#172C51','stroke-width':4.58333,fill:'#FFFFFF'}));
  for(const {y:position,labels} of bands){
    svg.append(node('rect',{x:2,y:position,width:91,height:31,fill:'#FF0000'}));
    svg.append(node('path',{d:'M219.421 120.219H107.833V116.781H219.421ZM107.833 118.5L117 127.666 89.5 118.5 117 109.333Z',
      transform:`translate(0 ${position-103})`,fill:'#0D0D0D'}));
    labels.forEach((label,i)=>svg.append(node('text',{x:229.25,y:position+29+i*42,fill:'#000000'},label)));
  }
  return svg;
}
export function profilePlot({profile,channelProfiles,lines,channel,method,selected}){
  const xmax=Math.ceil(profile.length/100)*100;
  const ymax=Math.max(1,...lines.map(p=>p?.height??0))+20;
  const chart=axes(75,35,520,285,0,xmax,ymax);
  let markup=start(560,337,'Image Profile Plots')+
    '<text x="298" y="26" text-anchor="middle" font-size="14" font-weight="bold">Image Profile Plots</text>'+chart.s;
  const entries=[];
  for(const [id,values] of channelProfiles){
    markup+=`<path d="${line(values,chart.x,chart.y)}" fill="none" stroke="${colors[id]}" stroke-width="1"/>`;
    entries.push({color:colors[id],label:names[id]});
  }
  if(method===0){
    markup+=`<path d="${line(profile,chart.x,chart.y)}" fill="none" stroke="${colors[channel]}" stroke-width="2"/>`;
    entries.push({color:colors[channel],label:'Best Channel for analysis',selected:true});
  }
  for(const i of selected===undefined?lines.keys():[0,selected]){
    const p=lines[i];if(!p)continue;
    markup+=`<text x="${chart.x(p.location)}" y="${chart.y(p.height+5)}" text-anchor="middle" font-weight="bold">${i?'Test Line '+i:'Control Line'}</text>`;
  }
  return parse(markup+legend(entries,325,40,195)+'</svg>');
}

const testAreaColors=[
  '#0072b2','#e69f00','#009e73','#d55e00','#8a57ad',
  '#56b4e9','#80602b','#556b2f','#c23b70','#545d69'
];

export function alignedPlot({profile,dividers,thumbnail,lines=[],selected,channel=4,readout,onEdit}) {
  const height=profile.length;
  const left=75,right=520,plotTop=62,plotBottom=184,stripTop=233,stripBottom=305;
  const topBar=34,bottomBar=310,barHeight=23,barYs=[topBar,bottomBar];
  const visibleLines=selected===undefined?[...lines.keys()]:[0,selected];
  const ymax=Math.max(1,profile.reduce((max,v)=>Math.max(max,v),0),
    ...visibleLines.map(i=>lines[i]?.height??0))+20;
  const {x,y,s}=axes(left,plotTop,right,plotBottom,1,height,ymax,false,ymax>100?50:ymax>40?20:ymax>10?5:1);
  const title=lines.length?'Profile Plot of the Best Channel':'Profile Plot of the Representative Strip';
  const shadingWidth=212, legendX=544;
  let markup=start(770,377,title)+`<text x="298" y="24" text-anchor="middle" font-size="14">${title}</text>`+s;
  markup+=`<path d="${line(profile,x,y)}" fill="none" stroke="${colors[channel]}" stroke-width="4"/>`;
  const entries=[];
  const projectors=[];
  for(const i of visibleLines){
    const peak=lines[i];
    const color=i?testAreaColors[i-1]:'#ff00ff',opacity=i?.45:.5;
    const label=i?'Test Line '+i:'Control Line';
    const area=peak?.area??0;
    entries.push({color,opacity,area:true,label:label+' Area = '+Number(area.toPrecision(6))});
    if(!peak?.integration)continue;
    const {bounds:[lo,hi],baseline}=peak.integration;
    const points=[];
    for(let j=lo;j<=hi;j++)points.push(`${x(j)},${y(Math.max(profile[j-1],baseline[j-lo]))}`);
    for(let j=hi;j>=lo;j--)points.push(`${x(j)},${y(baseline[j-lo])}`);
    markup+=`<polygon points="${points.join(' ')}" fill="${color}" fill-opacity="${opacity}"/><path d="M${x(lo)} ${y(baseline[0])}L${x(hi)} ${y(baseline.at(-1))}" fill="none" stroke="${color}" stroke-width="2"/>`;
    for(const [pixel,intensity] of [[lo,baseline[0]],[hi,baseline.at(-1)]]){
      const px=x(pixel),py=y(intensity);
      const stripPath=`M${px} ${stripTop}V${stripBottom}`;
      const backing=readout===2?`<path d="${stripPath}" stroke="white" stroke-width="3"/>`:'';
      projectors.push(backing+`<path d="M${px} ${plotBottom}V${py}${stripPath}" stroke="black" stroke-dasharray="6 4"/><circle cx="${px}" cy="${py}" r="3" fill="white" stroke="${color}" stroke-width="2"/>`);
    }
    markup+=`<text x="${x(peak.location)}" y="${Math.max(plotTop+4,y(peak.height+5))}" text-anchor="middle" font-weight="bold">${label}</text>`;
  }
  if(entries.length)markup+=legend(entries,legendX,41,shadingWidth);
  markup+='<text x="298" y="224" text-anchor="middle" font-size="13">Original LFA Image Aligned with Profile</text>';
  if(/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(thumbnail??''))markup+=`<image href="${thumbnail}" x="${left}" y="${stripTop}" width="${right-left}" height="${stripBottom-stripTop}" preserveAspectRatio="none"/>`;
  markup+=`<rect x="${left}" y="${stripTop}" width="${right-left}" height="${stripBottom-stripTop}" fill="none" stroke="black" stroke-width=".6"/>`;
  const tick=height>100?100:Math.max(1,Math.ceil(height/5));
  for(let v=tick;v<height;v+=tick)markup+=`<path d="M${x(v)} 338v-4" stroke="black" stroke-width=".6"/><text x="${x(v)}" y="351" text-anchor="middle">${v}</text>`;
  markup+='<text x="298" y="370" text-anchor="middle">Pixel</text>';
  markup+=`<g class="integration-bounds" visibility="hidden" pointer-events="none">${projectors.join('')}</g><g class="partition-lines">`;
  if(dividers.length){
    for(const [row,barY] of barYs.entries()){
      markup+=`<g class="partition-region-labels region-bar-${row?'bottom':'top'}" pointer-events="none"><rect x="${left}" y="${barY}" width="${right-left}" height="${barHeight}" fill="#eee" stroke="#b5b5b5"/>`;
      for(let i=0;i<=dividers.length;i++)markup+=`<text y="${barY+16}" text-anchor="middle" font-weight="bold" fill="#263746">${i?'T'+i:'C'}</text>`;
      markup+='</g>';
    }
  }
  markup+='</g>';
  const svg=parse(markup+'</svg>'),ns=svg.namespaceURI;
  svg.classList.add('multiplex-aligned-svg');
  const partitions=svg.querySelector('.partition-lines'),edges=[0,...dividers,height];
  const topLabels=[...partitions.querySelectorAll('.region-bar-top text')];
  const bottomLabels=[...partitions.querySelectorAll('.region-bar-bottom text')];
  function positionLabels(boundaries){
    const pixels=[left,...boundaries.map(v=>x(v+.5)),right];
    const spacing=24,padding=12;
    let next=left+padding;
    for(const [i,label] of topLabels.entries()){
      const center=(pixels[i]+pixels[i+1])/2;
      const latest=right-padding-(topLabels.length-i-1)*spacing;
      const labelX=Math.max(next,Math.min(center,latest));
      next=labelX+spacing;
      label.setAttribute('x',labelX);
      bottomLabels[i].setAttribute('x',labelX);
    }
  }
  positionLabels(dividers);
  for(const [i,divider] of dividers.entries()){
    const marker=x(divider+.5),visible=document.createElementNS(ns,'path');
    const segments=v=>`M${v} ${topBar}V${plotBottom}M${v} ${stripTop}V${bottomBar+barHeight}`;
    visible.setAttribute('d',segments(marker));
    visible.setAttribute('stroke','#0072bd');visible.setAttribute('stroke-width','3');
    partitions.append(visible);
    if(!onEdit)continue;
    const handle=visible.cloneNode();
    handle.setAttribute('stroke','transparent');handle.setAttribute('stroke-width','14');handle.setAttribute('class','divider-handle');
    const tip=document.createElementNS(ns,'title');tip.textContent='Drag divider '+(i+1)+' left or right';handle.append(tip);
    const grips=barYs.map((barY,row)=>{
      const grip=document.createElementNS(ns,'g');
      grip.setAttribute('class','divider-handle ruler-drag-handle');
      grip.setAttribute('transform',`translate(${marker} ${barY+barHeight/2})`);
      const shape=document.createElementNS(ns,'path');
      shape.setAttribute('d',row?'M-6 -1L0 -8L6 -1V7H-6Z M-6 2H6':'M-6 -7H6V-3L0 4L-6 -3Z');
      shape.setAttribute('fill','#fff');shape.setAttribute('stroke','#6c7074');
      shape.setAttribute('stroke-linejoin','round');
      grip.append(shape,tip.cloneNode(true));return grip;
    });
    const position=event=>{
      const point=new DOMPoint(event.clientX,event.clientY).matrixTransform(svg.getScreenCTM().inverse());
      return Math.max(edges[i]+3,Math.min(edges[i+2]-3,Math.round(.5+(point.x-left)/(right-left)*(height-1))));
    };
    function move(pixel){
      const v=x(pixel+.5);
      for(const node of [visible,handle])node.setAttribute('d',segments(v));
      grips.forEach((grip,row)=>grip.setAttribute('transform',`translate(${v} ${barYs[row]+barHeight/2})`));
      const draft=dividers.slice();draft[i]=pixel;
      positionLabels(draft);
    }
    for(const target of [handle,...grips]){
      target.addEventListener('pointerdown',event=>{event.preventDefault();target.setPointerCapture(event.pointerId);});
      target.addEventListener('pointermove',event=>{if(target.hasPointerCapture(event.pointerId))move(position(event));});
      target.addEventListener('pointerup',event=>{
        const pixel=position(event);
        move(onEdit(i,pixel)?pixel:divider);
      });
      target.addEventListener('pointercancel',()=>move(divider));
    }
    partitions.append(handle,...grips);
  }
  return svg;
}
