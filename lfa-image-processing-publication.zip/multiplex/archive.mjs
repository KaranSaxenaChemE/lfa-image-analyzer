const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', {fatal:true});
const crcTable = Uint32Array.from({length:256}, (_, i) => {
  for (let bit=0; bit<8; bit++) i = (i >>> 1) ^ ((i & 1) ? 0xedb88320 : 0);
  return i;
});
function crc(bytes) {
  let value = 0xffffffff;
  for (const byte of bytes) value = (value >>> 8) ^ crcTable[(value ^ byte) & 255];
  return (value ^ 0xffffffff) >>> 0;
}
const MAX_SIZE = 512 * 1024 * 1024;
const entryName = /^(experiment\.json|images\/[0-9]+)$/;

export function makeZip(entries) {
  let offset = 0, centralSize = 0;
  const local = [], central = [];
  for (const [path, bytes] of entries) {
    if (!entryName.test(path)) throw Error('Invalid experiment file entry.');
    const name = encoder.encode(path), checksum = crc(bytes);
    const header = new Uint8Array(30 + name.length), h = new DataView(header.buffer);
    h.setUint32(0,0x04034b50,true); h.setUint16(4,20,true); h.setUint16(12,33,true);
    h.setUint32(14,checksum,true); h.setUint32(18,bytes.length,true);
    h.setUint32(22,bytes.length,true); h.setUint16(26,name.length,true);
    header.set(name,30);
    const directory = new Uint8Array(46 + name.length), d = new DataView(directory.buffer);
    d.setUint32(0,0x02014b50,true); d.setUint16(4,20,true); d.setUint16(6,20,true);
    d.setUint16(14,33,true); d.setUint32(16,checksum,true); d.setUint32(20,bytes.length,true);
    d.setUint32(24,bytes.length,true); d.setUint16(28,name.length,true); d.setUint32(42,offset,true);
    directory.set(name,46);
    local.push(header,bytes); central.push(directory);
    offset += header.length + bytes.length;
    centralSize += directory.length;
  }
  if (offset + centralSize + 22 > MAX_SIZE || entries.size > 65535)
    throw Error('The experiment is too large for a local ZIP. Select fewer images.');
  const end = new Uint8Array(22), e = new DataView(end.buffer);
  e.setUint32(0,0x06054b50,true); e.setUint16(8,entries.size,true); e.setUint16(10,entries.size,true);
  e.setUint32(12,centralSize,true); e.setUint32(16,offset,true);
  return new Blob([...local,...central,end],{type:'application/zip'});
}

export async function openZip(file) {
  if (file.size < 22 || file.size > MAX_SIZE) throw Error('Invalid or oversized experiment ZIP.');
  const bytes = new Uint8Array(await file.arrayBuffer()), view = new DataView(bytes.buffer);
  const end = bytes.length - 22, count = view.getUint16(end+10,true);
  const directory = view.getUint32(end+16,true);
  if (view.getUint32(end,true)!==0x06054b50 || view.getUint32(end+4,true)!==0 ||
      count!==view.getUint16(end+8,true) || directory+view.getUint32(end+12,true)!==end)
    throw Error('Choose a ZIP saved by the Multiplex Notebook.');
  let cursor = 0, central = directory;
  const entries = new Map();
  for (let i=0; i<count; i++) {
    if (cursor+30>directory || central+46>end || view.getUint32(cursor,true)!==0x04034b50 ||
        view.getUint32(central,true)!==0x02014b50 || view.getUint16(cursor+6,true)!==0 ||
        view.getUint16(cursor+8,true)!==0) throw Error('Invalid experiment ZIP entry.');
    const size = view.getUint32(cursor+18,true), nameSize = view.getUint16(cursor+26,true);
    const start = cursor+30+nameSize;
    if (start+size>directory || central+46+nameSize>end || view.getUint16(central+28,true)!==nameSize ||
        view.getUint32(central+42,true)!==cursor || view.getUint32(central+20,true)!==size ||
        view.getUint32(cursor+22,true)!==size || view.getUint16(cursor+28,true)!==0)
      throw Error('Invalid experiment ZIP bounds.');
    const name = decoder.decode(bytes.subarray(cursor+30,start));
    const data = bytes.subarray(start,start+size);
    if (!entryName.test(name) || entries.has(name) ||
        name!==decoder.decode(bytes.subarray(central+46,central+46+nameSize)) ||
        crc(data)!==view.getUint32(cursor+14,true) ||
        view.getUint32(central+16,true)!==view.getUint32(cursor+14,true))
      throw Error('The experiment ZIP failed its integrity check.');
    entries.set(name,data);
    cursor = start+size; central += 46+nameSize;
  }
  if (cursor!==directory || central!==end || !entries.has('experiment.json'))
    throw Error('Experiment data is missing or invalid.');
  return entries;
}
