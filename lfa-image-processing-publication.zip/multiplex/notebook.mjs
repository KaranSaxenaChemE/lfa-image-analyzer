import {installFileDrop} from '../file-drop.mjs';
import {makeZip,openZip} from './archive.mjs';
import {csvText,parseCSV,spreadsheetCSV,headers,lineLabel,validateCSV} from './concentrations.mjs';
import {bestChannel,suggestDividers,validDividers} from './measure.mjs';
import {alignedPlot,profilePlot,orientationFigure} from './plots.mjs';
import {combinedReport,download,el,figureView,renderBatchResults,diagnosticImages,diagnosticOutput,sharedResultsTable} from './report.mjs';

const $=id=>document.getElementById(id);
const IMAGE='Image Analysis Only', FULL='Full Analysis through LoD';
const fields={
  readout:['LFA readout mode',[[0,'Auto-detect from first image'],[1,'Colorimetric'],[2,'Fluorescent/Chemiluminescent']]],
  method:['Image analysis method',[[0,'Automatic RGB (Best Channel)'],[1,'Contrast-Adjusted Grayscale'],[2,'Red Channel'],[3,'Green Channel'],[4,'Blue Channel'],[5,'Grayscale']]],
  control_threshold:['Control peak minimum prominence'],
  test_threshold:['Test peak minimum prominence'],
  diagnostics:['Diagnostic figures',['None','Aligned Profile Only','All']],
  stage:['Till which stage do you want to run the analysis?',[IMAGE,FULL]],
  signal:['Signal for analysis',[['(T/C)_area','Test/Control Area Ratio ((T/C)ₐᵣₑₐ)'],['T_area','Test Peak Area (Tₐᵣₑₐ)'],['T Prominence','Test Peak Prominence (Tprom)'],['T/C Prominence','Test/Control Prominence Ratio ((T/C)prom)']]],
  format:['LFA format',['Auto','Sandwich','Competitive']],
  model:['Curve-fitting model',[['logistic4','4-Parameter Logistic (4PL)'],['logistic5','5-Parameter Logistic (5PL)'],['hill','Hill'],['langmuir','Langmuir'],['linear','Linear'],['exp2','Two-Term Exponential']]],
  lod_method:['LoD method',[[1,'LoB + 1.6 × low-concentration SD'],[2,'Mean blank + 3 × blank SD']]]
};
const defaults={readout:0,method:0,control_threshold:1.5,test_threshold:1.5,diagnostics:'All',
  stage:IMAGE,signal:'(T/C)_area',format:'Auto',model:'logistic4',lod_method:2};
const calibrationKeys=new Set(['signal','format','model','lod_method']);
const sharedKeys=['readout','method','control_threshold','diagnostics','stage'];
const keys=Object.keys(fields).filter(key=>key!=='test_threshold');
const newLine=()=>({name:'',units:'',settings:{...defaults}});
const initialLineCount=Number($('line-count').defaultValue);
const empty=()=>({lines:Array.from({length:initialLineCount},newLine),notes:'',files:[],reference:'',
  dividers:[],confirmed:false,overrides:new Map(),csv:'',saved:Array(initialLineCount).fill(null),active:0,
  setupChannel:4,setupReadout:0,stale:[],excluded:[],cache:[],batch:null,order:[],
  shared:Object.fromEntries(sharedKeys.map(key=>[key,defaults[key]]))});
let state=empty(), referenceDraft=[], referenceDefaults=[], concentrationDraft=null, busy=false, ready=false;
const inputs=new Map();
const completedPanels=new Map(), statisticsTemplate=$('active-statistics').cloneNode(true);
const worker=new Worker('./worker.mjs',{type:'module'});
const requests=new Map();
let nextRequest=0;
function failWorker(error){
  for(const pending of requests.values())pending.reject(error);
  requests.clear();ready=false;message(error.message,true);sync();
}
worker.onerror=()=>failWorker(Error('The multiplex engine stopped. Reopen your latest saved experiment to continue.'));
worker.onmessage=({data})=>{
  const pending=requests.get(data.id);requests.delete(data.id);
  if(!pending)return;
  if(data.error)pending.reject(Error(data.error));else pending.resolve(data.result);
};
function call(method,...args){
  return new Promise((resolve,reject)=>{
    const id=++nextRequest;requests.set(id,{resolve,reject});worker.postMessage({id,method,args});
  });
}
function message(text,error=false,id='status'){
  $(id).textContent=text;$(id).classList.toggle('notice',error);
}
async function task(action){
  if(busy)return;
  busy=true;sync();
  try{await action();}
  catch(error){message(error.message,true);}
  finally{busy=false;sync();}
}
function option(value,label){
  const node=el('option',label);node.value=value;return node;
}
function activeRecord(){return state.saved[state.active]??state.cache[state.active];}
function invalidate(indices,{measurements=true}={}){
  if(measurements){state.batch=null;state.excluded=[];}
  state.order=state.order.filter(index=>!indices.includes(index));
  for(const i of indices){
    if(state.saved[i]){state.saved[i]=null;state.stale[i]=true;}
    if(measurements)state.cache[i]=null;
    else if(state.cache[i])state.cache[i]={...state.cache[i],summary:null,complete:false};
  }
}
function settingsFor(i){return {...state.lines[i].settings,...state.shared};}
function csvLines(){return state.lines.map((line,i)=>({...line,settings:settingsFor(i)}));}
function rowFor(measurement,i){
  const [control]=measurement.lines,test=measurement.lines[i+1];
  return {filename:measurement.name,T_area:test?.area??0,C_area:control?.area??0,T_prom:test?.prominence??0,C_prom:control?.prominence??0};
}
function lineMeasurements(i){
  return state.batch.measurements.map(m=>({...m,row:rowFor(m,i),
    status:m.controlMissing?m.status:m.lines[i+1]?'Measured':'Test line not detected'}));
}
function cacheFor(i){
  if(!state.batch)return null;
  return state.cache[i]??=( {index:i,settings:settingsFor(i),channel:state.batch.channel,readout:state.batch.readout,
    measurements:lineMeasurements(i),summary:null,complete:false} );
}
function allIndices(){return state.lines.map((_,i)=>i);}
function sameDividers(a,b){return a.length===b.length&&a.every((value,i)=>value===b[i]);}
function forceTemplateReview(){
  state.confirmed=false;state.dividers=[];state.overrides.clear();referenceDraft=[];referenceDefaults=[];
  $('attest').checked=false;invalidate(allIndices());
}
function invalidateCSV(){
  message(state.csv||concentrationDraft?'The template changed. Enter values in the new table or upload a matching CSV.':'',false,'csv-status');
  state.csv='';concentrationDraft=null;$('csv-file').value='';
}
function templateRows(){
  return [headers(state.lines),...state.files.map(({name})=>[name,'',...state.lines.map(()=>'')])];
}
function renderConcentrations(){
  const editing=$('edit-concentrations').checked;
  $('csv-import').hidden=editing;
  $('apply-concentrations').hidden=!editing;
  const [columns,...blankRows]=templateRows();
  const imported=new Map((state.csv?parseCSV(state.csv).slice(1):[]).map(row=>[row[0],row]));
  const rows=concentrationDraft??blankRows.map(row=>imported.get(row[0])??row);
  const table=$('concentration-table');table.replaceChildren();
  const header=table.createTHead().insertRow();
  for(const name of columns){
    const cell=el('th',name);cell.scope='col';header.append(cell);
  }
  const body=table.createTBody();
  for(const row of rows){
    const tr=body.insertRow(),filename=el('th',row[0]);
    filename.scope='row';tr.append(filename);
    for(let i=1;i<columns.length;i++){
      const cell=tr.insertCell();
      if(!editing){cell.textContent=row[i];continue;}
      const input=el('input');
      input.type='text';input.size=10;input.value=row[i];input.disabled=busy||!ready;
      if(i>1)input.inputMode='decimal';
      input.setAttribute('aria-label',columns[i]+' for '+row[0]);
      input.addEventListener('input',()=>{
        row[i]=input.value;concentrationDraft=rows;
        message('Apply table values to use these edits in the analysis.',false,'csv-status');
      });
      cell.append(input);
    }
  }
}
function sync(){
  const record=activeRecord(), saved=state.saved[state.active];
  const finished=state.saved.filter(Boolean).length;
  const remaining=state.lines.length-finished;
  const full=state.files.length>1&&state.shared.stage===FULL;
  const file=reference();
  const canConfirm=!!file&&validDividers(referenceDraft,file.height,state.lines.length);
  const confirmed=state.confirmed&&sameDividers(referenceDraft,state.dividers);
  $('csv-section').hidden=!full;
  $('reference').hidden=!state.files.length;
  $('run').disabled=busy||!ready||!confirmed;
  $('region-confirmation-needed').hidden=busy||!canConfirm||confirmed;
  $('refit').disabled=busy||!state.batch||!!saved||!full;
  $('save-line').disabled=busy||(full?(!!saved||!record?.complete):!canFinishImageOnly());
  $('save-line').hidden=!remaining||(full&&!!saved);
  $('save-line').textContent=!full?'Finish image analysis':remaining>1?'Select next analyte for analysis':'Finish analyte analysis';
  for(const id of ['save-html','save-pdf','save-html-top','save-pdf-top','download-project'])$(id).disabled=busy||!finished;
  $('download-project').disabled||=!confirmed;
  $('download-json').disabled=busy||!state.batch;
  $('save-controls').hidden=!state.batch;
  $('calibration-controls').hidden=!full;
  $('active-statistics').hidden=!!saved;
  $('selection').textContent=state.files.length?state.files.length+' image(s) selected.':'No images selected.';
  $('method-selection').textContent='Selected image analysis method: '+inputs.get('method').selectedOptions[0]?.textContent;
  for(const node of document.querySelectorAll('#lines input,#lines button,#add-line,#line-count,#test-thresholds input,#images,#folder,#open-project,#reference select,#reference-editor input,#analyte'))
    node.disabled=busy||(!ready&&node.id!=='open-project');
  $('attest').disabled=busy||!ready||!canConfirm;
  const referenceIndex=state.files.findIndex(file=>file.name===state.reference);
  $('reference-first').disabled=$('reference-previous').disabled=busy||referenceIndex<=0;
  $('reference-next').disabled=$('reference-last').disabled=busy||referenceIndex<0||referenceIndex>=state.files.length-1;
  for(const node of $('csv-section').querySelectorAll('input,button'))node.disabled=busy||!ready;
  for(const [key,node] of inputs)node.disabled=busy||(calibrationKeys.has(key)&&!!saved);
  for(const node of $('completed-analytes').querySelectorAll('select,.rerun-analyte'))node.disabled=busy;
  $('add-line').disabled=busy||state.lines.length>=10;
  for(const node of $('lines').querySelectorAll('button'))node.disabled=busy||state.lines.length<=1;
  if(state.files.length===1)inputs.get('stage').disabled=true;
  const picker=$('analyte'),[placeholder,...options]=picker.options;
  placeholder.textContent=remaining?'Select an analyte':'All analytes completed';
  for(const [i,item] of options.entries()){
    item.textContent=lineLabel(state.lines[i],i)+(state.saved[i]?' — Completed':state.stale[i]?' — Needs review':'');
    item.disabled=!!state.saved[i];
  }
  picker.disabled||=!remaining;
  picker.value=saved?'':String(state.active);
  $('progress').textContent=remaining?finished+' of '+state.lines.length+' Test lines completed.':'All Test lines are complete. Reopen a section to revise it or export the combined results below.';
}
function renderSetup(){
  if($('experiment-details').value!==state.notes)$('experiment-details').value=state.notes;
  $('lines').replaceChildren();
  $('line-count').value=state.lines.length;
  $('test-thresholds').replaceChildren();
  renderOrientation();
  state.lines.forEach((line,i)=>{
    const row=el('div',undefined,'line-row');row.append(el('strong','Test Line '+(i+1)));
    for(const [key,labelText] of [['name','Analyte name'],['units','Concentration unit']]){
      const label=el('label',labelText+' '),input=el('input');
      input.type='text';input.value=line[key];input.maxLength=120;input.setAttribute('aria-label','T'+(i+1)+' '+labelText);
      input.addEventListener('input',()=>{
        if(input.value===line[key])return;
        line[key]=input.value;renderOrientation();invalidateCSV();renderConcentrations();
        const affected=allIndices().filter(n=>n===i||state.shared.stage===FULL);
        invalidate(affected,{measurements:false});
        renderResults();sync();
      });
      label.append(input);row.append(label);
    }
    const remove=el('button','Delete Test Line '+(i+1));remove.type='button';
    remove.addEventListener('click',()=>{
      if(busy||state.lines.length<=1)return;
      forceTemplateReview();invalidateCSV();state.lines.splice(i,1);state.saved.splice(i,1);
      state.stale.splice(i,1);state.cache.splice(i,1);
      state.active=Math.min(state.active,state.lines.length-1);render();
      if(reference())task(suggestReferenceRegions);
    });
    row.append(remove);$('lines').append(row);
    const threshold=el('input');
    threshold.id='test-threshold-'+(i+1);threshold.type='number';threshold.min=0;threshold.step='any';
    threshold.required=true;threshold.value=line.settings.test_threshold;
    const label=el('label','Minimum Test Line '+(i+1)+' Peak Threshold Prominence ');
    label.append(threshold);$('test-thresholds').append(label);
    threshold.onchange=()=>{
      if(!threshold.checkValidity()){threshold.reportValidity();threshold.value=line.settings.test_threshold;return;}
      line.settings.test_threshold=threshold.valueAsNumber;invalidate(allIndices());renderResults();sync();
    };
  });
  const placeholder=option('','Select an analyte');placeholder.disabled=true;placeholder.hidden=true;
  $('analyte').replaceChildren(placeholder,...state.lines.map((line,i)=>option(i,lineLabel(line,i))));
  $('reference-file').replaceChildren(...state.files.map(file=>option(file.name,file.name)));
  $('reference-file').value=state.reference;
  $('setup-channel').value=state.setupChannel;
  $('setup-readout').value=state.setupReadout;
}
function renderOrientation(){$('orientation').replaceChildren(orientationFigure(state.lines));}
function renderSettings(){
  for(const key of keys){
    const input=$('setting-'+key);
    inputs.set(key,input);
    input.value=settingsFor(state.active)[key];
    input.onchange=()=>task(async()=>{
      const calibration=calibrationKeys.has(key);
      const settings=calibration?state.lines[state.active].settings:state.shared;
      if(!input.checkValidity()){input.reportValidity();input.value=settings[key];return;}
      settings[key]=typeof defaults[key]==='number'?Number(input.value):input.value;
      if(calibration){
        invalidate([state.active],{measurements:false});
        await refit();renderStatistics();
      }else if(key==='stage'){
        invalidate(allIndices(),{measurements:false});
        await refit();renderStatistics();
      }else{
        invalidate(allIndices());renderResults();
      }
    });
  }
}
async function prepareFiles(files){
  const sorted=[...files].filter(file=>/\.(?:jpe?g|png|tiff?)$/i.test(file.name)).sort((a,b)=>a.name<b.name?-1:a.name>b.name?1:0);
  if(!sorted.length)throw Error('Choose at least one JPG, PNG or TIFF image.');
  if(new Set(sorted.map(f=>f.name)).size!==sorted.length)throw Error('Each selected image must have a unique filename.');
  const prepared=[];
  for(const [i,file] of sorted.entries()){
    message('Reading image '+(i+1)+' of '+sorted.length+'…');
    const bytes=new Uint8Array(await file.arrayBuffer());
    let data;
    try{data=await call('prepare',bytes);}
    catch(error){throw Error(file.name+': '+error.message);}
    const first=prepared[0];
    if(first&&(first.width!==data.width||first.height!==data.height))
      throw Error(file.name+' has different dimensions. Use consistently cropped images.');
    const thumbnail=await dataURL(data.thumbnail);
    const channelImages=await Promise.all(data.channelImages.map(dataURL));
    prepared.push({...data,thumbnail,channelImages,name:file.name,bytes});
  }
  return prepared;
}
function dataURL(blob){
  return new Promise((resolve,reject)=>{
    const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('Could not prepare the strip preview.'));reader.readAsDataURL(blob);
  });
}
async function selectImages(files){
  const prepared=await prepareFiles(files);
  state.files=prepared;state.reference=prepared[0].name;
  if(prepared.length===1)state.shared.stage=IMAGE;
  forceTemplateReview();invalidateCSV();render();
  await suggestReferenceRegions();
  message(prepared.length+' image(s) ready. Select the representative strip and confirm its line regions.');
}
function reference(){return state.files.find(f=>f.name===state.reference);}
function profileOf(file,channel,readout){
  const values=file.profiles[channel];return readout===1?values.map(v=>255-v):values;
}
function referenceReadout(){return state.setupReadout||reference().readout;}
function editor({host,profile,image,dividers,selected,lines,channel,readout,changed,restoreDefaults,showOverlayKey=false}){
  const fineControlsOpen=host.querySelector('.divider-adjustments')?.open??false;
  const svg=alignedPlot({profile,thumbnail:image,dividers,lines,selected,channel,readout,onEdit:update});
  const figure=el('div',undefined,'aligned-editor-figure');
  figure.append(svg);
  if(showOverlayKey){
    const key=el('div',undefined,'aligned-overlay-key');
    key.setAttribute('role','group');key.setAttribute('aria-label','Aligned plot overlays');
    for(const [layer,text] of [
      ['integration-bounds','Integration bounds for the Control and Test peak areas under the curve'],
      ['partition-lines','Partition lines for Control and Test regions']
    ]){
      const label=el('label'),checkbox=el('input'),overlay=svg.querySelector('.'+layer);
      checkbox.type='checkbox';
      checkbox.checked=host.querySelector('.'+layer+'-toggle')?.checked??(layer==='partition-lines');
      checkbox.className=layer+'-toggle';
      checkbox.disabled=!overlay.childElementCount;
      const swatch=el('span',undefined,'overlay-swatch '+layer+'-swatch');swatch.setAttribute('aria-hidden','true');
      const sync=()=>overlay.setAttribute('visibility',checkbox.checked?'visible':'hidden');
      checkbox.addEventListener('change',sync);sync();
      label.append(checkbox,swatch,el('span',text));key.append(label);
    }
    figure.append(key);
  }
  host.replaceChildren(figure);
  if(restoreDefaults){
    const reset=el('button','Restore to default values','divider-reset');
    reset.type='button';
    reset.addEventListener('click',()=>{if(!busy)restoreDefaults();});
    host.append(reset);
  }
  const controls=el('div',undefined,'divider-fields'),height=profile.length;
  function update(i,value){
    if(busy)return;
    const candidate=dividers.slice();candidate[i]=value;
    if(!validDividers(candidate,height,state.lines.length)){message('Keep each region at least three pixels wide and in order.',true);return;}
    changed(candidate);
    return true;
  }
  dividers.forEach((value,i)=>{
    const label=el('label',(i===0?'C':'T'+i)+' / T'+(i+1)+' divider ');
    const input=el('input');input.type='number';input.min=(dividers[i-1]??0)+3;input.max=(dividers[i+1]??height)-3;
    input.step=1;input.required=true;input.value=value;input.setAttribute('aria-label','Divider '+(i+1)+' after pixel');
    input.addEventListener('change',()=>{
      if(input.checkValidity())update(i,input.valueAsNumber);
      else{input.reportValidity();input.value=value;}
    });
    label.append(input);controls.append(label);
  });
  if(dividers.length){
    const fineControls=el('details',undefined,'divider-adjustments');
    fineControls.open=fineControlsOpen;
    fineControls.append(el('summary','Fine-tune divider positions (pixels)'),controls);
    host.append(el('p','Drag a handle or blue divider to adjust the Control and Test regions. Place each divider between adjacent bands so every band stays fully inside its own region.','divider-help'),fineControls);
  }
}
function renderReference(){
  const file=reference(),host=$('reference-editor');
  if(!file||file.height<2){host.replaceChildren();return;}
  const readout=referenceReadout();
  const setDraft=next=>{
    referenceDraft=next;$('attest').checked=state.confirmed&&sameDividers(next,state.dividers);
    renderReference();sync();
  };
  editor({host,profile:profileOf(file,state.setupChannel,readout),image:file.thumbnail,
    dividers:referenceDraft,channel:state.setupChannel,readout,changed:setDraft,
    restoreDefaults:sameDividers(referenceDraft,referenceDefaults)?null:()=>setDraft([...referenceDefaults])});
}
async function referenceSuggestion(){
  const file=reference(),count=state.lines.length;
  if(!file||file.height<3*(count+1))return null;
  const readout=referenceReadout();
  const peaks=readout?suggestDividers(await call('peaks',profileOf(file,state.setupChannel,readout)),count):[];
  const suggested=validDividers(peaks,file.height,count);
  const evenlySpaced=()=>Array.from({length:count},(_,i)=>Math.floor((i+1)*file.height/(count+1)));
  return {dividers:suggested?peaks:evenlySpaced(),suggested,readout};
}
async function suggestReferenceRegions(){
  const suggestion=await referenceSuggestion();
  if(!suggestion){
    message('This image is too short for the configured number of regions.',true,'reference-message');
    return;
  }
  const {dividers,suggested,readout}=suggestion;
  referenceDefaults=dividers;referenceDraft=[...dividers];
  $('attest').checked=false;
  const explanation=readout?'The peaks could not be separated automatically.':'Automatic readout is inconclusive. You can select a readout under Advanced representative-strip setup.';
  message(suggested?'Regions suggested automatically. Check the divider positions, then confirm.':
    explanation+' The dividers start evenly spaced. Drag them to mark the correct regions, then confirm.',false,'reference-message');
  renderReference();
}
function csvData(){return validateCSV(state.csv,state.files,csvLines());}
function canFinishImageOnly(){return !!state.batch&&!state.batch.measurements.some(m=>m.controlMissing&&!state.excluded.includes(m.name));}
async function measureFile(file,batch){
  const {readout,channel}=batch,settings=state.shared;
  const dividers=state.overrides.get(file.name)??state.dividers;
  const profile=profileOf(file,channel,readout);
  const measured=await call('regions',profile,dividers,settings.control_threshold,state.lines.map(line=>line.settings.test_threshold));
  const controlMissing=!measured.lines[0];
  const channels=settings.method===0?[0,1,2]:channel===4?[3,4]:[channel];
  return {name:file.name,profile,dividers:[...dividers],thumbnail:file.thumbnail,lines:measured.lines.map(p=>p?{...p,height:profile[p.location-1]}:null),
    channel,readout,method:settings.method,channelImages:file.channelImages,controlMissing,
    status:controlMissing?'Control line not detected. Review the regions.':'Measured',
    channelProfiles:settings.diagnostics==='All'?channels.map(c=>[c,profileOf(file,c,readout)]):[]};
}
async function fitStatistics(record,i){
  const line=state.lines[i];
  const waiting=!canFinishImageOnly();
  record.complete=!waiting;record.summary=null;
  if(state.shared.stage!==FULL)return;
  const valid=record.measurements.filter(m=>!m.controlMissing);
  record.complete=false;
  if(waiting){record.summary={error:'Review the strips with undetected Control lines before calibration.'};return;}
  if(!valid.length){record.summary={error:'No strips with a detected Control line remain for calibration.'};return;}
  if(!state.csv){record.summary={error:'Apply the concentration table values or upload a completed CSV to run calibration.'};return;}
  try{
    const data=csvData();
    const meta=valid.map(m=>{const row=data.get(m.name);return [row.concentrations[i],row.replicate];});
    record.summary=await call('summarize',valid.map(m=>m.row),{...record.settings,units:line.units},meta);
    record.complete=!!record.summary.fit&&!record.summary.calibration_error;
  }catch(error){record.summary={error:error.message};}
}
async function refit(){
  const i=state.active;
  if(state.saved[i])return;
  const record=cacheFor(i);
  if(!record)return;
  record.settings=settingsFor(i);
  await fitStatistics(record,i);
}
async function run(){
  const settings=state.shared;
  const readout=settings.readout||state.files[0].readout;
  if(!readout)throw Error('Automatic readout is inconclusive for the first image. Select the readout mode manually.');
  const channel=settings.method===0?bestChannel(reference().profiles):[null,4,0,1,2,3][settings.method];
  const batch={channel,readout,measurements:[]};
  for(const [index,file] of state.files.entries()){
    message('Analysing image '+(index+1)+' of '+state.files.length+'…');
    batch.measurements.push(await measureFile(file,batch));
  }
  state.batch=batch;state.cache=[];
  for(const m of batch.measurements)if(m.controlMissing&&state.excluded.includes(m.name))m.status='Excluded after review: Control line not detected';
  await refit();renderResults();
  $('run-information').textContent='Last run: '+new Date().toLocaleString()+'\nImages processed: '+state.files.length;
  message('Measurements for all Test lines are ready. Review the results and any flagged strips.');
  $('results').scrollIntoView({block:'start'});
}
function renderCompletedAnalyte(panel,i,record){
  const line=state.lines[i],fit=record.summary?.fit;
  const model=fields.model[1].find(([value])=>value===record.settings.model)?.[1];
  const lod=fit?.lod_error||fit?.lod_display===undefined?'LoD unavailable':'LoD '+fit.lod_display+(line.units?' '+line.units:'');
  panel.querySelector('summary').textContent=lineLabel(line,i)+' · '+model+' · '+lod;
  renderBatchResults(record,line,i,'-completed-'+i);
}
function addCompletedAnalyte(i){
  const panel=el('details',undefined,'completed-analyte'),summary=el('summary');
  const body=statisticsTemplate.cloneNode(true),suffix='-completed-'+i;
  body.id='statistics'+suffix;
  const controls=new Map();
  for(const node of body.querySelectorAll('[id]')){
    controls.set(node.id,node);
    node.id+=suffix;
  }
  const status=el('p','', 'analyte-edit-status');status.setAttribute('role','status');
  const rerun=controls.get('refit');
  rerun.textContent='Recalculate this analyte';rerun.classList.add('rerun-analyte');
  rerun.parentElement.after(status);
  const selects=[...calibrationKeys].map(key=>[key,controls.get('setting-'+key)]);
  for(const [key,input] of selects){
    input.value=state.saved[i].settings[key];
    input.addEventListener('change',()=>{status.textContent='Recalculate this analyte to apply your changes.';});
  }
  rerun.addEventListener('click',()=>task(async()=>{
    const previous=state.saved[i];
    const settings={...previous.settings};
    for(const [key,input] of selects)settings[key]=typeof defaults[key]==='number'?Number(input.value):input.value;
    const revised={...previous,settings};
    await fitStatistics(revised,i);
    if(!revised.complete){
      status.textContent=(revised.summary?.error??revised.summary?.calibration_error??'Could not calculate the revised analysis.')+' The previous results are still shown and will be exported.';
      return;
    }
    state.saved[i]=revised;
    for(const key of calibrationKeys)state.lines[i].settings[key]=settings[key];
    renderCompletedAnalyte(panel,i,revised);
    status.textContent='Updated results for Test line '+(i+1)+'.';
  }));
  panel.append(summary,body);$('completed-analytes').append(panel);
  completedPanels.set(i,panel);renderCompletedAnalyte(panel,i,state.saved[i]);
}
function renderStatistics(){
  const desired=state.shared.stage===FULL?state.order:[];
  for(const [i,panel] of completedPanels){
    if(desired.includes(i))continue;
    panel.remove();completedPanels.delete(i);
  }
  for(const i of desired)if(!completedPanels.has(i))addCompletedAnalyte(i);
  renderBatchResults(activeRecord(),state.lines[state.active],state.active);
}
function renderResults(reopen){
  const batch=state.batch;
  $('results').hidden=!batch;
  renderStatistics();
  if(!batch)return;
  $('results-title').textContent='Individual image processing results';
  $('summary').replaceChildren(sharedResultsTable(batch,state.lines));
  const container=$('strip-results');container.replaceChildren();
  for(const [measurementIndex,measurement] of batch.measurements.entries()){
    let m=measurement;
    const details=el('details',undefined,'strip-result image-result'),body=el('div');
    const summary=el('summary');
    const stripStatus=el('span',m.status);
    const heading=el('h3','============================================================\nANALYSING LFA IMAGE: '+m.name+'\n============================================================');
    summary.append(heading,stripStatus);details.append(summary,body);
    const graph=el('div',undefined,'plot multiplex-aligned');
    const updateRegions=next=>task(async()=>{
      if(sameDividers(next,m.dividers))return;
      const file=state.files.find(f=>f.name===m.name),previous=state.overrides.get(m.name);
      if(sameDividers(next,state.dividers))state.overrides.delete(m.name);
      else state.overrides.set(m.name,[...next]);
      try{m=await measureFile(file,batch);}
      catch(error){
        if(previous)state.overrides.set(m.name,previous);else state.overrides.delete(m.name);
        body.replaceChildren();paint();throw error;
      }
      batch.measurements[measurementIndex]=m;
      state.excluded=state.excluded.filter(name=>name!==m.name);
      stripStatus.textContent=m.status;
      body.replaceChildren();paint();
      $('summary').replaceChildren(sharedResultsTable(batch,state.lines));
      const completed=state.order.slice();
      const finishedImageOnly=state.shared.stage===IMAGE&&state.saved.every(Boolean);
      invalidate(allIndices(),{measurements:false});state.cache=[];
      await refit();
      for(const i of completed){
        const record=cacheFor(i);
        if(i!==state.active)await fitStatistics(record,i);
        if(!record.complete)continue;
        state.saved[i]=record;state.stale[i]=false;state.order.push(i);
        const panel=completedPanels.get(i);
        if(panel)renderCompletedAnalyte(panel,i,record);
      }
      if(finishedImageOnly&&canFinishImageOnly())
        for(const i of allIndices()){state.saved[i]={...cacheFor(i),complete:true};state.stale[i]=false;}
      renderStatistics();message('Regions updated for '+m.name+' across all Test lines.');
    });
    const paint=()=>{
      if(body.childElementCount)return;
      const [peaks,areas,outputs]=diagnosticOutput(m,state.lines);
      if(state.shared.diagnostics==='All')body.append(diagnosticImages(m));
      if(state.shared.method===0){
        const decision=el('p');
        decision.append(el('strong',['Red Channel','Green Channel','Blue Channel'][batch.channel]),' is the best channel for further analysis');
        body.append(decision);
      }
      body.append(peaks);
      if(state.shared.diagnostics==='All')body.append(figureView(profilePlot(m),m.name+'-profiles'));
      body.append(areas);
      body.append(graph);
      editor({host:graph,profile:m.profile,image:m.thumbnail,dividers:m.dividers,channel:m.channel,readout:m.readout,showOverlayKey:true,
        lines:m.lines,changed:updateRegions,
        restoreDefaults:sameDividers(m.dividers,state.dividers)?null:()=>updateRegions(state.dividers)});
      if(m.controlMissing){
        const exclude=el('button',state.excluded.includes(m.name)?'Undo reviewed exclusion':'Confirm Control missing and exclude strip');
        exclude.addEventListener('click',()=>task(async()=>{
          const names=new Set(state.excluded);
          if(names.has(m.name))names.delete(m.name);else names.add(m.name);
          state.excluded=[...names];
          m.status=names.has(m.name)?'Excluded after review: Control line not detected':'Control line not detected. Review the regions.';
          invalidate(allIndices(),{measurements:false});state.cache=[];
          await refit();renderResults(m.name);
        }));
        body.append(el('p','Check that the Control and Test regions bracket the correct lines.','notice'),exclude);
      }
      body.append(figureView(alignedPlot(m),m.name+'-aligned').lastChild,outputs);
    };
    details.addEventListener('toggle',()=>{if(details.open)paint();});
    if(m.name===reopen||state.shared.diagnostics!=='None'||(m.controlMissing&&!state.excluded.includes(m.name))){
      details.open=true;paint();
    }
    container.append(details);
  }
}
function project(nextSaved){
  const files=state.files.map(({name})=>name);
  const next=state.lines.findIndex((_,i)=>!nextSaved[i]);
  const record={schema:'lfa2lod-multiplex',version:2,files,lines:state.lines,shared:state.shared,notes:state.notes,
    reference:state.reference,dividers:state.dividers,confirmed:state.confirmed,overrides:[...state.overrides],
    csv:state.csv,saved:nextSaved.map(item=>item?{...item,measurements:item.measurements.map(
      ({profile,thumbnail,channelProfiles,channelImages,...measurement})=>measurement)}:null),
    stale:state.stale.map((v,i)=>nextSaved[i]?false:v),excluded:state.excluded,order:state.order,
    next:next<0?state.active:next,setupChannel:state.setupChannel,setupReadout:state.setupReadout};
  const entries=new Map([['experiment.json',new TextEncoder().encode(JSON.stringify(record))]]);
  state.files.forEach((file,i)=>entries.set('images/'+i,file.bytes));
  return makeZip(entries);
}
function completeAnalysis(){
  const i=state.active,record=activeRecord();
  const imageOnly=state.shared.stage===IMAGE;
  if(busy||(imageOnly?!canFinishImageOnly():!record?.complete||state.saved[i]))return;
  if(imageOnly)for(const index of allIndices())state.saved[index]={...cacheFor(index),complete:true};
  else{state.saved[i]=record;state.order.push(i);}
  for(const index of allIndices())if(state.saved[index])state.stale[index]=false;
  renderStatistics();sync();
  if(state.saved.every(Boolean)){
    $('report').scrollIntoView({block:'start'});
    $('save-pdf').focus({preventScroll:true});
  }else{
    $('analyte-section').scrollIntoView({block:'start'});
    $('analyte').focus({preventScroll:true});
  }
}
function validSettings(settings){
  return settings&&Object.entries(fields).every(([key,[,choices]])=>choices?
    choices.some(choice=>(Array.isArray(choice)?choice[0]:choice)===settings[key]):
    Number.isFinite(settings[key])&&settings[key]>=0);
}
function validateSavedRecord(record,i,files,count){
  if(!record||record.index!==i||record.complete!==true||!validSettings(record.settings)||
    ![0,1,2,3,4].includes(record.channel)||![1,2].includes(record.readout)||
    !Array.isArray(record.measurements)||record.measurements.length!==files.length)throw Error('Saved results are incomplete.');
  for(const [j,item] of record.measurements.entries()){
    const file=files[j];
    if(item.name!==file.name||item.row?.filename!==file.name||typeof item.status!=='string'||
      typeof item.controlMissing!=='boolean'||!Array.isArray(item.dividers)||!validDividers(item.dividers,file.height,count)||
      !Array.isArray(item.lines)||item.lines.length!==count+1||
      !['T_area','C_area','T_prom','C_prom'].every(key=>Number.isFinite(item.row[key])))
      throw Error('Saved strip measurements are invalid.');
    for(const line of item.lines)if(line!==null){
      const bounds=line.integration?.bounds;
      if(!Array.isArray(bounds)||bounds.length!==2||!bounds.every(Number.isInteger)||bounds[0]<1||
        bounds[1]>file.height||bounds[1]<=bounds[0]||!Array.isArray(line.integration.baseline)||
        line.integration.baseline.length!==bounds[1]-bounds[0]+1||!line.integration.baseline.every(Number.isFinite))
        throw Error('Saved peak bounds are invalid.');
    }
    item.profile=profileOf(file,record.channel,record.readout);item.thumbnail=file.thumbnail;item.channelImages=file.channelImages;
    const channels=record.settings.method===0?[0,1,2]:record.channel===4?[3,4]:[record.channel];
    item.channelProfiles=record.settings.diagnostics==='All'?channels.map(c=>[c,profileOf(file,c,record.readout)]):[];
  }
}
async function restore(file){
  const entries=await openZip(file),record=JSON.parse(new TextDecoder().decode(entries.get('experiment.json')));
  if(record.schema!=='lfa2lod-multiplex'||![1,2].includes(record.version))throw Error('This experiment file version is unsupported.');
  if(!Array.isArray(record.files)||!record.files.length||entries.size!==record.files.length+1||
     !record.files.every(name=>typeof name==='string'&&/^[^\x00-\x1f\\/]+\.(?:jpe?g|png|tiff?)$/i.test(name))||
     !Array.isArray(record.lines)||!record.lines.length||record.lines.length>10||!record.lines.every(line=>typeof line.name==='string'&&typeof line.units==='string'&&validSettings(line.settings))||
     !Array.isArray(record.saved)||record.saved.length!==record.lines.length||typeof record.notes!=='string'||
     !Array.isArray(record.dividers)||!Array.isArray(record.overrides)||!Array.isArray(record.stale)||(record.version===2&&(!Array.isArray(record.excluded)||!validSettings({...defaults,...record.shared})||!sharedKeys.every(key=>Object.hasOwn(record.shared??{},key))))||
     typeof record.csv!=='string'||record.confirmed!==true||
     ![0,1,2,4].includes(record.setupChannel)||![0,1,2].includes(record.setupReadout))
    throw Error('Experiment setup is incomplete or invalid.');
  const files=await prepareFiles(record.files.map((name,i)=>{
    const bytes=entries.get('images/'+i);if(!bytes?.length)throw Error('The ZIP is missing '+name+'.');
    return new File([bytes],name);
  }));
  const ref=files.find(f=>f.name===record.reference),count=record.lines.length;
  if(!ref||!validDividers(record.dividers,ref.height,count))throw Error('The saved representative strip or dividers are invalid.');
  const overrides=new Map();
  for(const pair of record.overrides){
    if(!Array.isArray(pair)||pair.length!==2||!files.some(f=>f.name===pair[0])||overrides.has(pair[0])||
      !Array.isArray(pair[1])||!validDividers(pair[1],ref.height,count))throw Error('An individual strip override is invalid.');
    overrides.set(...pair);
  }
  const legacy=record.version===1;
  const shared=Object.fromEntries(sharedKeys.map(key=>[key,legacy?record.lines[0].settings[key]:record.shared[key]]));
  if(files.length===1)shared.stage=IMAGE;
  if(record.csv)validateCSV(record.csv,files,record.lines.map(line=>({...line,settings:{...line.settings,stage:IMAGE}})));
  if(!legacy)record.saved.forEach((saved,i)=>{if(saved!==null)validateSavedRecord(saved,i,files,count);});
  const saved=legacy?Array(count).fill(null):record.saved;
  const order=[...new Set([...(Array.isArray(record.order)?record.order:[]),...saved.keys()])]
    .filter(i=>Number.isInteger(i)&&saved[i]);
  const first=saved.find(Boolean);
  const next=saved.findIndex(item=>!item);
  const batch=first?{channel:first.channel,readout:first.readout,measurements:first.measurements.map(m=>({
    ...m,status:m.controlMissing?m.status:'Measured'
  }))}:null;
  for(const panel of completedPanels.values())panel.remove();
  completedPanels.clear();
  state={...record,files,overrides,shared,saved,batch,order,active:next<0?count-1:next,cache:[],
    stale:legacy?record.saved.map(Boolean):record.stale,
    excluded:legacy?[]:record.excluded.filter(name=>files.some(f=>f.name===name))};

  referenceDraft=[...state.dividers];
  referenceDefaults=(await referenceSuggestion())?.dividers??referenceDraft;
  $('attest').checked=true;
  $('images').value='';$('folder').value='';$('csv-file').value='';
  concentrationDraft=null;
  message(state.csv?'Concentrations restored from the saved experiment.':'',false,'csv-status');
  await refit();render();message(legacy?'Saved experiment opened. Run shared image analysis to update the previous results.':'Saved experiment opened. '+state.saved.filter(Boolean).length+' Test line(s) already saved.');
}
function importCsv(file){
  return task(async()=>{
    if(!file||$('csv-section').hidden||$('edit-concentrations').checked)return;
    if(!/\.csv$/i.test(file.name)){message('Choose the completed concentration CSV.',true,'csv-status');return;}
    await applyConcentrations(await file.text());
  });
}
async function applyConcentrations(text){
  let data;
  try{data=validateCSV(text,state.files,csvLines());}
  catch(error){message(error.message,true,'csv-status');return;}
  const previous=state.csv?validateCSV(state.csv,state.files,state.lines.map(line=>({...line,settings:{...line.settings,stage:IMAGE}}))):null;
  const affected=allIndices().filter(i=>state.files.some(({name})=>{
    const a=data.get(name),b=previous?.get(name);
    return a.replicate!==b?.replicate||a.concentrations[i]!==b?.concentrations[i];
  }));
  state.csv=text;concentrationDraft=null;invalidate(affected,{measurements:false});
  renderConcentrations();
  message('Concentrations loaded for '+data.size+' images.',false,'csv-status');
  await refit();renderStatistics();
}
function render(){
  renderSetup();renderSettings();renderReference();renderConcentrations();renderResults();sync();
}

$('experiment-details').addEventListener('input',()=>{state.notes=$('experiment-details').value;});
function setLineCount(count){
  if(!Number.isInteger(count)||count<1||count>10||busy)return;
  if(count===state.lines.length)return;
  forceTemplateReview();invalidateCSV();
  while(state.lines.length<count){state.lines.push(newLine());state.saved.push(null);}
  state.lines.length=state.saved.length=count;
  state.stale=state.stale.slice(0,count);state.cache=[];
  state.active=Math.min(state.active,count-1);render();
  if(reference())task(suggestReferenceRegions);
}
$('add-line').onclick=()=>setLineCount(state.lines.length+1);
$('line-count').onchange=event=>{
  const input=event.target;
  if(!input.checkValidity()){input.reportValidity();input.value=state.lines.length;return;}
  setLineCount(input.valueAsNumber);
};
installFileDrop({zone:$('image-drop'),input:$('images'),relatedInputs:[$('folder')],message:$('image-message'),
  multiple:true,isEnabled:()=>ready&&!busy,onFiles:files=>task(()=>selectImages(files)),stateElement:$('run')});
for(const id of ['images','folder'])$(id).addEventListener('change',event=>{
  const files=[...event.currentTarget.files];if(files.length)task(()=>selectImages(files));
});
$('open-project').addEventListener('change',event=>{const file=event.target.files[0];event.target.value='';if(file)task(()=>restore(file));});
function selectReference(name){
  if(!name||name===state.reference)return;
  return task(async()=>{
    state.reference=name;forceTemplateReview();render();await suggestReferenceRegions();
  });
}
$('reference-file').addEventListener('change',event=>selectReference(event.target.value));
for(const [direction,targetIndex] of [
  ['first',()=>0],['previous',index=>index-1],
  ['next',index=>index+1],['last',()=>state.files.length-1]
]){
  $('reference-'+direction).addEventListener('click',()=>{
    const index=state.files.findIndex(file=>file.name===state.reference);
    selectReference(state.files[targetIndex(index)]?.name);
  });
}
for(const [id,key] of [['setup-channel','setupChannel'],['setup-readout','setupReadout']])$(id).addEventListener('change',()=>task(async()=>{
  state[key]=Number($(id).value);forceTemplateReview();render();await suggestReferenceRegions();
}));
$('attest').addEventListener('change',event=>{
  if(!event.target.checked){
    state.confirmed=false;
    message('Regions need confirmation.',false,'reference-message');
    sync();return;
  }
  const changed=!sameDividers(state.dividers,referenceDraft);
  if(changed){invalidate(allIndices());state.overrides.clear();}
  state.dividers=[...referenceDraft];state.confirmed=true;
  if(changed)renderResults();
  message('Regions confirmed. Run image analysis for all Test lines.');message('Regions confirmed.',false,'reference-message');
  sync();
});
$('go-to-region-confirmation').addEventListener('click',event=>{
  event.preventDefault();
  $('attest').scrollIntoView({block:'center'});$('attest').focus({preventScroll:true});
});
$('analyte').addEventListener('change',event=>{
  const next=Number(event.target.value);
  task(async()=>{
    if(!state.lines[next]||state.saved[next])return;
    state.active=next;renderSettings();await refit();renderStatistics();
  });
});
$('template').addEventListener('click',()=>download(spreadsheetCSV(templateRows()),'multiplex-concentrations.csv','text/csv;charset=utf-8'));
$('edit-concentrations').addEventListener('change',renderConcentrations);
$('apply-concentrations').addEventListener('click',()=>task(async()=>{
  if($('csv-section').hidden||!$('edit-concentrations').checked)return;
  if(concentrationDraft)await applyConcentrations(csvText([headers(state.lines),...concentrationDraft]));
  else if(!state.csv)await applyConcentrations(csvText(templateRows()));
}));
$('csv-file').addEventListener('change',event=>{const file=event.target.files[0];event.target.value='';importCsv(file);});
const drop=$('csv-drop');
drop.addEventListener('click',()=>{if(!busy)$('csv-file').click();});
drop.addEventListener('keydown',event=>{if(['Enter',' '].includes(event.key)){event.preventDefault();drop.click();}});
drop.addEventListener('dragover',event=>{event.preventDefault();if(!busy)drop.classList.add('drag-active');});
drop.addEventListener('dragleave',()=>drop.classList.remove('drag-active'));
drop.addEventListener('drop',event=>{
  event.preventDefault();event.stopPropagation();drop.classList.remove('drag-active');
  if(event.dataTransfer.files.length===1)importCsv(event.dataTransfer.files[0]);
  else message('Drop one completed concentration CSV.',true,'csv-status');
});
$('run').addEventListener('click',()=>task(run));
$('refit').addEventListener('click',()=>task(async()=>{await refit();renderStatistics();}));
$('save-line').addEventListener('click',completeAnalysis);
$('download-project').addEventListener('click',()=>task(()=>download(project(state.saved),'LFA2LoD-multiplex-experiment.zip','application/zip')));
$('download-json').addEventListener('click',()=>download(JSON.stringify({settings:state.shared,channel:state.batch.channel,readout:state.batch.readout,lines:state.lines,measurements:state.batch.measurements.map(m=>({filename:m.name,status:m.status,dividers:m.dividers,lines:m.lines})),statistics:activeRecord()?.summary},null,2),'multiplex-results.json','application/json'));
for(const id of ['save-html','save-html-top'])$(id).addEventListener('click',()=>task(async()=>download(await combinedReport(state),'LFA2LoD-multiplex-report.html','text/html;charset=utf-8')));
for(const id of ['save-pdf','save-pdf-top'])$(id).addEventListener('click',async()=>{
  const printWindow=window.open('','_blank');
  if(!printWindow){message('Allow the report window to open, or download the HTML and print it.',true);return;}
  try{
    const html=await combinedReport(state,{forPrint:true});
    printWindow.document.open();printWindow.document.write(html);printWindow.document.close();
    printWindow.print();
  }catch(error){printWindow.close();message(error.message,true);}
});
render();
call('ready').then(()=>{ready=true;message('Engine ready. Define the Test lines and select images.');sync();}).catch(failWorker);
