// Notebook figures copied from the verified single-image presentation.
let result;
const names=['Red Channel','Green Channel','Blue Channel','Grayscale','Contrast-adjusted Grayscale'];
const colors=['#ff0000','#00ff00','#0000ff','#808080','#000000'];
// Match the single notebook: show only diagnostics relevant to the method.
export function diagnosticChannels(value){
 return value.method===0?[0,1,2]:value.method===1?[3,4]:[value.channel];
}
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
function canvas(rgb,w,h,plane=null,transpose=false){
 const c=document.createElement('canvas');c.width=transpose?h:w;c.height=transpose?w:h;
 const ctx=c.getContext('2d'),image=ctx.createImageData(c.width,c.height);
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const a=(y*w+x)*3,b=(transpose?x*h+y:y*w+x)*4;for(let k=0;k<3;k++)image.data[b+k]=plane===null?rgb[a+k]:typeof plane==='number'?rgb[a+plane]:plane[y*w+x];image.data[b+3]=255;}
 ctx.putImageData(image,0,0);return c;
}
const start=(w,h,title)=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" font-family="Arial,Helvetica,sans-serif" font-size="12" role="img"><title>${esc(title)}</title><rect width="100%" height="100%" fill="white"/>`;
function line(v,x,y,offset=0){return v.map((n,i)=>`${i?'L':'M'}${x(i+1+offset).toFixed(3)} ${y(n).toFixed(3)}`).join('');}
function axes(left,top,right,bottom,xmin,xmax,ymax,labels=true,tickStep=null){
 const x=v=>left+(v-xmin)/(xmax-xmin)*(right-left),y=v=>bottom-v/ymax*(bottom-top);
 let s=`<path d="M${left} ${top}V${bottom}H${right}V${top}H${left}" fill="none" stroke="black" stroke-width=".6"/>`;
 const step=xmax>100?100:Math.max(1,Math.ceil(xmax/5));
 for(let v=Math.ceil(xmin/step)*step;v<=xmax;v+=step)s+=`<path d="M${x(v)} ${bottom}v-5" stroke="black" stroke-width=".6"/><text x="${x(v)}" y="${bottom+17}" text-anchor="middle">${v}</text>`;
 let ystep=tickStep??(ymax>180?50:ymax>100?20:ymax>40?10:ymax>10?5:1);
 for(let v=0;v<=ymax;v+=ystep)s+=`<path d="M${left} ${y(v)}h5" stroke="black" stroke-width=".6"/><text x="${left-7}" y="${y(v)+4}" text-anchor="end">${v}</text>`;
 if(labels)s+=`<text x="${(left+right)/2}" y="${bottom+37}" text-anchor="middle">pixel</text>`;
 s+=`<text transform="translate(${left-42} ${(top+bottom)/2}) rotate(-90)" text-anchor="middle">Intensity</text>`;
 return {x,y,s};
}
function legend(entries,left,top,width){
 let s=`<g class="figure-legend"><rect x="${left}" y="${top}" width="${width}" height="${entries.length*17+8}" fill="white" stroke="black" stroke-width=".6"/>`;
 entries.forEach((e,i)=>{const yy=top+14+i*17;s+=e.area?`<rect x="${left+5}" y="${yy-8}" width="33" height="9" fill="${e.color}" fill-opacity="${e.opacity}" stroke="black" stroke-width=".5"/>`:`<path d="M${left+5} ${yy-4}h33" stroke="${e.color}" stroke-width="${e.selected?2:1}"/>`;s+=`<text x="${left+44}" y="${yy}" font-size="11">${esc(e.label)}</text>`;});return s+'</g>';
}
function profilePlot(){
 const ids=diagnosticChannels(result);
 const ymax=Math.max(result.control?.height??0,result.test?.height??0)+20,xmax=Math.ceil(result.height/100)*100;
 const a=axes(75,35,520,285,0,xmax,ymax);let s=start(560,337,'Image Profile Plots');
 s+='<text x="298" y="26" text-anchor="middle" font-size="14" font-weight="bold">Image Profile Plots</text>'+a.s;
 for(const id of ids)s+=`<path d="${line(result.profiles[id],a.x,a.y)}" fill="none" stroke="${colors[id]}" stroke-width="1"/>`;
 const entries=ids.map(id=>({color:colors[id],label:names[id]}));
 if(result.method===0){s+=`<path d="${line(result.profile,a.x,a.y)}" fill="none" stroke="${colors[result.channel]}" stroke-width="2"/>`;entries.push({color:colors[result.channel],label:'Best Channel for analysis',selected:true});}
 for(const[p,name]of [[result.control,'Control Line'],[result.test,'Test Line']])if(p)s+=`<text x="${a.x(p.location)}" y="${a.y(p.height+5)}" text-anchor="middle" font-weight="bold">${name}</text>`;
 return s+legend(entries,325,40,195)+'</svg>';
}
function alignedPlot(){
 const ymax=Math.max(result.control?.height??0,result.test?.height??0)+20;
 const a=axes(75,38,520,160,1,result.height,ymax,false,ymax>100?50:ymax>40?20:ymax>10?5:1);
 // The shorter aligned profile in the PDF uses 50-unit y ticks.
 let s=start(560,337,'Profile Plot of the Best Channel');s+='<text x="298" y="24" text-anchor="middle" font-size="14">Profile Plot of the Best Channel</text>'+a.s;
 s+=`<path d="${line(result.profile,a.x,a.y)}" fill="none" stroke="${colors[result.channel]}" stroke-width="4"/>`;
 const entries=[];
 for(const[p,color,opacity,name,area]of [[result.control,'#ff00ff',.5,'Control',result.C_area],[result.test,'#0000ff',.4,'Test',result.T_area]]){
  if(!p)continue;const b=p.integration.bounds,baseline=p.integration.baseline,points=[];
  for(let i=b[0];i<=b[1];i++)points.push(`${a.x(i)},${a.y(result.corrected_profile[i-1])}`);
  for(let i=b[1];i>=b[0];i--)points.push(`${a.x(i)},${a.y(baseline[i-b[0]])}`);
  s+=`<polygon points="${points.join(' ')}" fill="${color}" fill-opacity="${opacity}"/><path d="M${a.x(b[0])} ${a.y(baseline[0])}L${a.x(b[1])} ${a.y(baseline.at(-1))}" fill="none" stroke="${color}" stroke-width="2"/>`;
  for(let i=0;i<2;i++)s+=`<path d="M${a.x(b[i])} 160V${a.y(p.integration.endpoints[i])}" stroke="black" stroke-dasharray="6 4"/><circle cx="${a.x(b[i])}" cy="${a.y(p.integration.endpoints[i])}" r="3.5" fill="none" stroke="${color}" stroke-width="2"/>`;
  s+=`<text x="${a.x(p.location)}" y="${Math.max(42,a.y(p.height+5))}" text-anchor="middle" font-size="12" font-weight="bold">${name} Line</text>`;
  entries.push({color,opacity,area:true,label:`${name} Line Area = ${Math.round(area)}`});
 }
 s+=legend(entries,326,41,191);
 const image=canvas(result.rgb,result.width,result.height,null,true).toDataURL('image/png');
 s+='<text x="298" y="214" text-anchor="middle" font-size="13">Original LFA Image Aligned with Profile</text>';
 s+=`<defs><clipPath id="aligned-image"><rect x="75" y="225" width="445" height="72"/></clipPath></defs><g clip-path="url(#aligned-image)"><image href="${image}" x="${a.x(.5)}" y="225" width="${a.x(result.height+.5)-a.x(.5)}" height="72" preserveAspectRatio="none"/>`;
 for(const p of [result.control,result.test])if(p)for(const v of p.integration.bounds)s+=`<path d="M${a.x(v)} 225V297" stroke="${result.readout===2?'white':'black'}" stroke-dasharray="6 4"/>`;
 s+='</g><rect x="75" y="225" width="445" height="72" fill="none" stroke="black" stroke-width=".6"/>';
 const step=result.height>100?100:Math.max(1,Math.ceil(result.height/5));for(let v=step;v<result.height;v+=step)s+=`<path d="M${a.x(v)} 297v-4" stroke="black" stroke-width=".6"/><text x="${a.x(v)}" y="315" text-anchor="middle">${v}</text>`;
 return s+'<text x="298" y="335" text-anchor="middle">Pixel</text></svg>';
}

export function imageCanvas(rgb,w,h,plane=null){return canvas(rgb,w,h,plane);}
export function profileFigure(value){result=value;return profilePlot();}
export function alignedFigure(value){result=value;return alignedPlot();}
