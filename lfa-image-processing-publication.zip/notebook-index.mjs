// Local, progressively updated notebook navigation. No user data is transmitted.
const notebook=document.querySelector('main.document');
const panel=document.getElementById('notebook-index'),links=document.getElementById('notebook-index-links'),toggle=document.getElementById('notebook-index-toggle');
const narrow=matchMedia('(max-width:1099px)');
let pending=false;
notebook.id ||= 'notebook-top';
function open(value){
 toggle.setAttribute('aria-expanded',String(value));
 toggle.setAttribute('aria-label',(value?'Close':'Open')+' notebook section index');
 panel.hidden=!value;document.body.classList.toggle('notebook-index-open',value);
 if(value&&narrow.matches)requestAnimationFrame(()=>panel.scrollIntoView({block:'start'}));
}
toggle.addEventListener('click',()=>open(toggle.getAttribute('aria-expanded')!=='true'));
addEventListener('keydown',event=>{
 if(event.key==='Escape'&&!panel.hidden){open(false);toggle.focus();}
});
function target(element,id){
 if(!element.id)element.id=id;
 element.classList.add('notebook-section-target');
 if(!element.hasAttribute('tabindex'))element.tabIndex=-1;
 return element.id;
}
function item(element,label,id,subitem=false){
 const li=document.createElement('li');if(subitem)li.className='notebook-index-subitem';
 const a=document.createElement('a');a.href='#'+encodeURIComponent(target(element,id));a.textContent=label;
 if(decodeURIComponent(location.hash.slice(1))===element.id)a.setAttribute('aria-current','location');
 li.append(a);return li;
}
function visible(element){return element.getClientRects().length>0;}
function build(){
 pending=false;const priorScroll=panel.scrollTop,filesOpen=links.querySelector('details')?.open??false;
 const list=document.createElement('ul');
 list.append(item(notebook,'Top of notebook','notebook-top'));
 const detailsLabel=document.querySelector('label[for="experiment-details"]');
 if(detailsLabel)list.append(item(detailsLabel,detailsLabel.textContent.trim(),'experimental-details-heading'));
 const candidates=[...notebook.querySelectorAll('h2,h3,#image-results,#warnings,#review-help,#data-privacy')];
 let heading=0;
 for(const element of candidates){
  if(!visible(element)||element.closest('.image-result'))continue;
  if(element.id==='image-results'){
   const images=[...element.querySelectorAll('.image-result')];
   if(!images.length)continue;
   list.append(item(element,'Individual image processing results','image-results'));
   const li=document.createElement('li'),details=document.createElement('details'),summary=document.createElement('summary'),files=document.createElement('ul');
   details.open=filesOpen;summary.textContent='Image files ('+images.length+')';
   images.forEach((image,index)=>{
    const title=image.querySelector('h3')?.textContent??'';
    const name=title.split('\n').find(line=>line.startsWith('ANALYSING LFA IMAGE: '))?.slice('ANALYSING LFA IMAGE: '.length)??'Image '+(index+1);
    files.append(item(image,name,'notebook-image-'+(index+1)));
   });
   details.append(summary,files);li.append(details);list.append(li);continue;
  }
  if(element.id==='warnings'){
   if(element.textContent.trim())list.append(item(element,'Analysis warnings','warnings'));
   continue;
  }
  if(element.id==='review-help'){list.append(item(element,'Review Results','review-help'));continue;}
  if(element.id==='data-privacy'){list.append(item(element,'Data privacy','data-privacy'));continue;}
  const table=element.closest('.table-block');
  const container=table?.parentElement;
  let id=container?.id;
  if(!id)id='notebook-section-'+(++heading)+'-'+element.textContent.trim().toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  list.append(item(container?.id?container:element,element.textContent.trim(),id,element.tagName==='H3'));
 }
 // The two curve containers are visual figures rather than HTML headings.
 let curveAnchor=[...list.children].find(li=>li.textContent==='LoD Calculation');
 for(const [id,label]of [['calibration-figure','LFA Standard Curve'],['publication-curve','Publication curve']]){
  const element=document.getElementById(id);if(element&&visible(element)&&element.querySelector('svg')){
   const anchor=item(element,label,id,true);
   // Keep curve shortcuts next to LoD rather than burying them after privacy.
   if(curveAnchor)curveAnchor.after(anchor);else list.append(anchor);
   curveAnchor=anchor;
  }
 }
 links.replaceChildren(list);panel.scrollTop=priorScroll;
}
function schedule(){if(!pending){pending=true;requestAnimationFrame(build);}}
new MutationObserver(schedule).observe(notebook,{childList:true,subtree:true,attributes:true,attributeFilter:['hidden']});
links.addEventListener('click',event=>{
 const a=event.target.closest('a[href^="#"]');if(!a)return;
 const element=document.getElementById(decodeURIComponent(a.hash.slice(1)));if(!element)return;
 event.preventDefault();
 history.pushState(null,'',a.hash);
 if(narrow.matches)open(false);
 requestAnimationFrame(()=>{element.scrollIntoView({block:'start'});element.focus({preventScroll:true});schedule();});
});
addEventListener('hashchange',schedule);
build();
