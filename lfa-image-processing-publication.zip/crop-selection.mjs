// Shared pointer/keyboard interaction for the two Single crop interfaces.
// Coordinates retain the existing 1-based pixel-centre convention: w/h are
// distances, so a width of zero selects one pixel. No analysis is run here.
export function installCropSelection({stage,canvas,box,getSize,getRect,setRect}){
 let drag=null;
 const labels={nw:'top left',n:'top midpoint',ne:'top right',e:'right midpoint',se:'bottom right',s:'bottom midpoint',sw:'bottom left',w:'left midpoint'};
 for(const [edge,label]of Object.entries(labels)){
  const handle=document.createElement('button');handle.type='button';handle.className='crop-handle crop-handle-'+edge;handle.dataset.cropEdge=edge;
  handle.setAttribute('aria-label','Resize crop from '+label);handle.title='Drag to resize; arrow keys adjust by 1 pixel (Shift: 10 pixels)';
  box.append(handle);
 }
 box.tabIndex=0;box.setAttribute('role','group');box.setAttribute('aria-label','Crop selection. Drag to move, or use the resize handles. Arrow keys move by 1 pixel; Shift moves by 10 pixels.');
 // Enlarge small images for editing without changing their pixels or aspect
 // ratio. Leave enough space around the image for the outside handle hit areas.
 function fitPreview(){
  const size=getSize(),parent=stage.parentElement;if(!size||!parent.clientWidth)return;
  const css=getComputedStyle(parent),available=parent.clientWidth-parseFloat(css.paddingLeft)-parseFloat(css.paddingRight)-32;
  const scale=Math.min(Math.max(1,available)/size.width,Math.min(600,innerHeight*.65)/size.height);
  canvas.style.width=size.width*scale+'px';canvas.style.height=size.height*scale+'px';
 }
 new ResizeObserver(fitPreview).observe(stage.parentElement);addEventListener('resize',fitPreview);
 const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
 function point(event){
  const bounds=canvas.getBoundingClientRect(),size=getSize();
  return [(event.clientX-bounds.left)/bounds.width*size.width+1,(event.clientY-bounds.top)/bounds.height*size.height+1];
 }
 function edges(){
  const [x,y,w,h]=getRect(),size=getSize();
  const l=clamp(Number.isFinite(x)?x:1,1,size.width),t=clamp(Number.isFinite(y)?y:1,1,size.height);
  return {l,t,r:clamp(Number.isFinite(x+w)?x+w:size.width,l,size.width),b:clamp(Number.isFinite(y+h)?y+h:size.height,t,size.height)};
 }
 function write(r){setRect([r.l,r.t,r.r-r.l,r.b-r.t]);}
 function adjust(r,edge,dx,dy){
  const size=getSize();r={...r};
  if(edge==='move'){
   dx=clamp(dx,1-r.l,size.width-r.r);dy=clamp(dy,1-r.t,size.height-r.b);
   r.l+=dx;r.r+=dx;r.t+=dy;r.b+=dy;
  }else{
   if(edge.includes('w'))r.l=clamp(r.l+dx,1,r.r);
   if(edge.includes('e'))r.r=clamp(r.r+dx,r.l,size.width);
   if(edge.includes('n'))r.t=clamp(r.t+dy,1,r.b);
   if(edge.includes('s'))r.b=clamp(r.b+dy,r.t,size.height);
  }
  return r;
 }
 stage.addEventListener('pointerdown',event=>{
  if(event.button!==0||event.isPrimary===false||!getSize())return;
  event.preventDefault();const p=point(event);let handle=event.target.closest('[data-crop-edge]');
  // Narrow strips can put the generous handle hit areas on top of each other.
  // Pick the nearest handle centre rather than whichever button is painted last.
  if(handle)handle=[...box.querySelectorAll('[data-crop-edge]')].sort((a,b)=>{
   const distance=node=>{const r=node.getBoundingClientRect();return Math.hypot(event.clientX-r.left-r.width/2,event.clientY-r.top-r.height/2);};
   return distance(a)-distance(b);
  })[0];
  const mode=handle?.dataset.cropEdge||(event.target.closest('#crop-box')?'move':'draw');
  drag={id:event.pointerId,start:p,rect:edges(),mode};stage.setPointerCapture(event.pointerId);
  if(handle)handle.focus({preventScroll:true});else if(mode==='move')box.focus({preventScroll:true});
  if(mode==='draw'){
   const size=getSize(),x=clamp(Math.floor(p[0]),1,size.width),y=clamp(Math.floor(p[1]),1,size.height);
   drag.anchor=[x,y];write({l:x,t:y,r:x,b:y});
  }
 });
 stage.addEventListener('pointermove',event=>{
  if(!drag||event.pointerId!==drag.id)return;
  event.preventDefault();const p=point(event);
  if(drag.mode==='draw'){
   const size=getSize(),x=clamp(Math.floor(p[0]),1,size.width),y=clamp(Math.floor(p[1]),1,size.height),[a,b]=drag.anchor;
   write({l:Math.min(a,x),t:Math.min(b,y),r:Math.max(a,x),b:Math.max(b,y)});
  }else write(adjust(drag.rect,drag.mode,Math.round(p[0]-drag.start[0]),Math.round(p[1]-drag.start[1])));
 });
 const finish=event=>{if(event.pointerId===drag?.id)drag=null;};
 for(const event of ['pointerup','pointercancel','lostpointercapture'])stage.addEventListener(event,finish);
 box.addEventListener('keydown',event=>{
  const delta={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[event.key];
  if(!delta||!getSize())return;event.preventDefault();
  const step=event.shiftKey?10:1;write(adjust(edges(),event.target.dataset.cropEdge||'move',delta[0]*step,delta[1]*step));
 });
}
