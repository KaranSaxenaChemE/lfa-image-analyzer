// Tutorial players are independent of image processing and analysis settings.
for (const tutorial of document.querySelectorAll('.notebook-tutorial')) {
  tutorial.addEventListener('toggle', () => {
    const slot = tutorial.querySelector('.notebook-tutorial-player');
    if (!tutorial.open) { slot.replaceChildren(); return; }
    if (slot.childElementCount) return;
    const player = document.createElement('iframe');
    player.src = 'https://drive.google.com/file/d/' + tutorial.dataset.tutorialId + '/preview';
    player.title = tutorial.querySelector('summary').textContent;
    player.allow = 'autoplay; fullscreen';
    player.allowFullscreen = true;
    player.referrerPolicy = 'no-referrer';
    slot.append(player);
  });
}
