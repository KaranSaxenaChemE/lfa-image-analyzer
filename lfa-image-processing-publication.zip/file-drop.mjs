// File selection only. Files stay local and enter the existing analysis path.
const supported=file=>/\.(jpe?g|png|tiff?)$/i.test(file.name);
const entryFile=entry=>new Promise((resolve,reject)=>entry.file(resolve,reject));
async function directoryFiles(entry){
 const reader=entry.createReader(),children=[];
 // Chromium can return directory entries in groups of 100. Read to completion.
 for(;;){const batch=await new Promise((resolve,reject)=>reader.readEntries(resolve,reject));if(!batch.length)break;children.push(...batch);}
 return {files:await Promise.all(children.filter(child=>child.isFile).map(entryFile)),folderName:entry.name,subfoldersExcluded:children.some(child=>child.isDirectory)};
}
export async function readDroppedFiles({entries,files},multiple){
 const folders=entries.filter(entry=>entry?.isDirectory);
 if(folders.length){
  if(!multiple)throw Error('Drop one image file here. Use Batch Analysis to work with an image folder.');
  if(folders.length!==1||entries.length!==1)throw Error('Drop one image folder, or select a set of image files. Do not combine folders or mix a folder with files.');
  return directoryFiles(folders[0]);
 }
 return {files};
}
export function installFileDrop({zone,input,relatedInputs=[],message,multiple=false,isEnabled,onFiles,stateElement}){
 let collecting=false,epoch=0,depth=0;
 const inputs=[input,...relatedInputs];
 const fileDrag=event=>[...(event.dataTransfer?.types??[])].includes('Files');
 const enabled=()=>isEnabled()&&!collecting;
 const sync=()=>{zone.setAttribute('aria-disabled',String(!enabled()));zone.setAttribute('aria-busy',String(collecting));};
 function report(text,error=false){message.textContent=text;message.classList.toggle('file-drop-error',error);}
 function clearHover(){depth=0;zone.classList.remove('drag-active');}
 function choose(event){event.preventDefault();if(enabled())input.click();}
 zone.addEventListener('click',choose);
 zone.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){choose(event);}});
 zone.addEventListener('dragenter',event=>{if(!fileDrag(event))return;event.preventDefault();if(enabled()){depth++;zone.classList.add('drag-active');}});
 zone.addEventListener('dragover',event=>{if(!fileDrag(event))return;event.preventDefault();event.dataTransfer.dropEffect=enabled()?'copy':'none';});
 zone.addEventListener('dragleave',event=>{if(!fileDrag(event))return;depth=Math.max(0,depth-1);if(!depth)clearHover();});
 zone.addEventListener('drop',async event=>{
  if(!fileDrag(event))return;event.preventDefault();event.stopPropagation();clearHover();
  if(!enabled()){report('Please wait until the app is ready before adding images.');return;}
  // Capture entries and File objects synchronously, before the drag data store
  // becomes protected again. No paths are fetched and no image is uploaded.
  const transfer=event.dataTransfer;
  const items=[...(transfer.items??[])].filter(item=>item.kind==='file');
  const entries=items.map(item=>item.webkitGetAsEntry?.()??item.getAsEntry?.()??null);
  const files=[...transfer.files];const ticket=++epoch;collecting=true;sync();report('Reading the selected files locally…');
  try{
   const result=await readDroppedFiles({entries,files},multiple);if(ticket!==epoch)return;
   const images=result.files.filter(supported),ignored=result.files.length-images.length;
   if(!images.length)throw Error('No supported images found. Choose JPG, JPEG, PNG, TIF or TIFF files. If folder dropping is unavailable in your browser, use Choose an image folder.');
   if(!multiple&&result.files.length!==1)throw Error('Drop exactly one LFA image. Use Batch Analysis for multiple images.');
   if(!isEnabled())throw Error('The app is busy. Add the images again after the current analysis finishes.');
   // Keep native filename displays and saved-report filename lists consistent
   // with the dropped selection. Calling onFiles avoids synthetic change events.
   const selected=new DataTransfer();images.forEach(file=>selected.items.add(file));input.files=selected.files;
   relatedInputs.forEach(control=>control.value='');
   await onFiles(images,result);
   if(ticket===epoch)report(images.length+' image'+(images.length===1?'':'s')+' added'+(result.folderName?' from “'+result.folderName+'”':'')+'.'+(ignored?' '+ignored+' unsupported file(s) ignored.':'')+(result.subfoldersExcluded?' Subfolders are excluded.':''));
  }catch(error){if(ticket===epoch)report(error.message||'Could not read this selection. Please use the file buttons instead.',true);}
  finally{if(ticket===epoch){collecting=false;sync();}}
 });
 for(const control of inputs)control.addEventListener('change',()=>{
  epoch++;collecting=false;clearHover();report('');for(const other of inputs)if(other!==control)other.value='';sync();
 });
 // Dropping files outside the target must not navigate away from an analysis.
 for(const type of ['dragover','drop'])window.addEventListener(type,event=>{if(fileDrag(event))event.preventDefault();});
 new MutationObserver(sync).observe(input,{attributes:true,attributeFilter:['disabled']});
 if(stateElement)new MutationObserver(sync).observe(stateElement,{childList:true,subtree:true,characterData:true});
 sync();
}
