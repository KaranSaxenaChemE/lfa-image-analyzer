const $=id=>document.getElementById(id);
const worker=new Worker('./worker.mjs',{type:'module'});
let ready=false,original=null,result=null,fileName='',sequence=0,pending=0,view=null,drag=null;
let appliedCrop=null,cropDirty=false;
const colors=['#d14949','#39814d','#396bb7','#808080','#263d37'];
const channelNames=['Red Channel','Green Channel','Blue Channel','Grayscale','Contrast-adjusted Grayscale'];
const modeNames={1:'Colorimetric',2:'Fluorescent / Chemiluminescent'};
function text(tag,content,cls){const e=document.createElement(tag);e.textContent=content;if(cls)e.className=cls;return e;}
function display(v){if(typeof v!=='number')return v==='Infinity'?'∞':v;return new Intl.NumberFormat('en',{maximumSignificantDigits:7}).format(v);}
function status(message){$('engine-status').textContent=message;}
function clearResults(){result=null;for(const id of ['cropped-panel','measurements','aligned-panel','channels-panel','details-panel','exports-panel'])$(id).hidden=true;}
function fail(message){clearResults();$('error').textContent=message;$('error').hidden=false;status('Review the message above, then rerun.');}
function settings(){
  const crop=$('crop-enabled').checked?appliedCrop:null;
  return {method:Number($('method').value),readout:Number($('readout').value),control_threshold:Number($('control-threshold').value),test_threshold:Number($('test-threshold').value),crop};
}
function run(){
  if(!ready||!original)return;
  if(cropDirty){status('Click “Apply crop & analyse” to use your selected region.');return;}
  for(const id of ['control-threshold','test-threshold',...($('crop-enabled').checked?['crop-x','crop-y','crop-w','crop-h']:[])]){
    if(!$(id).value.trim()||!$(id).checkValidity()){fail('Enter valid thresholds and crop coordinates before running the analysis.');$(id).reportValidity();return;}
  }
  $('error').hidden=true;clearResults();$('run').disabled=true;$('run').textContent='Analysing…';status('Measuring the selected image on your computer');
  pending=++sequence;worker.postMessage({type:'analyze',id:pending,options:settings()});
}
function pixelsCanvas(rgb,w,h,plane=null,transpose=false){
  const canvas=document.createElement('canvas');canvas.width=transpose?h:w;canvas.height=transpose?w:h;
  const ctx=canvas.getContext('2d'),image=ctx.createImageData(canvas.width,canvas.height);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    const src=(y*w+x)*3,dst=(transpose?(x*h+y):(y*w+x))*4;
    for(let c=0;c<3;c++)image.data[dst+c]=plane===null?rgb[src+c]:typeof plane==='number'?rgb[src+plane]:plane[y*w+x];
    image.data[dst+3]=255;
  }ctx.putImageData(image,0,0);return canvas;
}
async function load(bytes,name){
  if(!ready)return;
  original=null;appliedCrop=null;cropDirty=false;fileName=name;clearResults();$('error').hidden=true;$('welcome').hidden=true;$('original-panel').hidden=true;$('crop-panel').hidden=true;
  $('crop-enabled').checked=false;$('run').disabled=true;status('Reading image pixels');$('file-info').textContent=name;
  pending=++sequence;worker.postMessage({type:'load',id:pending,bytes},[bytes]);
}
worker.onmessage=({data})=>{
  if(data.type==='ready'){ready=true;$('run').textContent='Run analysis';$('run').disabled=!original;status('Ready · no image uploads');return;}
  if(data.type==='fatal'){fail(data.error);return;}
  if(data.id!==pending)return;
  $('run').disabled=!original;$('run').textContent='Run analysis';
  if(data.result.error){
    if(data.result.detection){const d=data.result.detection;fail(`${data.result.error} Background = ${d.backgroundLevel.toFixed(1)}, dark-line score = ${d.darkLineScore.toFixed(1)}, bright-line score = ${d.brightLineScore.toFixed(1)}.`);}else fail(data.result.error);
    return;
  }
  if(data.type==='loaded'){
    original=data.result;
    const c=pixelsCanvas(original.rgb,original.width,original.height),target=$('original');target.width=c.width;target.height=c.height;target.getContext('2d').drawImage(c,0,0);
    $('original-panel').hidden=false;$('dimensions').textContent=`${original.width} × ${original.height} pixels`;
    $('file-info').textContent=`${fileName} · ${original.width} × ${original.height} px`;
    resetCrop();run();return;
  }
  result=data.result;view=[1,result.height];render();status('Analysis complete · settings changes rerun automatically');
  if(appliedCrop){$('crop-status').textContent=`Crop applied: ${result.width} × ${result.height} pixels. This region is being used for analysis.`;}
};
worker.onerror=e=>{fail(`The analysis engine stopped: ${e.message}. Reload the page and try again.`);$('run').disabled=true;};
$('file').addEventListener('change',async()=>{
  const f=$('file').files[0];if(!f)return;
  if(!/\.(jpe?g|png|tiff?)$/i.test(f.name)){fail('Choose a JPG, JPEG, PNG, TIF or TIFF image.');return;}
  await load(await f.arrayBuffer(),f.name);
});
$('example').addEventListener('click',async()=>{try{await load(await(await fetch('./assets/synthetic-example.png')).arrayBuffer(),'synthetic-lfa-example.png');}catch(e){fail(e.message);}});
$('run').addEventListener('click',run);
for(const id of ['method','readout','control-threshold','test-threshold'])$(id).addEventListener('change',()=>{
  $('method-help').textContent=Number($('method').value)===0?'Automatic RGB selects the channel with the largest intensity range across the whole profile.':Number($('method').value)===1?'Converts to 8-bit grayscale and stretches contrast using the default 1% histogram limits.':'Uses the selected channel or grayscale profile for peak detection and area integration.';
  run();
});
function resetCrop(){if(!original)return;for(const[k,v]of Object.entries({x:1,y:1,w:original.width-1,h:original.height-1}))$(`crop-${k}`).value=v;updateCrop();}
function draftChanged(){
  cropDirty=true;pending=++sequence;clearResults();$('error').hidden=true;
  $('run').disabled=true;$('run').textContent='Apply crop to continue';
  $('crop-status').textContent='Selection not applied. Click “Apply crop & analyse” to use this region.';
  status('Crop selection is waiting for you to apply it.');
}
function updateCrop(){
  if(!original)return;
  const c=$('crop-canvas');if(c.width!==original.width||c.height!==original.height){c.width=original.width;c.height=original.height;}c.getContext('2d').drawImage($('original'),0,0);
  const box=$('crop-box'),rect=c.getBoundingClientRect(),x=Number($('crop-x').value),y=Number($('crop-y').value),w=Number($('crop-w').value),h=Number($('crop-h').value);
  box.style.left=`${(x-1)/original.width*100}%`;box.style.top=`${(y-1)/original.height*100}%`;box.style.width=`${(w+1)/original.width*100}%`;box.style.height=`${(h+1)/original.height*100}%`;
}
$('crop-enabled').addEventListener('change',()=>{
  if(!original){$('crop-enabled').checked=false;status('Select an image before cropping.');return;}
  const enabled=$('crop-enabled').checked;$('crop-panel').hidden=!enabled;
  if(enabled){requestAnimationFrame(updateCrop);draftChanged();$('crop-panel').scrollIntoView({behavior:'smooth',block:'start'});}
  else{appliedCrop=null;cropDirty=false;$('run').textContent='Run analysis';run();}
});
$('reset-crop').addEventListener('click',()=>{resetCrop();$('crop-enabled').checked=false;$('crop-panel').hidden=true;appliedCrop=null;cropDirty=false;run();});
$('apply-crop').addEventListener('click',()=>{
  for(const k of ['x','y','w','h']){const input=$(`crop-${k}`);if(!input.value.trim()||!input.checkValidity()){input.reportValidity();return;}}
  const rect=['x','y','w','h'].map(k=>Number($(`crop-${k}`).value));
  if(rect[0]+rect[2]<1||rect[1]+rect[3]<1||rect[0]>original.width||rect[1]>original.height){$('crop-status').textContent='Select a region that contains image pixels.';return;}
  appliedCrop=rect;cropDirty=false;$('crop-status').textContent='Applying the selected crop…';run();
});
for(const k of ['x','y','w','h'])$(`crop-${k}`).addEventListener('input',()=>{updateCrop();draftChanged();});
function point(event){const b=$('crop-canvas').getBoundingClientRect();return [Math.max(1,Math.min(original.width,Math.floor((event.clientX-b.left)/b.width*original.width)+1)),Math.max(1,Math.min(original.height,Math.floor((event.clientY-b.top)/b.height*original.height)+1))];}
$('crop-stage').addEventListener('pointerdown',e=>{if(!original)return;drag=point(e);draftChanged();$('crop-stage').setPointerCapture(e.pointerId);});
$('crop-stage').addEventListener('pointermove',e=>{if(!drag)return;const p=point(e);for(const[k,v]of Object.entries({x:Math.min(p[0],drag[0]),y:Math.min(p[1],drag[1]),w:Math.abs(p[0]-drag[0]),h:Math.abs(p[1]-drag[1])}))$(`crop-${k}`).value=v;updateCrop();});
$('crop-stage').addEventListener('pointerup',()=>{drag=null;});
$('crop-stage').addEventListener('pointercancel',()=>{drag=null;});
function download(content,name,type){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}
function stem(){return fileName.replace(/\.[^.]+$/,'');}
const escape=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const svgStart=(w,h)=>`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${w} ${h}" role="img" font-family="Arial,sans-serif" font-size="15"><rect width="100%" height="100%" fill="white"/>`;
function svgLegend(entries,y){
  const rows=Math.ceil(entries.length/2);
  let s=`<g class="figure-legend" role="group" aria-label="Figure legend"><rect x="68" y="${y-20}" width="808" height="${rows*31+14}" rx="3" fill="#f8fafb" stroke="#d8e0e5"/>`;
  entries.forEach((entry,i)=>{const x=86+(i%2)*394,yy=y+Math.floor(i/2)*31;
    s+=entry.metric?'':entry.area?`<rect x="${x}" y="${yy-11}" width="23" height="13" fill="${entry.color}" fill-opacity=".3" stroke="${entry.color}"/>`:`<path d="M${x} ${yy-5}h23" fill="none" stroke="${entry.color}" stroke-width="${entry.selected?3:2}"/>`;
    s+=`<text x="${x+33}" y="${yy}" fill="#243747" font-size="17">${escape(entry.label)}</text>`;
  });return s+'</g>';
}
function exportFigure(id,name){
  const svg=$(id).querySelector('svg').cloneNode(true);
  svg.querySelector('#probe')?.remove();
  download(new XMLSerializer().serializeToString(svg),name,'image/svg+xml');
}
function axes(x,y,maxY,h,range){
  let s=`<path d="M68 20V${h}H876" fill="none" stroke="#46564f"/>`;
  for(let i=0;i<=4;i++){const v=maxY*i/4,yy=y(v);s+=`<path d="M64 ${yy}H68" stroke="#46564f"/><text x="56" y="${yy+4}" text-anchor="end" fill="#66776c">${Number(v.toPrecision(3))}</text>`;}
  for(let i=0;i<=5;i++){const p=range[0]+(range[1]-range[0])*i/5,xx=x(p);s+=`<path d="M${xx} ${h}v5" stroke="#46564f"/><text x="${xx}" y="${h+23}" text-anchor="middle" fill="#66776c">${Math.round(p)}</text>`;}
  return s+`<text x="472" y="${h+45}" text-anchor="middle" fill="#53665b">Pixel</text><text transform="translate(18 ${h/2}) rotate(-90)" text-anchor="middle" fill="#53665b">Intensity</text>`;
}
function pathOf(values,x,y){return values.map((v,i)=>`${i?'L':'M'}${x(i+1).toFixed(3)} ${y(v).toFixed(3)}`).join('');}
function chartAligned(){
  const W=900,H=555,plotBottom=280,maxY=Math.max(result.control?.height??0,result.test?.height??0)+20;
  const x=v=>68+(v-view[0])/(view[1]-view[0])*808,y=v=>plotBottom-v/maxY*245;
  const image=pixelsCanvas(result.rgb,result.width,result.height,null,true).toDataURL('image/png');
  let s=svgStart(W,H)+`<title>Best-channel profile and aligned LFA image</title><defs><clipPath id="profile-clip"><rect x="68" y="20" width="808" height="260"/></clipPath><clipPath id="image-clip"><rect x="68" y="355" width="808" height="65"/></clipPath></defs>`;
  s+=axes(x,y,maxY,plotBottom,view)+`<g clip-path="url(#profile-clip)"><path d="${pathOf(result.profile,x,y)}" fill="none" stroke="${colors[result.channel]}" stroke-width="2.5"/>`;
  for(const[key,color,label]of [['control','#b43d8b','Control Line'],['test','#2b65b8','Test Line']]){
    const p=result[key];if(!p)continue;const b=p.integration.bounds,base=p.integration.baseline;
    const points=[];for(let i=b[0];i<=b[1];i++)points.push(`${x(i)},${y(result.corrected_profile[i-1])}`);
    for(let i=b[1];i>=b[0];i--)points.push(`${x(i)},${y(base[i-b[0]])}`);
    s+=`<polygon points="${points.join(' ')}" fill="${color}" fill-opacity=".3"/><path d="M${x(b[0])} ${y(base[0])}L${x(b[1])} ${y(base.at(-1))}" stroke="${color}" stroke-width="2"/>`;
    for(let i=0;i<2;i++)s+=`<path d="M${x(b[i])} ${plotBottom}V${y(p.integration.endpoints[i])}" stroke="#58645c" stroke-dasharray="5 4"/><circle cx="${x(b[i])}" cy="${y(p.integration.endpoints[i])}" r="3" fill="white" stroke="${color}"/>`;
    s+=`<text x="${x(p.location)}" y="${Math.max(18,y(p.height)-12)}" text-anchor="middle" fill="#30453b" font-size="13" font-weight="600">${label}</text>`;
  }
  s+=`</g><text x="472" y="347" text-anchor="middle" fill="#53665b">Original LFA Image Aligned with Profile</text><g clip-path="url(#image-clip)"><image href="${image}" x="${x(.5)}" y="355" width="${x(result.height+.5)-x(.5)}" height="65" preserveAspectRatio="none"/>`;
  for(const p of [result.control,result.test])if(p)for(const v of p.integration.bounds)s+=`<path d="M${x(v)} 355V420" stroke="${result.readout===2?'white':'black'}" stroke-dasharray="5 4"/>`;
  s+='</g>'+svgLegend([
    {color:'#b43d8b',area:true,label:`Control line area = ${display(result.C_area)}`},
    {color:'#2b65b8',area:true,label:`Test line area = ${display(result.T_area)}`},
    {color:colors[result.channel],label:`${channelNames[result.channel]} profile`},
    {metric:true,label:`Area ratio (T/C) = ${display(result.area_ratio)}`}
  ],456);
  s+=`<g id="probe" visibility="hidden"><path id="probe-line" d="" stroke="#243e32" stroke-dasharray="3 3"/><rect x="69" y="3" width="310" height="22" fill="white"/><text id="probe-text" x="76" y="18" font-size="12"/></g></svg>`;
  $('aligned').innerHTML=s;
  const svg=$('aligned').firstElementChild;
  svg.addEventListener('pointermove',e=>{const r=svg.getBoundingClientRect(),f=((e.clientX-r.left)/r.width*900-68)/808;if(f<0||f>1)return;const pixel=Math.round(view[0]+f*(view[1]-view[0]));$('probe').setAttribute('visibility','visible');$('probe-line').setAttribute('d',`M${x(pixel)} 25V420`);$('probe-text').textContent=`Pixel ${pixel} · intensity ${display(result.profile[pixel-1])}`;});
  svg.addEventListener('pointerleave',()=>$('probe')?.setAttribute('visibility','hidden'));
}
function chartProfiles(){
  const indices=result.method===0?[0,1,2]:result.method===1?[3,4]:[result.channel];
  const maxY=indices.reduce((max,i)=>result.profiles[i].reduce((a,b)=>Math.max(a,b),max),1)*1.1;
  const x=v=>68+(v-1)/(result.height-1)*808,y=v=>270-v/maxY*235;
  let s=svgStart(900,425)+'<title>Image Profile Plots</title>'+axes(x,y,maxY,270,[1,result.height]);
  for(const i of indices)s+=`<path d="${pathOf(result.profiles[i],x,y)}" fill="none" stroke="${colors[i]}" stroke-width="1.5"/>`;
  if(result.method===0)s+=`<path d="${pathOf(result.profile,x,y)}" fill="none" stroke="${colors[result.channel]}" stroke-width="3"/>`;
  for(const[p,label]of [[result.control,'Control Line'],[result.test,'Test Line']])if(p)s+=`<text x="${x(p.location)}" y="${y(p.height)-12}" text-anchor="middle" font-size="12">${label}</text>`;
  const legend=indices.map(i=>({color:colors[i],label:channelNames[i]}));
  if(result.method===0)legend.push({color:colors[result.channel],selected:true,label:`Selected: ${channelNames[result.channel]}`});
  $('profiles').innerHTML=s+svgLegend(legend,354)+'</svg>';
  $('spectrum-legend').replaceChildren(...indices.map(i=>{const e=text('span','');const mark=document.createElement('i');mark.style.background=colors[i];e.append(mark,text('span',channelNames[i]));return e;}));
  if(result.method===0)$('spectrum-legend').append(text('span',`${channelNames[result.channel]} selected for analysis`));
  $('channel-images').replaceChildren();
  const cards=[{title:'Original Image',plane:null},...indices.map(i=>({title:channelNames[i],plane:i<3?i:i===3?result.grayscale:result.adjusted}))];
  for(const card of cards){const box=text('div','', 'channel-card'),canvas=pixelsCanvas(result.rgb,result.width,result.height,card.plane);box.append(canvas,text('span',card.title));$('channel-images').append(box);}
}
function render(){
  $('error').hidden=true;for(const id of ['measurements','aligned-panel','channels-panel','details-panel','exports-panel'])$(id).hidden=false;
  $('resolved-mode').textContent=modeNames[result.readout];
  $('mode-source').textContent=settings().readout===0?'Readout mode · automatically detected':'Readout mode · manually selected';
  $('mode-value').textContent=modeNames[result.readout];
  const d=result.detection;
  $('mode-explanation').textContent=(result.readout===1?'Dark lines on a bright background.':'Bright lines on a dark background.')+(settings().readout===0?` Background ${display(d.backgroundLevel)} · dark-line score ${display(d.darkLineScore)} · bright-line score ${display(d.brightLineScore)}.`:'');
  $('channel-source').textContent=result.method===0?'Best channel · automatically selected':'Analysis profile · manually selected';
  $('channel-value').textContent=channelNames[result.channel];
  $('channel-explanation').textContent=result.method===0?`Largest whole-profile intensity range: ${display(result.ranges[result.channel])}. Red ${display(result.ranges[0])} · Green ${display(result.ranges[1])} · Blue ${display(result.ranges[2])}.`:'This profile is used to detect and measure both lines.';
  if(appliedCrop&&$('crop-enabled').checked){
    const canvas=pixelsCanvas(result.rgb,result.width,result.height),target=$('cropped-image');target.width=canvas.width;target.height=canvas.height;target.getContext('2d').drawImage(canvas,0,0);
    $('cropped-dimensions').textContent=`${result.width} × ${result.height} pixels`;$('cropped-panel').hidden=false;
  }
  const metrics=[['C_area', 'Cₐᵣₑₐ · Control area','intensity × pixel'],['T_area','Tₐᵣₑₐ · Test area','intensity × pixel'],['area_ratio','(T/C)ₐᵣₑₐ · Area ratio','Test / Control'],['C_prom','Control Prominence','intensity'],['T_prom','Test Prominence','intensity'],['prom_ratio','T/C Prominence','Test / Control']];
  $('metrics').replaceChildren(...metrics.map(([key,label,unit])=>{const e=text('div','', 'metric');e.append(text('span',label,'metric-label'),text('strong',display(result[key]),'metric-value'),text('span',unit,'metric-unit'));e.title=`${label}: ${result[key]}`;e.dataset.metric=key;return e;}));
  const notes=[`${channelNames[result.channel]} · ${result.width} × ${result.height} analysed pixels`];
  if(!result.control)notes.push('Control peak not detected: Control area and prominence are zero.');
  if(!result.test)notes.push('Test peak not detected: Test area and prominence are zero.');
  if(typeof result.area_ratio==='string'||typeof result.prom_ratio==='string')notes.push('A zero Control signal produces an undefined or infinite ratio, as in MATLAB.');
  $('result-note').textContent=notes.join(' · ');chartAligned();chartProfiles();
  const detail=$('numerical-details');detail.replaceChildren();
  const table=document.createElement('table');
  table.innerHTML='<thead><tr><th>Line</th><th>Location (pixel)</th><th>Height</th><th>Width (pixels)</th><th>Prominence</th><th>Area interval</th></tr></thead>';
  const body=document.createElement('tbody');
  for(const[name,p]of [['Control',result.control],['Test',result.test]]){
    const row=document.createElement('tr');for(const v of [name,p?.location??'Not detected',p?display(p.height):'—',p?display(p.width):'—',p?display(p.prominence):'0',p?p.integration.bounds.join(' – '):'—'])row.append(text('td',v));body.append(row);
  }table.append(body);const scroll=text('div','','table-scroll');scroll.append(table);detail.append(scroll);
  if(result.method===0)detail.append(text('p',`RGB profile ranges: Red ${display(result.ranges[0])}; Green ${display(result.ranges[1])}; Blue ${display(result.ranges[2])}.`,'hint'));
  if(settings().readout===0){const d=result.detection;detail.append(text('p',`Auto-detection: background ${display(d.backgroundLevel)}; dark-line score ${display(d.darkLineScore)}; bright-line score ${display(d.brightLineScore)}. Calculated from the original, uncropped image.`,'hint'));}
}
$('download-aligned').addEventListener('click',()=>exportFigure('aligned',`${stem()}-aligned.svg`));
$('download-profile').addEventListener('click',()=>exportFigure('profiles',`${stem()}-profiles.svg`));
$('download-json').addEventListener('click',()=>download(JSON.stringify({filename:fileName,settings:settings(),...result},null,2),`${stem()}-analysis.json`,'application/json'));
$('download-csv').addEventListener('click',()=>{
  const fields=['C_area','T_area','area_ratio','C_prom','T_prom','prom_ratio'];const quote=v=>'"'+String(v).replaceAll('"','""')+'"';
  const csv=[['filename','method','readout','control_threshold','test_threshold',...fields], [fileName,$('method').selectedOptions[0].textContent,modeNames[result.readout],settings().control_threshold,settings().test_threshold,...fields.map(k=>result[k])]].map(r=>r.map(quote).join(',')).join('\r\n');download(csv,`${stem()}-measurements.csv`,'text/csv');
});
async function loadGuide(){
  const [artwork,paragraphs]=await Promise.all([fetch('./assets/artwork.json').then(r=>r.json()),fetch('./assets/explanations.json').then(r=>r.json())]);
  for(const key of ['4451','3c31'])if(artwork[key]){
    const img=document.createElement('img');img.src='./assets/'+artwork[key];img.alt=key==='4451'?'Indian Institute of Science':'Toley Lab';
    const link=document.createElement('a');link.href=key==='4451'?'https://iisc.ac.in/':'https://toleylab.weebly.com/';link.target='_blank';link.rel='noopener noreferrer';link.setAttribute('aria-label',`Visit ${img.alt} website (opens in a new tab)`);link.append(img);$('logos').append(link);
  }
  if(artwork['0d05'])$('orientation').src='./assets/'+artwork['0d05'];
  for(let p of paragraphs){
    if(!p||p.includes('![ ')||p.includes('![')||p.includes('![]')||p.startsWith('# Single')||p.includes('Smoothing:'))continue;
    p=p.replaceAll('\\_','_').replace(/\*\*/g,'');
    const heading=p.match(/^#{1,3}\s+(.*)/);$('guide-content').append(text(heading?'h3':'p',heading?heading[1]:p));
  }
  $('guide-content').append(text('p','C_area and T_area are baseline-corrected integrated peak areas. The prominence values describe how far the selected peaks rise above their surrounding baselines. Area and prominence ratios are calculated as Test divided by Control.'));
}
loadGuide().catch(e=>status(`Guide artwork could not load: ${e.message}`));
