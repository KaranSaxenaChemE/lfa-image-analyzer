import {createEngine} from './engine.mjs';
let engine,rows=[];
try{engine=await createEngine(await(await fetch('./single_lfa.wasm')).arrayBuffer());postMessage({type:'ready'});}
catch(error){postMessage({type:'fatal',error:error.message});}
onmessage=async({data})=>{
 try{
  if(data.type==='calibrate'){
   postMessage({type:'summary',id:data.id,result:engine.batch(rows,data.options)});return;
  }
  if(data.type!=='analyze')return;
  rows=[];let readout=data.options.readout,channel;
  // MATLAB detects polarity from the first sorted file, then processes in reverse.
  const files=data.files.filter(f=>/\.(jpe?g|png|tiff?)$/i.test(f.name)).sort((a,b)=>a.name<b.name?-1:a.name>b.name?1:0);
  const duplicates=files.filter((f,i)=>i&&f.name===files[i-1].name);
  if(duplicates.length)throw Error('Duplicate filenames were selected. Choose images from one experiment folder.');
  if(!files.length)throw Error('No supported experimental LFA images were selected.');
  if(readout===0){
   const first=engine.file(new Uint8Array(await files[0].arrayBuffer()),{...data.options,batch:true});
   // Readout detection remains usable even if this strip has no detected peaks.
   readout=first.readout;
   if(!readout)throw Error(first.error??'Automatic readout detection is inconclusive. Select a readout mode manually.');
   postMessage({type:'readout',id:data.id,filename:files[0].name,readout,detection:first.detection});
  }else postMessage({type:'readout',id:data.id,filename:null,readout});
  for(let i=files.length-1;i>=0;i--){
   const file=files[i],result=engine.file(new Uint8Array(await file.arrayBuffer()),{...data.options,readout,batch:true,batch_channel:channel});
   if(result.error)throw Error(file.name+': '+result.error);
   if(data.options.method===0&&channel===undefined)channel=result.channel;
   const row={filename:file.name,...Object.fromEntries(['T_area','C_area','T_prom','C_prom'].map(k=>[k,result[k]]))};rows.push(row);
   const diagnostic=data.options.diagnostics==='None'?null:result;
   const peaks=[result.control,result.test].filter(Boolean).map(({height,location,width,prominence})=>({height,location,width,prominence}));
   postMessage({type:'image',id:data.id,row,index:files.length-i,total:files.length,result:diagnostic,channel:result.channel,ranges:result.ranges,peaks});
   // Let message delivery and browser painting progress between strips.
   await new Promise(resolve=>setTimeout(resolve,0));
  }
  postMessage({type:'summary',id:data.id,result:engine.batch(rows,data.options)});
 }catch(error){postMessage({type:'error',id:data.id,error:error.message});}
};
