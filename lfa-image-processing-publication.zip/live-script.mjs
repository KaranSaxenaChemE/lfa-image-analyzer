// A separate document-style interface. The existing academic interface and the
// shared Rust/WebAssembly decoder and scientific calculations are unchanged.
const $=id=>document.getElementById(id),worker=new Worker('./worker.mjs',{type:'module'});
const names=['Red Channel','Green Channel','Blue Channel','Grayscale','Contrast-adjusted Grayscale'];
const colors=['#ff0000','#00ff00','#0000ff','#808080','#000000'];
const modes={1:'Colorimetric (dark lines on bright background)',2:'Fluorescent/Chemiluminescent (bright lines on dark background)'};
let ready=false,original=null,result=null,filename='',sequence=0,pending=0,appliedCrop=null,dirty=false,drag=null;
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const number=v=>typeof v!=='number'?(v==='Infinity'?'Inf':v==='-Infinity'?'-Inf':v):Math.abs(v)>=1?String(Number(v.toFixed(4))):String(Number(v.toPrecision(5)));
const row4=v=>typeof v==='number'?v.toFixed(4):String(v);
function settings(){return {method:+$('method').value,readout:+$('readout').value,control_threshold:+$('control-threshold').value,test_threshold:+$('test-threshold').value,crop:$('crop-enabled').checked?appliedCrop:null};}
function status(s){$('engine-status').textContent=s;}
function clear(){result=null;$('analysis-output').hidden=true;$('cropped-figure').hidden=true;$('crop-print-summary').hidden=true;for(const id of ['save-pdf-top','save-pdf-bottom'])$(id).disabled=true;}
function fail(s){clear();$('error').hidden=false;$('error').textContent=s;status('Review the message, adjust your settings, and run the analysis again.');}
function canvas(rgb,w,h,plane=null,transpose=false){
 const c=document.createElement('canvas');c.width=transpose?h:w;c.height=transpose?w:h;
 const ctx=c.getContext('2d'),image=ctx.createImageData(c.width,c.height);
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const a=(y*w+x)*3,b=(transpose?x*h+y:y*w+x)*4;for(let k=0;k<3;k++)image.data[b+k]=plane===null?rgb[a+k]:typeof plane==='number'?rgb[a+plane]:plane[y*w+x];image.data[b+3]=255;}
 ctx.putImageData(image,0,0);return c;
}
function draw(c,target){target.width=c.width;target.height=c.height;target.getContext('2d').drawImage(c,0,0);}
function run(){
 if(!ready||!original)return;if(dirty){status('Apply your selected crop before running the analysis.');return;}
 for(const id of ['control-threshold','test-threshold'])if(!$(id).value.trim()||!$(id).checkValidity()){$(id).reportValidity();return;}
 clear();$('error').hidden=true;$('run').disabled=true;status('Analysing image…');pending=++sequence;worker.postMessage({type:'analyze',id:pending,options:settings()});
}
async function load(bytes,name){
 if(!ready)return;original=null;appliedCrop=null;dirty=false;filename=name;clear();$('error').hidden=true;$('original-figure').hidden=true;$('crop-editor').hidden=true;$('crop-enabled').checked=false;$('crop-output').textContent='manually_crop_img = logical\n   0';$('run').disabled=true;$('filename').textContent=name;status('Reading image…');pending=++sequence;worker.postMessage({type:'load',id:pending,bytes},[bytes]);
}
worker.onmessage=({data})=>{
 if(data.type==='ready'){ready=true;status('Ready. Select an LFA image.');return;}
 if(data.type==='fatal'){fail(data.error);return;}if(data.id!==pending)return;
 $('run').disabled=!original;
 if(data.result.error){fail(data.result.error+(data.result.detection?` Background = ${number(data.result.detection.backgroundLevel)}, dark-line score = ${number(data.result.detection.darkLineScore)}, bright-line score = ${number(data.result.detection.brightLineScore)}.`:''));return;}
 if(data.type==='loaded'){
  original=data.result;draw(canvas(original.rgb,original.width,original.height),$('original'));$('original-figure').hidden=false;
  for(const[k,v]of Object.entries({x:1,y:1,w:original.width-1,h:original.height-1}))$(`crop-${k}`).value=v;
  updateCrop();run();return;
 }
 result=data.result;render();status('Analysis complete.');if(appliedCrop)$('crop-status').textContent=`Crop applied: ${result.width} × ${result.height} pixels used for analysis.`;
};
worker.onerror=e=>fail(`The analysis engine stopped: ${e.message}. Reload this view to restart it.`);
$('file').addEventListener('change',async()=>{const f=$('file').files[0];if(!f)return;if(!/\.(jpe?g|png|tiff?)$/i.test(f.name)){fail('Choose a JPG, JPEG, PNG, TIF or TIFF image.');return;}await load(await f.arrayBuffer(),f.name);});
$('example').addEventListener('click',async()=>{try{await load(await(await fetch('./assets/synthetic-example.png')).arrayBuffer(),'synthetic-lfa-example.png');}catch(e){fail(e.message);}});
$('run').addEventListener('click',run);
for(const id of ['method','readout','control-threshold','test-threshold'])$(id).addEventListener('change',()=>{
 $('readout-selection').textContent=`lfa_readout_mode =\n   "${$('readout').selectedOptions[0].textContent}"`;run();
});
function updateCrop(){
 if(!original)return;draw(canvas(original.rgb,original.width,original.height),$('crop-canvas'));
 const values=['x','y','w','h'].map(k=>+$(`crop-${k}`).value),box=$('crop-box');
 box.style.left=`${(values[0]-1)/original.width*100}%`;box.style.top=`${(values[1]-1)/original.height*100}%`;box.style.width=`${(values[2]+1)/original.width*100}%`;box.style.height=`${(values[3]+1)/original.height*100}%`;
}
function draft(){dirty=true;pending=++sequence;clear();$('run').disabled=true;$('crop-status').textContent='Selection not applied. Click Apply crop & analyse.';status('Crop selection is waiting for confirmation.');}
$('crop-enabled').addEventListener('change',()=>{
 if(!original){$('crop-enabled').checked=false;return;}
 const enabled=$('crop-enabled').checked;$('crop-output').textContent=`manually_crop_img = logical\n   ${enabled?1:0}`;$('crop-editor').hidden=!enabled;
 if(enabled){updateCrop();draft();}else{appliedCrop=null;dirty=false;run();}
});
for(const k of ['x','y','w','h'])$(`crop-${k}`).addEventListener('input',()=>{updateCrop();draft();});
function point(e){const b=$('crop-canvas').getBoundingClientRect();return [Math.max(1,Math.min(original.width,Math.floor((e.clientX-b.left)/b.width*original.width)+1)),Math.max(1,Math.min(original.height,Math.floor((e.clientY-b.top)/b.height*original.height)+1))];}
$('crop-stage').addEventListener('pointerdown',e=>{drag=point(e);draft();$('crop-stage').setPointerCapture(e.pointerId);});
$('crop-stage').addEventListener('pointermove',e=>{if(!drag)return;const p=point(e);for(const[k,v]of Object.entries({x:Math.min(p[0],drag[0]),y:Math.min(p[1],drag[1]),w:Math.abs(p[0]-drag[0]),h:Math.abs(p[1]-drag[1])}))$(`crop-${k}`).value=v;updateCrop();});
$('crop-stage').addEventListener('pointerup',()=>{drag=null;});$('crop-stage').addEventListener('pointercancel',()=>{drag=null;});
$('apply-crop').addEventListener('click',()=>{
 for(const k of ['x','y','w','h'])if(!$(`crop-${k}`).value.trim()||!$(`crop-${k}`).checkValidity()){$(`crop-${k}`).reportValidity();return;}
 const r=['x','y','w','h'].map(k=>+$(`crop-${k}`).value);if(r[0]>original.width||r[1]>original.height||r[0]+r[2]<1||r[1]+r[3]<1){$('crop-status').textContent='Choose a region containing image pixels.';return;}
 appliedCrop=r;dirty=false;run();
});
$('full-image').addEventListener('click',()=>{$('crop-enabled').checked=false;$('crop-editor').hidden=true;$('crop-output').textContent='manually_crop_img = logical\n   0';appliedCrop=null;dirty=false;run();});

const start=(w,h,title)=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" font-family="Arial,Helvetica,sans-serif" font-size="12" role="img"><title>${esc(title)}</title><rect width="100%" height="100%" fill="white"/>`;
function line(v,x,y,offset=0){return v.map((n,i)=>`${i?'L':'M'}${x(i+1+offset).toFixed(3)} ${y(n).toFixed(3)}`).join('');}
function axes(left,top,right,bottom,xmin,xmax,ymax,labels=true,tickStep=null){
 const x=v=>left+(v-xmin)/(xmax-xmin)*(right-left),y=v=>bottom-v/ymax*(bottom-top);
 let s=`<path d="M${left} ${top}V${bottom}H${right}V${top}H${left}" fill="none" stroke="black" stroke-width=".6"/>`;
 const step=xmax>100?100:Math.max(1,Math.ceil(xmax/5));
 for(let v=Math.ceil(xmin/step)*step;v<=xmax;v+=step)s+=`<path d="M${x(v)} ${bottom}v-5" stroke="black" stroke-width=".6"/><text x="${x(v)}" y="${bottom+17}" text-anchor="middle">${v}</text>`;
 let ystep=tickStep??(ymax>180?50:ymax>100?20:ymax>40?10:ymax>10?5:1);
 for(let v=0;v<=ymax;v+=ystep)s+=`<path d="M${left} ${y(v)}h5" stroke="black" stroke-width=".6"/><text x="${left-7}" y="${y(v)+4}" text-anchor="end">${v}</text>`;
 if(labels)s+=`<text x="${(left+right)/2}" y="${bottom+37}" text-anchor="middle">pixel</text>`;
 s+=`<text transform="translate(${left-42} ${(top+bottom)/2}) rotate(-90)" text-anchor="middle">Intensity</text>`;
 return {x,y,s};
}
function legend(entries,left,top,width){
 let s=`<g class="figure-legend"><rect x="${left}" y="${top}" width="${width}" height="${entries.length*17+8}" fill="white" stroke="black" stroke-width=".6"/>`;
 entries.forEach((e,i)=>{const yy=top+14+i*17;s+=e.area?`<rect x="${left+5}" y="${yy-8}" width="33" height="9" fill="${e.color}" fill-opacity="${e.opacity}" stroke="black" stroke-width=".5"/>`:`<path d="M${left+5} ${yy-4}h33" stroke="${e.color}" stroke-width="${e.selected?2:1}"/>`;s+=`<text x="${left+44}" y="${yy}" font-size="11">${esc(e.label)}</text>`;});return s+'</g>';
}
function profilePlot(){
 const ids=result.method===0?[0,1,2]:result.method===1?[3,4]:[result.channel];
 const ymax=Math.max(result.control?.height??0,result.test?.height??0)+20,xmax=Math.ceil(result.height/100)*100;
 const a=axes(75,35,520,285,0,xmax,ymax);let s=start(560,337,'Image Profile Plots');
 s+='<text x="298" y="26" text-anchor="middle" font-size="14" font-weight="bold">Image Profile Plots</text>'+a.s;
 for(const id of ids)s+=`<path d="${line(result.profiles[id],a.x,a.y)}" fill="none" stroke="${colors[id]}" stroke-width="1"/>`;
 const entries=ids.map(id=>({color:colors[id],label:names[id]}));
 if(result.method===0){s+=`<path d="${line(result.profile,a.x,a.y)}" fill="none" stroke="${colors[result.channel]}" stroke-width="2"/>`;entries.push({color:colors[result.channel],label:'Best Channel for analysis',selected:true});}
 for(const[p,name]of [[result.control,'Control Line'],[result.test,'Test Line']])if(p)s+=`<text x="${a.x(p.location)}" y="${a.y(p.height+5)}" text-anchor="middle" font-weight="bold">${name}</text>`;
 return s+legend(entries,325,40,195)+'</svg>';
}
function alignedPlot(){
 const ymax=Math.max(result.control?.height??0,result.test?.height??0)+20;
 const a=axes(75,38,520,160,1,result.height,ymax,false,ymax>100?50:ymax>40?20:ymax>10?5:1);
 // The shorter aligned profile in the PDF uses 50-unit y ticks.
 let s=start(560,337,'Profile Plot of the Best Channel');s+='<text x="298" y="24" text-anchor="middle" font-size="14">Profile Plot of the Best Channel</text>'+a.s;
 s+=`<path d="${line(result.profile,a.x,a.y)}" fill="none" stroke="${colors[result.channel]}" stroke-width="4"/>`;
 const entries=[];
 for(const[p,color,opacity,name,area]of [[result.control,'#ff00ff',.5,'Control',result.C_area],[result.test,'#0000ff',.4,'Test',result.T_area]]){
  if(!p)continue;const b=p.integration.bounds,baseline=p.integration.baseline,points=[];
  for(let i=b[0];i<=b[1];i++)points.push(`${a.x(i)},${a.y(result.corrected_profile[i-1])}`);
  for(let i=b[1];i>=b[0];i--)points.push(`${a.x(i)},${a.y(baseline[i-b[0]])}`);
  s+=`<polygon points="${points.join(' ')}" fill="${color}" fill-opacity="${opacity}"/><path d="M${a.x(b[0])} ${a.y(baseline[0])}L${a.x(b[1])} ${a.y(baseline.at(-1))}" fill="none" stroke="${color}" stroke-width="2"/>`;
  for(let i=0;i<2;i++)s+=`<path d="M${a.x(b[i])} 160V${a.y(p.integration.endpoints[i])}" stroke="black" stroke-dasharray="6 4"/><circle cx="${a.x(b[i])}" cy="${a.y(p.integration.endpoints[i])}" r="3.5" fill="none" stroke="${color}" stroke-width="2"/>`;
  s+=`<text x="${a.x(p.location)}" y="${Math.max(42,a.y(p.height+5))}" text-anchor="middle" font-size="12" font-weight="bold">${name} Line</text>`;
  entries.push({color,opacity,area:true,label:`${name} Line Area = ${Math.round(area)}`});
 }
 s+=legend(entries,326,41,191);
 const image=canvas(result.rgb,result.width,result.height,null,true).toDataURL('image/png');
 s+='<text x="298" y="214" text-anchor="middle" font-size="13">Original LFA Image Aligned with Profile</text>';
 s+=`<defs><clipPath id="aligned-image"><rect x="75" y="225" width="445" height="72"/></clipPath></defs><g clip-path="url(#aligned-image)"><image href="${image}" x="${a.x(.5)}" y="225" width="${a.x(result.height+.5)-a.x(.5)}" height="72" preserveAspectRatio="none"/>`;
 for(const p of [result.control,result.test])if(p)for(const v of p.integration.bounds)s+=`<path d="M${a.x(v)} 225V297" stroke="${result.readout===2?'white':'black'}" stroke-dasharray="6 4"/>`;
 s+='</g><rect x="75" y="225" width="445" height="72" fill="none" stroke="black" stroke-width=".6"/>';
 const step=result.height>100?100:Math.max(1,Math.ceil(result.height/5));for(let v=step;v<result.height;v+=step)s+=`<path d="M${a.x(v)} 297v-4" stroke="black" stroke-width=".6"/><text x="${a.x(v)}" y="315" text-anchor="middle">${v}</text>`;
 return s+'<text x="298" y="335" text-anchor="middle">Pixel</text></svg>';
}
function highlightedOutput(id,before,value,after=''){
 const strong=document.createElement('strong');strong.textContent=value;
 $(id).replaceChildren(document.createTextNode(before),strong,document.createTextNode(after));
}
function render(){
 $('error').hidden=true;$('analysis-output').hidden=false;
 for(const id of ['save-pdf-top','save-pdf-bottom'])$(id).disabled=false;
 if(appliedCrop){draw(canvas(result.rgb,result.width,result.height),$('cropped'));$('cropped-figure').hidden=false;$('crop-print-summary').hidden=false;$('crop-print-summary').textContent=`Applied crop: X = ${appliedCrop[0]}, Y = ${appliedCrop[1]}, width = ${appliedCrop[2]}, height = ${appliedCrop[3]}. Analysed image: ${result.width} × ${result.height} pixels.`;}
 const d=result.detection;
 highlightedOutput('readout-output',settings().readout===0?'Auto-detected LFA readout mode: ':'LFA readout mode: ',modes[result.readout],settings().readout===0?` (background ${number(d.backgroundLevel)}; dark-line score ${number(d.darkLineScore)}; bright-line score ${number(d.brightLineScore)}).`:'');
 const ids=result.method===0?[0,1,2]:result.method===1?[3,4]:[result.channel];$('channels').replaceChildren();
 for(const[title,plane]of [['Original Image',null],...ids.map(i=>[names[i],i<3?i:i===3?result.grayscale:result.adjusted])]){
  const f=document.createElement('figure'),caption=document.createElement('figcaption');caption.textContent=title;f.append(caption,canvas(result.rgb,result.width,result.height,plane));$('channels').append(f);
 }
 highlightedOutput('ranges-output',result.method===0?`red_range =\n${row4(result.ranges[0])}\n\ngreen_range =\n${row4(result.ranges[1])}\n\nblue_range =\n${row4(result.ranges[2])}\n\n`:'Image analysis method: ',names[result.channel],result.method===0?' is the best channel for further analysis':'');
 const peaks=[result.control,result.test].filter(Boolean);$('peak-arrays').replaceChildren();
 for(const[name,key]of [['pks','height'],['locs','location'],['widths','width'],['proms','prominence']]){
  const label=document.createElement('div');label.className='array-name';label.append(document.createTextNode(name+' = '));const shape=document.createElement('span');shape.textContent=`${peaks.length}×1`;label.append(shape);
  const p=document.createElement('pre');p.className='array-data';p.textContent=peaks.map(v=>key==='location'?'   '+v[key]:'   '+row4(v[key])).join('\n');$('peak-arrays').append(label,p);
 }
 $('profiles').innerHTML=profilePlot();$('aligned').innerHTML=alignedPlot();
 $('areas-output').textContent=`The area under control peak = ${number(result.C_area)}\n\nThe area under test peak = ${number(result.T_area)}`;
 $('results-output').textContent=`The area ratio (T/C)_area = ${number(result.area_ratio)}\n\nTest Peak Prominence = ${number(result.T_prom)}\n\nControl Peak Prominence = ${number(result.C_prom)}\n\nThe prominence ratio T/C = ${number(result.prom_ratio)}`;
 if(!result.control)$('areas-output').textContent+='\n\nControl peak not detected';if(!result.test)$('areas-output').textContent+='\n\nTest Line not detected';
}
function download(data,name,type){const url=URL.createObjectURL(new Blob([data],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}
const stem=()=>filename.replace(/\.[^.]+$/,'');
for(const kind of ['profile','aligned'])$(`download-${kind}`).addEventListener('click',()=>{const svg=$(kind==='profile'?'profiles':'aligned').querySelector('svg');download(new XMLSerializer().serializeToString(svg),`${stem()}-${kind}-live-script.svg`,'image/svg+xml');});
$('download-json').addEventListener('click',()=>download(JSON.stringify({filename,settings:settings(),...result},null,2),`${stem()}-live-script.json`,'application/json'));
$('download-csv').addEventListener('click',()=>{
 const fields=['C_area','T_area','area_ratio','C_prom','T_prom','prom_ratio'],quote=v=>'"'+String(v).replaceAll('"','""')+'"',o=settings();
 const rows=[['filename','method','readout','control_threshold','test_threshold',...fields],[filename,$('method').selectedOptions[0].textContent,modes[result.readout],o.control_threshold,o.test_threshold,...fields.map(k=>result[k])]];
 download(rows.map(r=>r.map(quote).join(',')).join('\r\n'),`${stem()}-live-script.csv`,'text/csv');
});
async function artwork(){
 const a=await(await fetch('./assets/artwork.json')).json();
 for(const key of ['4451','3c31']){
  const img=document.createElement('img');img.src='./assets/'+a[key];img.alt=key==='4451'?'Indian Institute of Science':'Toley Lab';
  const link=document.createElement('a');link.href=key==='4451'?'https://iisc.ac.in/':'https://toleylab.weebly.com/';link.target='_blank';link.rel='noopener noreferrer';link.setAttribute('aria-label',`Visit ${img.alt} website (opens in a new tab)`);link.append(img);$('logos').append(link);
 }
 $('orientation').src='./assets/'+a['0d05'];
}artwork().catch(e=>fail(e.message));

// The browser prints the entire document, including canvases and vector SVGs.
// Static setting values replace interactive controls only in the PDF layout.
function preparePrint(){
 syncExperimentDetails();
 document.querySelectorAll('.print-value').forEach(e=>e.remove());
 for(const input of document.querySelectorAll('select,input[type="number"],input[type="checkbox"]')){
  const span=document.createElement('span');span.className='print-value';
  span.textContent=input.tagName==='SELECT'?input.selectedOptions[0].textContent:input.type==='checkbox'?(input.checked?'true':'false'):input.value;
  if(input.type==='checkbox')input.closest('label').append(span);else input.insertAdjacentElement('afterend',span);
 }
}
function syncExperimentDetails(){
 const value=$('experiment-details').value;
 $('experiment-details-print').textContent=value;
 $('experiment-details-print').hidden=!value.trim();
}
$('experiment-details').addEventListener('input',syncExperimentDetails);
window.addEventListener('beforeprint',preparePrint);
for(const id of ['save-pdf-top','save-pdf-bottom'])$(id).addEventListener('click',()=>{
 if(!result||dirty){status('Complete the analysis and apply any crop before saving a PDF.');return;}
 preparePrint();window.print();
});
