# Third-party notices

The following dependencies were used to build the compiled analysis engine. Their original license and notice files are included below. No third-party rights are changed by this application.

## adler2 2.0.1

License expression: 0BSD OR MIT OR Apache-2.0.

- [LICENSE-0BSD](third-party/adler2-2.0.1/LICENSE-0BSD)
- [LICENSE-APACHE](third-party/adler2-2.0.1/LICENSE-APACHE)
- [LICENSE-MIT](third-party/adler2-2.0.1/LICENSE-MIT)

## autocfg 1.5.1

License expression: Apache-2.0 OR MIT.

- [LICENSE-APACHE](third-party/autocfg-1.5.1/LICENSE-APACHE)
- [LICENSE-MIT](third-party/autocfg-1.5.1/LICENSE-MIT)

## bitflags 2.13.2

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/bitflags-2.13.2/LICENSE-APACHE)
- [LICENSE-MIT](third-party/bitflags-2.13.2/LICENSE-MIT)

## bytemuck 1.25.2

License expression: Zlib OR Apache-2.0 OR MIT.

- [LICENSE-APACHE](third-party/bytemuck-1.25.2/LICENSE-APACHE)
- [LICENSE-MIT](third-party/bytemuck-1.25.2/LICENSE-MIT)
- [LICENSE-ZLIB](third-party/bytemuck-1.25.2/LICENSE-ZLIB)

## byteorder-lite 0.1.0

License expression: Unlicense OR MIT.

- [LICENSE-MIT](third-party/byteorder-lite-0.1.0/LICENSE-MIT)
- [UNLICENSE](third-party/byteorder-lite-0.1.0/UNLICENSE)

## cfg-if 1.0.5

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/cfg-if-1.0.5/LICENSE-APACHE)
- [LICENSE-MIT](third-party/cfg-if-1.0.5/LICENSE-MIT)

## crc32fast 1.5.4

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/crc32fast-1.5.4/LICENSE-APACHE)
- [LICENSE-MIT](third-party/crc32fast-1.5.4/LICENSE-MIT)

## fax 0.2.7

License expression: MIT.

- [LICENSE](third-party/fax-0.2.7/LICENSE)

## fdeflate 0.3.7

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/fdeflate-0.3.7/LICENSE-APACHE)
- [LICENSE-MIT](third-party/fdeflate-0.3.7/LICENSE-MIT)

## flate2 1.1.11

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/flate2-1.1.11/LICENSE-APACHE)
- [LICENSE-MIT](third-party/flate2-1.1.11/LICENSE-MIT)

## half 2.7.1

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/half-2.7.1/LICENSE-APACHE)
- [LICENSE-MIT](third-party/half-2.7.1/LICENSE-MIT)

## image 0.25.10

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/image-0.25.10/LICENSE-APACHE)
- [LICENSE-MIT](third-party/image-0.25.10/LICENSE-MIT)

## itoa 1.0.18

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/itoa-1.0.18/LICENSE-APACHE)
- [LICENSE-MIT](third-party/itoa-1.0.18/LICENSE-MIT)

## jpeg-decoder 0.3.2

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/jpeg-decoder-0.3.2/LICENSE-APACHE)
- [LICENSE-MIT](third-party/jpeg-decoder-0.3.2/LICENSE-MIT)

## memchr 2.8.3

License expression: Unlicense OR MIT.

- [COPYING](third-party/memchr-2.8.3/COPYING)
- [LICENSE-MIT](third-party/memchr-2.8.3/LICENSE-MIT)
- [UNLICENSE](third-party/memchr-2.8.3/UNLICENSE)

## miniz_oxide 0.8.9

License expression: MIT OR Zlib OR Apache-2.0.

- [LICENSE](third-party/miniz_oxide-0.8.9/LICENSE)
- [LICENSE-APACHE.md](third-party/miniz_oxide-0.8.9/LICENSE-APACHE.md)
- [LICENSE-MIT.md](third-party/miniz_oxide-0.8.9/LICENSE-MIT.md)
- [LICENSE-ZLIB.md](third-party/miniz_oxide-0.8.9/LICENSE-ZLIB.md)

## miniz_oxide 0.9.1

License expression: MIT OR Zlib OR Apache-2.0.

- [LICENSE](third-party/miniz_oxide-0.9.1/LICENSE)
- [LICENSE-APACHE.md](third-party/miniz_oxide-0.9.1/LICENSE-APACHE.md)
- [LICENSE-MIT.md](third-party/miniz_oxide-0.9.1/LICENSE-MIT.md)
- [LICENSE-ZLIB.md](third-party/miniz_oxide-0.9.1/LICENSE-ZLIB.md)

## moxcms 0.8.1

License expression: BSD-3-Clause OR Apache-2.0.

- [LICENSE-APACHE.md](third-party/moxcms-0.8.1/LICENSE-APACHE.md)
- [LICENSE.md](third-party/moxcms-0.8.1/LICENSE.md)

## num-traits 0.2.19

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/num-traits-0.2.19/LICENSE-APACHE)
- [LICENSE-MIT](third-party/num-traits-0.2.19/LICENSE-MIT)

## png 0.18.1

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/png-0.18.1/LICENSE-APACHE)
- [LICENSE-MIT](third-party/png-0.18.1/LICENSE-MIT)

## proc-macro2 1.0.107

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/proc-macro2-1.0.107/LICENSE-APACHE)
- [LICENSE-MIT](third-party/proc-macro2-1.0.107/LICENSE-MIT)

## pxfm 0.1.30

License expression: BSD-3-Clause OR Apache-2.0.

- [LICENSE-APACHE.md](third-party/pxfm-0.1.30/LICENSE-APACHE.md)
- [LICENSE.md](third-party/pxfm-0.1.30/LICENSE.md)

## quick-error 2.0.1

License expression: MIT/Apache-2.0.

- [LICENSE-APACHE](third-party/quick-error-2.0.1/LICENSE-APACHE)
- [LICENSE-MIT](third-party/quick-error-2.0.1/LICENSE-MIT)

## quote 1.0.47

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/quote-1.0.47/LICENSE-APACHE)
- [LICENSE-MIT](third-party/quote-1.0.47/LICENSE-MIT)

## serde_core 1.0.229

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/serde_core-1.0.229/LICENSE-APACHE)
- [LICENSE-MIT](third-party/serde_core-1.0.229/LICENSE-MIT)

## serde_derive 1.0.229

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/serde_derive-1.0.229/LICENSE-APACHE)
- [LICENSE-MIT](third-party/serde_derive-1.0.229/LICENSE-MIT)

## serde_json 1.0.154

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/serde_json-1.0.154/LICENSE-APACHE)
- [LICENSE-MIT](third-party/serde_json-1.0.154/LICENSE-MIT)

## serde 1.0.229

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/serde-1.0.229/LICENSE-APACHE)
- [LICENSE-MIT](third-party/serde-1.0.229/LICENSE-MIT)

## simd-adler32 0.3.10

License expression: MIT.

- [LICENSE.md](third-party/simd-adler32-0.3.10/LICENSE.md)

## syn 2.0.119

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/syn-2.0.119/LICENSE-APACHE)
- [LICENSE-MIT](third-party/syn-2.0.119/LICENSE-MIT)

## syn 3.0.9

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/syn-3.0.9/LICENSE-APACHE)
- [LICENSE-MIT](third-party/syn-3.0.9/LICENSE-MIT)

## tiff 0.11.3

License expression: MIT.

- [LICENSE](third-party/tiff-0.11.3/LICENSE)

## unicode-ident 1.0.27

License expression: (MIT OR Apache-2.0) AND Unicode-3.0.

- [LICENSE-APACHE](third-party/unicode-ident-1.0.27/LICENSE-APACHE)
- [LICENSE-MIT](third-party/unicode-ident-1.0.27/LICENSE-MIT)
- [LICENSE-UNICODE](third-party/unicode-ident-1.0.27/LICENSE-UNICODE)

## weezl 0.1.12

License expression: MIT OR Apache-2.0.

- [LICENSE-APACHE](third-party/weezl-0.1.12/LICENSE-APACHE)
- [LICENSE-MIT](third-party/weezl-0.1.12/LICENSE-MIT)

## zerocopy-derive 0.8.63

License expression: BSD-2-Clause OR Apache-2.0 OR MIT.

- [LICENSE-APACHE](third-party/zerocopy-derive-0.8.63/LICENSE-APACHE)
- [LICENSE-BSD](third-party/zerocopy-derive-0.8.63/LICENSE-BSD)
- [LICENSE-MIT](third-party/zerocopy-derive-0.8.63/LICENSE-MIT)

## zerocopy 0.8.63

License expression: BSD-2-Clause OR Apache-2.0 OR MIT.

- [LICENSE-APACHE](third-party/zerocopy-0.8.63/LICENSE-APACHE)
- [LICENSE-BSD](third-party/zerocopy-0.8.63/LICENSE-BSD)
- [LICENSE-MIT](third-party/zerocopy-0.8.63/LICENSE-MIT)

## zlib-rs 0.6.8

License expression: Zlib.

- [LICENSE](third-party/zlib-rs-0.6.8/LICENSE)

## zmij 1.0.23

License expression: MIT.

- [LICENSE-MIT](third-party/zmij-1.0.23/LICENSE-MIT)

## zune-core 0.5.3

License expression: MIT OR Apache-2.0 OR Zlib.

- [LICENSE-APACHE](third-party/zune-core-0.5.3/LICENSE-APACHE)
- [LICENSE-MIT](third-party/zune-core-0.5.3/LICENSE-MIT)
- [LICENSE-ZLIB](third-party/zune-core-0.5.3/LICENSE-ZLIB)

## zune-jpeg 0.5.15

License expression: MIT OR Apache-2.0 OR Zlib.

- [LICENSE-APACHE](third-party/zune-jpeg-0.5.15/LICENSE-APACHE)
- [LICENSE-MIT](third-party/zune-jpeg-0.5.15/LICENSE-MIT)
- [LICENSE-ZLIB](third-party/zune-jpeg-0.5.15/LICENSE-ZLIB)

## Rust standard library

See [Rust library copyright](third-party/rust/COPYRIGHT-library.html), and the original license texts in third-party/rust/licenses/.

## LAPACK mathematical routines

The small eigensolver adapts public LAPACK mathematics. Original notice: [LAPACK.txt](assets/licenses/LAPACK.txt).

## Local decoder modification

The jpeg-decoder dependency includes the existing local numerical-decoding patch. It retains its original MIT/Apache-2.0 license notices.
