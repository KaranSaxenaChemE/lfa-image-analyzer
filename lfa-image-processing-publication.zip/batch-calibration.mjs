// MATLAB notebook plot labels and styles, with collision-free legend placement.
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
function crosses(a,b,box){
 let lo=0,hi=1;const dx=b[0]-a[0],dy=b[1]-a[1];
 for(const[p,q]of [[-dx,a[0]-box.x],[dx,box.x+box.w-a[0]],[-dy,a[1]-box.y],[dy,box.y+box.h-a[1]]]){
  if(p===0){if(q<0)return false;continue;}
  const t=q/p;if(p<0)lo=Math.max(lo,t);else hi=Math.min(hi,t);if(lo>hi)return false;
 }return true;
}
function tickStep(max){
 const raw=max/6,scale=10**Math.floor(Math.log10(raw));
 return [1,2,2.5,5,10].map(v=>v*scale).reduce((a,b)=>Math.abs(a-raw)<Math.abs(b-raw)?a:b);
}
export function calibrationFigure(result,{analyte='',units='',publication=false}={}){
 const fit=result.fit,rows=result.averages.rows.filter(v=>v[0]>0);
 const curve=fit.curve.filter(v=>typeof v[1]==='number'&&Number.isFinite(v[1]));
 const left=75,right=520,top=35,bottom=285;
 const xmin=curve[0][0],xmax=curve.at(-1)[0],ymax=Math.max(...rows.map(v=>v[1]+v[2]))+.2;
 const x=v=>left+(Math.log(v)-Math.log(xmin))/(Math.log(xmax)-Math.log(xmin))*(right-left);
 const y=v=>bottom-v/ymax*(bottom-top);
 const fitColor=publication?'#d55e00':'#ff0000',dataColor=publication?'#0072b2':'#0072bd';
 const modelNames={logistic4:'4PL',logistic5:'5PL',hill:'Hill',langmuir:'Langmuir',linear:'Linear',exp2:'Bi-exponential'};
 const r2=fit.gof.rows[0][fit.gof.columns.indexOf('R_squared')];
 const rsquare=typeof r2==='number'&&Number.isFinite(r2)?r2.toFixed(3):String(r2);
 const labels=['Experimental Data','Fitted Curve (R² = '+rsquare+')','Curve Fit Model: '+modelNames[fit.model]];
 if(typeof fit.lod==='number')labels.push('LoD = '+fit.lod_display+(units?' '+units:''));
 const width=230,height=labels.length*17+12;
 const segments=[];
 for(let i=1;i<curve.length;i++)segments.push([[x(curve[i-1][0]),y(curve[i-1][1])],[x(curve[i][0]),y(curve[i][1])]]);
 for(const v of rows){const xx=x(v[0]);segments.push([[xx,y(v[1]-v[2])],[xx,y(v[1]+v[2])]],[[xx-4,y(v[1])],[xx+4,y(v[1])]]);}
 if(typeof fit.lod==='number')segments.push([[left,y(fit.lod_signal)],[x(fit.lod),y(fit.lod_signal)]],[[x(fit.lod),y(fit.lod_signal)],[x(fit.lod),bottom]]);
 const corners=[
  {name:'northwest',x:left+10,y:top+10,w:width,h:height},
  {name:'northeast',x:right-width-10,y:top+10,w:width,h:height},
  {name:'southwest',x:left+10,y:bottom-height-10,w:width,h:height},
  {name:'southeast',x:right-width-10,y:bottom-height-10,w:width,h:height}
 ];
 const legend=corners.find(box=>!segments.some(([a,b])=>crosses(a,b,{x:box.x-6,y:box.y-6,w:box.w+12,h:box.h+12})))??{name:'outside',x:left,y:365,w:width,h:height};
 const svgHeight=legend.name==='outside'?legend.y+height+15:365;
 const clip=publication?'publication-plot-area':'working-plot-area';
 let s='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 580 '+svgHeight+'" font-family="Arial,Helvetica,sans-serif" font-size="12" role="img"><title>LFA Calibration Curve and LoD</title><rect width="580" height="'+svgHeight+'" fill="white"/><defs><clipPath id="'+clip+'"><rect x="'+left+'" y="'+top+'" width="'+(right-left)+'" height="'+(bottom-top)+'"/></clipPath></defs>';
 if(!publication)s+='<text x="298" y="22" text-anchor="middle" font-size="14">LFA Standard Curve</text>';
 s+='<path d="M'+left+' '+top+'V'+bottom+'H'+right+(publication?'':'V'+top+'H'+left)+'" fill="none" stroke="black" stroke-width=".75"/>';
 for(let d=Math.floor(Math.log10(xmin));d<=Math.ceil(Math.log10(xmax));d++){const v=10**d;if(v<xmin||v>xmax)continue;s+='<path d="M'+x(v)+' '+bottom+'v5" stroke="black"/><text x="'+x(v)+'" y="305" text-anchor="middle">'+v+'</text>';}
 const step=tickStep(ymax);
 for(let v=0;v<=ymax+step*1e-10;v+=step)s+='<path d="M70 '+y(v)+'h5" stroke="black"/><text x="65" y="'+(y(v)+4)+'" text-anchor="end">'+Number(v.toPrecision(6))+'</text>';
 s+='<g clip-path="url(#'+clip+')"><path class="fitted-curve" d="'+curve.map((v,i)=>(i?'L':'M')+x(v[0]).toFixed(3)+' '+y(v[1]).toFixed(3)).join('')+'" fill="none" stroke="'+fitColor+'" stroke-width="'+(publication?1.2:1.5)+'"/>';
 for(const v of rows)s+='<path class="experimental-errorbar" d="M'+x(v[0])+' '+y(v[1]-v[2])+'V'+y(v[1]+v[2])+'M'+(x(v[0])-4)+' '+y(v[1]-v[2])+'h8M'+(x(v[0])-4)+' '+y(v[1]+v[2])+'h8" stroke="'+dataColor+'"/><circle class="experimental-marker" cx="'+x(v[0])+'" cy="'+y(v[1])+'" r="3" stroke="'+dataColor+'" fill="none"/>';
 if(typeof fit.lod==='number')s+='<path d="M'+left+' '+y(fit.lod_signal)+'H'+x(fit.lod)+'V'+bottom+'" stroke="black" stroke-dasharray="6 4" fill="none"/><circle cx="'+x(fit.lod)+'" cy="'+y(fit.lod_signal)+'" r="3" fill="black"/>';
 s+='</g>';
 const xlabel=[analyte.trim(),'Concentration',units.trim()?'('+units.trim()+')':''].filter(Boolean).join(' ');
 const metrics={'T_area':['T','area'],'(T/C)_area':['(T/C)','area'],'T Prominence':['T','prominence'],'T/C Prominence':['(T/C)','prominence']};
 const metric=metrics[result.signal],ylabel=metric?esc(metric[0])+'<tspan baseline-shift="sub" font-size="9">'+metric[1]+'</tspan>':esc(result.signal);
 s+='<text x="298" y="342" text-anchor="middle">'+esc(xlabel)+'</text><text transform="translate(23 160) rotate(-90)" text-anchor="middle">'+ylabel+'</text>';
 s+='<g class="figure-legend" data-placement="'+legend.name+'" data-bounds="'+[legend.x,legend.y,legend.w,legend.h].join(',')+'" transform="translate('+legend.x+' '+legend.y+')">';
 if(!publication)s+='<rect width="'+width+'" height="'+height+'" fill="white" stroke="black" stroke-width=".6"/>';
 labels.forEach((label,i)=>{
  const yy=17+i*17;
  if(i===0)s+='<circle cx="17" cy="'+(yy-4)+'" r="3" stroke="'+dataColor+'" fill="none"/>';
  if(i===1)s+='<path d="M7 '+(yy-4)+'h24" stroke="'+fitColor+'" stroke-width="1.2"/>';
  if(i===3)s+='<circle cx="17" cy="'+(yy-4)+'" r="3" fill="black"/>';
  s+='<text x="38" y="'+yy+'" font-size="'+(publication&&i<3?10.5:11)+'"'+(publication&&i===3?' font-weight="bold"':'')+'>'+esc(label)+'</text>';
 });
 return s+'</g></svg>';
}
