// Native MathML keeps equations local, accessible and available in print/PDF.
const row=(...parts)=>'<mrow>'+parts.join('')+'</mrow>';
const variable=name=>'<mi>'+name+'</mi>';
const operator=value=>'<mo>'+value+'</mo>';
const number=value=>'<mn>'+value+'</mn>';
const fraction=(top,bottom)=>'<mfrac>'+top+bottom+'</mfrac>';
const power=(base,exponent)=>'<msup>'+base+exponent+'</msup>';
const subscript=(base,label)=>'<msub>'+base+'<mtext>'+label+'</mtext></msub>';
const product=(...terms)=>row(...terms.flatMap((term,i)=>i?[operator('&#x2062;'),term]:[term]));
const math=(expression,label)=>'<math xmlns="http://www.w3.org/1998/Math/MathML" display="block" aria-label="'+label+'">'+expression+'</math>';
const equals=operator('='),plus=operator('+');

export function modelEquation(model,format){
 const a=variable('a'),b=variable('b'),c=variable('c'),d=variable('d'),x=variable('x');
 const A=variable('A'),K=variable('K'),n=variable('n');
 let expression,label;
 if(model==='logistic4'||model==='logistic5'){
  const scaled=power(row(operator('('),fraction(x,c),operator(')')),b);
  const base=row(number(1),plus,scaled);
  const denominator=model==='logistic5'?power(row(operator('['),base,operator(']')),variable('e')):base;
  expression=row(d,plus,fraction(row(a,operator('−'),d),denominator));
  label=model==='logistic4'?'Four parameter logistic: y equals d plus the fraction a minus d over one plus x over c raised to b.':'Five parameter logistic: y equals d plus the fraction a minus d over the bracket one plus x over c raised to b, with the whole bracket raised to e.';
 }else if(model==='hill'){
  const xn=power(x,n),kn=power(K,n);
  expression=fraction(product(A,format==='Competitive'?kn:xn),row(kn,plus,xn));
  label='Hill '+format+': y equals A times '+(format==='Competitive'?'K':'x')+' to the power n divided by K to the power n plus x to the power n.';
 }else if(model==='langmuir'){
  expression=fraction(product(A,format==='Competitive'?K:x),row(K,plus,x));
  label='Langmuir '+format+': y equals A times '+(format==='Competitive'?'K':'x')+' divided by K plus x.';
 }else if(model==='linear'){
  expression=row(product(variable('m'),x),plus,c);label='Linear: y equals m times x plus c.';
 }else if(model==='exp2'){
  const exponential=rate=>power('<mi mathvariant="normal">e</mi>',product(rate,x));
  expression=row(product(a,exponential(b)),plus,product(c,exponential(d)));
  label='Bi-exponential: y equals a times e to the power b x plus c times e to the power d x.';
 }else return '';
 return math(row(variable('y'),equals,expression),label);
}

export function lodEquation(method,direction){
 const sign=operator(direction<0?'−':'+');
 const mean=subscript(variable('μ'),'blank'),blankSD=subscript(variable('σ'),'blank');
 const terms=[mean,sign,product(number(method===1?'1.645':'3'),blankSD)];
 if(method===1)terms.push(sign,product(number('1.645'),subscript(variable('σ'),'low conc')));
 const label='LoD signal threshold equals blank mean '+(direction<0?'minus':'plus')+' '+(method===1?'1.645 times blank standard deviation '+(direction<0?'minus':'plus')+' 1.645 times low concentration standard deviation.':'3 times blank standard deviation.');
 return math(row(subscript('<mi mathvariant="normal">LoD</mi>','signal'),equals,...terms),label);
}
