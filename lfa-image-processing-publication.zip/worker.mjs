import {createEngine} from './engine.mjs';
let engine, input;
try {engine=await createEngine(await (await fetch('./single_lfa.wasm')).arrayBuffer());postMessage({type:'ready'});}
catch(error){postMessage({type:'fatal',error:`The analysis engine could not start. ${error.message}`});}
onmessage=({data})=>{
  try {
    if(data.type==='load'){
      input=null;const decoded=engine.decode(new Uint8Array(data.bytes));
      if(!decoded.error)input={...decoded,rgb:Uint8Array.from(decoded.rgb)};
      postMessage({type:'loaded',id:data.id,result:decoded});
    }else if(data.type==='analyze'){
      if(!input)throw new Error('Select an image first.');
      const result=engine.rgb(input.rgb,input.width,input.height,data.options);
      postMessage({type:'result',id:data.id,result});
    }
  }catch(error){postMessage({type:'result',id:data.id,result:{error:error.message}});}
};
