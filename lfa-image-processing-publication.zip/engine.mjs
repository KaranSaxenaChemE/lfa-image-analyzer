// Thin transport only: all decoding and scientific calculations are in Rust/Wasm.
export async function createEngine(bytes) {
  const { instance } = await WebAssembly.instantiate(bytes, {});
  const e=instance.exports, encoder=new TextEncoder(), decoder=new TextDecoder();
  function put(bytes){const p=e.allocate(bytes.length);new Uint8Array(e.memory.buffer,p,bytes.length).set(bytes);return p;}
  function result(){return JSON.parse(decoder.decode(new Uint8Array(e.memory.buffer,e.result_pointer(),e.result_length())));}
  function call(name,bytes,options,w,h){
    const op=encoder.encode(JSON.stringify(options??{}));const p=put(bytes),q=put(op);
    try {
      if(name==='analyze_rgb')e[name](p,bytes.length,w,h,q,op.length);
      else if(name==='analyze_file')e[name](p,bytes.length,q,op.length);
      else e[name](p,bytes.length);
      return result();
    } finally {e.release(p,bytes.length);e.release(q,op.length);}
  }
  return {
    decode:bytes=>call('decode_file',bytes),
    batch:(rows,options)=>call('batch_summary',encoder.encode(JSON.stringify({rows,options}))),
    file:(bytes,options)=>call('analyze_file',bytes,options),
    rgb:(bytes,w,h,options)=>call('analyze_rgb',bytes,options,w,h),
    peaks:(profile,threshold=0)=>call('inspect_peaks',encoder.encode(JSON.stringify({profile,threshold})))
  };
}
