# LFA Image Processing

Browser-based Single and Batch LFA image processing, developed by Karan Saxena and Bhushan Toley, Toley Lab, Indian Institute of Science.

## Use

Open the hosted home page and choose Single or Batch analysis. Both open the Notebook Interface; a separate Single App Interface is also available. Processing runs in your browser. Images and experiment notes are not uploaded. MATLAB is not required.

For Single analysis, select an 8-bit RGB strip image or try the clearly labelled synthetic example. Place Control above Test; crop if needed, then inspect the profiles and measurements.

For Batch analysis, choose a folder or files from one experiment. For calibration, use Concentration_ReplicateNumber_SubstrateName filenames, for example 0.1_II_AuNP.png. Review the per-image results, replicate statistics, chosen assay format, fitted curve and warnings. Export each complete table as CSV, figures as SVG, or the notebook as PDF with experimental notes.

This app is free to use for analysis. A source-code reuse licence has not yet been granted; licensing terms are under review. Third-party components retain their respective licences. If it contributes to image processing or data analysis of your lateral flow immunoassays, please cite:

Saxena, K.; Toley, B. Streamlining Lateral Flow Assay (LFA) Data Analysis: A MATLAB® Live Script for Integrated Batch Image Processing and Limit of Detection Determination. ChemRxiv 2024 [Preprint]. https://doi.org/10.26434/chemrxiv-2024-wr3kj

## Local preview

These are static website files. Serve this folder over local HTTP; opening HTML directly as a file will not start the analysis workers. No build, account or API key is needed to use the compiled app.

## Credits

Original application: Karan Saxena and Bhushan Toley. Institutional artwork remains unchanged. Third-party components retain their own licenses; see THIRD_PARTY_NOTICES.md and third-party/. The included example strip is synthetic.
